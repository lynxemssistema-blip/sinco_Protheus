const fs = require('fs');
const path = require('path');
const p = path.join('server', 'services', 'pcpmetal', 'orchestrator.js');
let text = fs.readFileSync(p, 'utf8');

const regexAnalystQuestion = /const analystQuestion = Pergunta do usu�rio: "\$\{userMessage\}"\$\{historyContext\}\\n\\nGenere as consultas SQL.*;/;

const newAnalystQuestion = "const analystQuestion = Pergunta do usu�rio: \"\\"\\\n\\nGenere as consultas SQL necess�rias. Se o usu�rio pedir para alterar ou atualizar, voc� pode gerar UPDATE/INSERT/DELETE no banco MySQL. Formato: \\\\\\\\\sql\\n[BANCO: postgresql ou mysql]\\nSELECT ou UPDATE...\\n\\\\\\\\\`;";

text = text.replace(regexAnalystQuestion, newAnalystQuestion);

// Now for the SQL execution block
const regexExecute = /const result = await runQuery\(banco, sql\);/;

const newExecute = 
                const isDml = /^(UPDATE|INSERT|DELETE)\\s/i.test(sql.trim());
                const permissionGranted = /(autorizado|pode fazer|pode executar|aprovo|sim|atualize|execute|confirmo)/i.test(userMessage);
                
                let result;
                if (isDml && !permissionGranted) {
                    // N�o executa, apenas passa para o estrategista pedir permiss�o
                    result = { rows: [{ aviso: 'SQL DML gerado mas N�O executado. O Estrategista deve mostrar o comando SQL ao usu�rio e pedir permiss�o expl�cita para executar.' }], rowCount: 0 };
                    send({ type: 'step', icon: '??', message: \Consulta \ requer confirma��o do usu�rio (UPDATE/INSERT/DELETE)\ });
                } else if (isDml && banco === 'postgresql') {
                    result = { rows: [{ error: 'N�o � permitido fazer altera��es no Protheus (PostgreSQL)' }], rowCount: 0 };
                } else {
                    result = await runQuery(banco, sql);
                }
;

text = text.replace(regexExecute, newExecute);

fs.writeFileSync(p, text, 'utf8');
console.log('Updated orchestrator.js to support DML and permissions!');
