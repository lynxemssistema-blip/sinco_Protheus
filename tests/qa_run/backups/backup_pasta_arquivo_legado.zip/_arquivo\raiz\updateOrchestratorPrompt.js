const fs = require('fs');
const path = require('path');
const p = path.join('server', 'services', 'pcpmetal', 'orchestrator.js');
let text = fs.readFileSync(p, 'utf8');

const regexStrategistQ = /const finalQuestion = Pergunta original.*?;/g;

const newStrategistQ = "const finalQuestion = Pergunta original: \"\\"\\\n\\n\\\n\\nResponda diretamente � pergunta do usu�rio em Portugu�s (Brasil). Importante: (1) O seu estilo de conversa deve ser como num bate-papo, natural e contextualizado. (2) Se o usu�rio pedir expressamente um 'relat�rio t�cnico', gere um relat�rio completo em Markdown. Caso contr�rio, apenas responda o que foi perguntado de forma clara e flu�da. (3) Sempre que solicitado, ofere�a sugest�es ou ideias estrat�gicas de como ajustar o planejamento da produ��o ou resolver o problema detectado.;";

text = text.replace(regexStrategistQ, newStrategistQ);

fs.writeFileSync(p, text, 'utf8');
console.log('Orchestrator prompt updated!');
