const express = require('express');
const router = express.Router();
const mysqlPool = require('../services/mysqlService');

// Table Initialization
(async () => {
    try {
        await mysqlPool.query(`
            CREATE TABLE IF NOT EXISTS app_engineering_releases (
                id INT AUTO_INCREMENT PRIMARY KEY,
                codigo_produto VARCHAR(50) NOT NULL,
                descricao_produto TEXT NOT NULL,
                pedido VARCHAR(30) DEFAULT NULL,
                item VARCHAR(10) DEFAULT NULL,
                usuario VARCHAR(100) NOT NULL,
                tipo_acao ENUM('DOWNLOAD', 'EMAIL') NOT NULL,
                destinatarios TEXT DEFAULT NULL,
                modo ENUM('FULL', 'N1') NOT NULL,
                data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_prod_rel (codigo_produto),
                INDEX idx_data_rel (data_hora)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        `);
        console.log('✅ Engineering Releases table initialized');
    } catch (err) {
        console.error('❌ Error initializing app_engineering_releases table:', err);
    }
})();

// POST /api/engineering-releases/log - Register a new release action
router.post('/log', async (req, res) => {
    try {
        const {
            codigo_produto,
            descricao_produto,
            pedido,
            item,
            usuario,
            tipo_acao,
            destinatarios,
            modo
        } = req.body;

        if (!codigo_produto || !usuario || !tipo_acao || !modo) {
            return res.status(400).json({ error: 'Campos obrigatórios ausentes.' });
        }

        await mysqlPool.query(
            `INSERT INTO app_engineering_releases 
             (codigo_produto, descricao_produto, pedido, item, usuario, tipo_acao, destinatarios, modo) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [codigo_produto, descricao_produto, pedido || null, item || null, usuario, tipo_acao, destinatarios || null, modo]
        );

        res.json({ success: true });
    } catch (err) {
        console.error('❌ [LOG ERROR]', err);
        res.status(500).json({ error: err.message });
    }
});

// GET /api/engineering-releases - Get history with optional filters
router.get('/', async (req, res) => {
    try {
        const { startDate, endDate, product, user, pedido, item } = req.query;
        let whereClauses = [];
        let params = [];

        if (startDate) {
            whereClauses.push(`data_hora >= ?`);
            params.push(`${startDate} 00:00:00`);
        }
        if (endDate) {
            whereClauses.push(`data_hora <= ?`);
            params.push(`${endDate} 23:59:59`);
        }
        if (product) {
            whereClauses.push(`codigo_produto LIKE ?`);
            params.push(`%${product}%`);
        }
        if (user) {
            whereClauses.push(`usuario LIKE ?`);
            params.push(`%${user}%`);
        }
        if (pedido) {
            whereClauses.push(`pedido LIKE ?`);
            params.push(`%${pedido}%`);
        }
        if (item) {
            whereClauses.push(`item LIKE ?`);
            params.push(`%${item}%`);
        }

        const whereSQL = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';
        const [rows] = await mysqlPool.query(
            `SELECT * FROM app_engineering_releases ${whereSQL} ORDER BY data_hora DESC LIMIT 1000`,
            params
        );

        res.json(rows);
    } catch (err) {
        console.error('❌ [FETCH ERROR]', err);
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
