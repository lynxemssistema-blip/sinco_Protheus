@echo off
title Agente MetalFisa SolidWorks
color 0B
cd /d "%~dp0"
echo =========================================================
echo    AGENTE LOCAL METALFISA - LEITURA SOLIDWORKS
echo =========================================================
echo.

WHERE node >nul 2>nul
IF %ERRORLEVEL% NEQ 0 GOTO NodeNotFound

IF NOT EXIST "node_modules\" GOTO InstallDeps

:StartAgent
echo.
echo [INFO] Iniciando o Conector Local (Porta 3005)...
echo =========================================================
echo.
node agent.js
echo.
echo [AVISO] O Agente foi encerrado.
pause
exit /b 0

:InstallDeps
echo [INFO] Essa e a primeira vez rodando (ou faltam modulos).
echo Instalando dependencias do painel...
call npm install express cors
IF %ERRORLEVEL% NEQ 0 GOTO InstallError
echo [INFO] Instalacao completa!
GOTO StartAgent

:NodeNotFound
echo [ERRO] Node.js nao encontrado no seu computador!
echo Para que a integracao com o SolidWorks funcione na Web,
echo voce precisa de um pequeno programa chamado Node.js.
echo.
echo 1. Acesse: https://nodejs.org/
echo 2. Baixe a versao LTS e instale (So Clicar em Next).
echo 3. Apos instalar, abra o start-sw-agent.bat novamente.
echo.
pause
exit /b 1

:InstallError
echo.
echo [ERRO] Falha ao instalar as dependencias. 
echo Verifique se voce tem acesso a internet.
pause
exit /b 1
