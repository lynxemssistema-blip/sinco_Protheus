# get_sw_data.ps1
# Script to read SolidWorks Active Document data without requiring Winax / C++
$ErrorActionPreference = "Stop"

try {
    # Attempt to connect to the running SolidWorks instance
    $swApp = [System.Runtime.InteropServices.Marshal]::GetActiveObject("SldWorks.Application")
    
    if (-not $swApp) {
        Write-Output '{"status":"error","message":"SolidWorks object not found."}'
        exit
    }

    $swModel = $swApp.ActiveDoc
    if (-not $swModel) {
        Write-Output '{"status":"connected","documentoAberto":false}'
        exit
    }

    $title = $swModel.GetTitle()
    $pathname = $swModel.GetPathName()
    $type = $swModel.GetType() # 1=Part, 2=Assembly, 3=Drawing

    if ($args[0] -eq "status") {
        # Only return status
        $json = @{
            status = "connected"
            documentoAberto = $true
            arquivoNome = $title
            arquivoCaminho = $pathname
            tipoArquivo = if ($type -eq 1) {"Peça"} elseif ($type -eq 2) {"Montagem"} elseif ($type -eq 3) {"Desenho"} else {"Desconhecido"}
        }
        $json | ConvertTo-Json -Compress -Depth 2
        exit
    }

    if ($args[0] -eq "properties") {
        $swCustPropMgr = $swModel.Extension.CustomPropertyManager("")
        if (-not $swCustPropMgr) {
            Write-Output '{"success":false,"message":"Could not access CustomPropertyManager"}'
            exit
        }

        $names = $swCustPropMgr.GetNames()
        $propsList = @()
        
        if ($names -ne $null) {
            foreach ($name in $names) {
                # VBScript/COM interop from powershell returns a string directly on GET usually
                $val = $swCustPropMgr.Get($name)
                # Attempt to get resolved using get5 or via API, but .Get() is safest fallback
                $propsList += @{
                    nome = $name
                    valorBruto = $val
                    valorResolvido = $val
                }
            }
        }
        
        $json = @{
            success = $true
            total = $propsList.Count
            propriedades = $propsList
        }
        $json | ConvertTo-Json -Compress -Depth 3
        exit
    }

    if ($args[0] -eq "geometry") {
        if ($type -eq 3) {
            Write-Output '{"success":false,"message":"Mass properties don''t apply to 2D drawings."}'
            exit
        }
        
        $swMass = $swModel.Extension.CreateMassProperty()
        if (-not $swMass) {
            Write-Output '{"success":false,"message":"Failed to CreateMassProperty"}'
            exit
        }

        $swMass.UseSystemUnits = $true # standard SI metric kg, m3

        $json = @{
            success = $true
            geometria = @{
                massa_kg = $swMass.Mass
                area_m2 = $swMass.SurfaceArea
                volume_m3 = $swMass.Volume
                densidade_kg_m3 = $swMass.Density
                material = "Configurado no SW" # PowerShell .GetMaterialPropertyName2 throws COM errors often without 'ref' params. Leaving generic.
            }
        }
        $json | ConvertTo-Json -Compress -Depth 3
        exit
    }

} catch {
    $errMsg = $_.Exception.Message
    # Se erro for MK_E_UNAVAILABLE, o SolidWorks não está aberto.
    if ($errMsg -match "0x800401E3") {
        Write-Output '{"status":"error","message":"SolidWorks nao esta aberto no computador."}'
    } else {
        $cleanMsg = $errMsg -replace '"', '\"'
        Write-Output "{`"status`":`"error`",`"message`":`"$cleanMsg`"}"
    }
}
