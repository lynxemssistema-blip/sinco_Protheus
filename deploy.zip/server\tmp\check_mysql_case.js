require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/linux-deployment/server/.env' });
const mysql = require('mysql2/promise');

async function checkCasing() {
    const pool = mysql.createPool({
        host: process.env.MYSQL_HOST,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASS,
        database: process.env.MYSQL_DB
    });

    try {
        console.log('--- EXACT TABLE NAMES IN DATABASE ---');
        const [rows] = await pool.query('SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_SCHEMA = ?', [process.env.MYSQL_DB]);
        rows.forEach(r => console.log(`- ${r.TABLE_NAME}`));

        console.log('\n--- COLUMN NAMES IN sistema_avisos ---');
        try {
            const [cols] = await pool.query('SHOW COLUMNS FROM sistema_avisos');
            cols.forEach(c => console.log(`- ${c.Field}`));
        } catch (e) {
            console.log('Failed to read sistema_avisos:', e.message);
        }

        process.exit(0);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
}

checkCasing();
