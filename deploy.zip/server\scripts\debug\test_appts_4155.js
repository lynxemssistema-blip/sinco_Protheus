const { Pool } = require('pg');
const pool = new Pool({ 
  user: 'sinco2', 
  host: '192.168.1.61', 
  password: 'sinco25', 
  database: 'p12prd', 
  port: 5432 
});
const mysqlPool = require('./services/mysqlService');

async function test() {
    const sql = `
        SELECT
            btrim(c2.c2_num) as op,
            btrim(c2.c2_pedido) as pedido,
            btrim(c2.c2_produto) as produto,
            c2.c2_quant as qtd_plan
        FROM sc2010 c2
        WHERE TRIM(c2.c2_pedido) LIKE '%4155%' AND COALESCE(c2.d_e_l_e_t_, '') = ''
    `;
    const res = await pool.query(sql);
    
    const opNumbers = [...new Set(res.rows.map(r => r.op))];
    console.log("OPs count:", opNumbers.length);
    
    if (opNumbers.length > 0) {
        const placeholders = opNumbers.map(() => '?').join(',');
        const apptsSql = `
            SELECT 
                op_numero, 
                operacao_codigo, 
                SUM(quantidade) as total_produzido
            FROM app_production_appointments
            WHERE op_numero IN (${placeholders}) AND status != 'CANCELADO'
            GROUP BY op_numero, operacao_codigo
        `;
        const [apptsRows] = await mysqlPool.query(apptsSql, opNumbers);
        console.log("\nAppointments:");
        console.table(apptsRows.slice(0, 20));
    }
    
    process.exit(0);
}

test().catch(e => { console.error(e); process.exit(1); });
