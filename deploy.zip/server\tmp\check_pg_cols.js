require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/server/.env' });
const { Pool } = require('pg');

async function checkPgSchema() {
    const pool = new Pool({
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        user: process.env.DB_USER,
        password: process.env.DB_PASS,
        database: process.env.DB_NAME,
    });

    try {
        console.log('--- COLUMNS IN public.sf2010 ---');
        const res = await pool.query(`
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_schema = 'public' 
              AND table_name = 'sf2010'
            ORDER BY column_name
        `);
        res.rows.forEach(r => {
            if (r.column_name.toLowerCase().includes('nat')) {
                console.log(`- ${r.column_name}`);
            }
        });

        if (res.rows.length === 0) {
            console.log('No columns found or table does not exist.');
        }

        await pool.end();
    } catch (err) {
        console.error('Error connecting to PG:', err.message);
    }
}

checkPgSchema();
