const axios = require('axios');

async function testBadPassword() {
    try {
        const res = await axios.post('http://localhost:3001/api/auth/login', {
            login: 'Edson',
            senha: 'edsonmetal'
        });
        console.log("✅ OK!", res.data);
    } catch(e) {
        if (e.response) {
            console.log("❌ ERRO HTTP:", e.response.status, e.response.data);
        } else {
            console.log("❌ ERRO NO REQUEST:", e.message);
        }
    }
}

testBadPassword();
