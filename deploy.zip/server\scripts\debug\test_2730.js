const db = require('./db');
async function run() {
    try {
        const res = await db.query(`
            SELECT 
                c6_num, 
                c6_item, 
                c6_produto, 
                c6_qtdven, 
                c6_qtdent, 
                (c6_qtdven - c6_qtdent) as saldo, 
                c6_entreg, 
                c6_datapcp 
            FROM public.sc6010 
            WHERE c6_num LIKE '%2730%' 
            AND COALESCE(d_e_l_e_t_, '') IN ('', ' ')
        `);
        console.log(res.rows);
    } catch (e) {
        console.error(e);
    } finally {
        process.exit(0);
    }
}
run();
