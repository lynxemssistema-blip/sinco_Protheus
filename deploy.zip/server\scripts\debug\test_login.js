const mysql = require('mysql2/promise');
require('dotenv').config();

async function checkUser() {
    const connection = await mysql.createConnection({
        host: process.env.MYSQL_HOST,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASS,
        database: process.env.MYSQL_DB,
        port: 3306
    });

    const [rows] = await connection.execute('SELECT Login, Senha FROM usuario WHERE Login LIKE "edson";');
    console.log("edson query:", rows);
    const [rows2] = await connection.execute('SELECT Login, Senha FROM usuario WHERE Login LIKE "cdson";');
    console.log("cdson query:", rows2);

    await connection.end();
}

checkUser().catch(console.error);
