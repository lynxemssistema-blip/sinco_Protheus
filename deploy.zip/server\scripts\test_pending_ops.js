require('dotenv').config({ path: '../.env' });
const db = require('../db');

async function testQuery() {
    const query = `
        WITH ParentOPs AS (
            SELECT 
                c2.c2_num,
                c2.c2_pedido,
                c2.c2_obs,
                c2.c2_itempv
            FROM sc2010 c2
            WHERE c2.c2_sequen = '001'
            AND COALESCE(c2.D_E_L_E_T_, '') = ''
        )
        SELECT 
            TRIM(SC2.C2_NUM) AS c2_num,
            TRIM(SC2.C2_ITEM) AS c2_item,
            TRIM(SC2.C2_SEQUEN) AS c2_sequen,
            TRIM(SC2.C2_PRODUTO) AS c2_produto,
            SB1.B1_DESC AS descricao,
            SC2.C2_QUANT AS c2_quant,
            SC2.C2_DATPRI AS c2_datpri,
            TRIM(COALESCE(parent.c2_pedido, SC2.C2_PEDIDO)) AS pedido,
            TRIM(COALESCE(parent.c2_itempv, SC2.C2_ITEMPV)) AS item_pedido,
            SA1.A1_NOME AS cliente,
            TRIM(SC6.C6_PEDCLI) AS pedcli,
            SC6.C6_ENTREG AS c6_entreg,
            ((COALESCE(SC6.C6_QTDVEN, 0) - COALESCE(SC6.C6_QTDENT, 0))) AS qtd_saldo_faturar
        FROM sc2010 SC2
        LEFT JOIN ParentOPs parent ON parent.c2_num = SC2.C2_NUM
        LEFT JOIN sc6010 SC6 
            ON TRIM(parent.c2_pedido) = TRIM(SC6.C6_NUM) 
            AND parent.c2_itempv = SC6.C6_ITEM
            AND COALESCE(SC6.D_E_L_E_T_, '') = ''
        LEFT JOIN sc5010 SC5
            ON SC5.C5_NUM = TRIM(parent.c2_pedido)
            AND COALESCE(SC5.D_E_L_E_T_, '') = ''
        LEFT JOIN sa1010 SA1 
            ON SA1.A1_COD = SC5.C5_CLIENTE 
            AND SA1.A1_LOJA = SC5.C5_LOJACLI
            AND COALESCE(SA1.D_E_L_E_T_, '') = ''
        LEFT JOIN sb1010 SB1 
            ON SC2.C2_PRODUTO = SB1.B1_COD 
            AND COALESCE(SB1.D_E_L_E_T_, '') = ''
        WHERE COALESCE(SC2.D_E_L_E_T_, '') = ''
        AND SC2.C2_DATPRI >= '20240101'
        AND SC2.C2_QUANT > SC2.C2_QUJE
        ORDER BY SC2.C2_DATPRI DESC
        LIMIT 10
    `;

    try {
        const res = await db.query(query);
        console.log('Query sucesso. Rows:', res.rows.length);
        console.log(res.rows[0]);
    } catch (e) {
        console.error('Query falhou:', e.message);
    } finally {
        process.exit();
    }
}

testQuery();
