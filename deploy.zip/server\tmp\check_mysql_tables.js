require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/server/.env' });
const mysql = require('mysql2/promise');

async function checkMysqlTables() {
    const config = {
        host: process.env.MYSQL_HOST,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASS,
        database: process.env.MYSQL_DB
    };

    try {
        const connection = await mysql.createConnection(config);
        console.log('--- CHECKING MYSQL TABLES ---');

        const tables = ['produtos_docs', 'app_pcp_delivery_forecasts', 'app_sales_order_item_notes'];
        for (const t of tables) {
            const [rows] = await connection.query(`SHOW TABLES LIKE ?`, [t]);
            if (rows.length > 0) {
                console.log(`✅ Table ${t} exists.`);
                const [cols] = await connection.query(`DESCRIBE ${t}`);
                console.log(`Columns for ${t}:`, cols.map(c => c.Field).join(', '));
            } else {
                console.log(`❌ Table ${t} DOES NOT EXIST.`);
            }
        }

        await connection.end();
    } catch (err) {
        console.error('MySQL Error:', err.message);
    }
}

checkMysqlTables();
