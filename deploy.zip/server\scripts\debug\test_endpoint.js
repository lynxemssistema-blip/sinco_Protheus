const axios = require('axios');
async function run() {
    try {
        const res = await axios.get('http://localhost:3002/api/pedidos/op-mirror/003954?item=01');
        console.log(JSON.stringify(res.data, null, 2).substring(0, 500));
    } catch(err) {
        console.error(err.response?.data || err.message);
    }
}
run();
