require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/server/.env' });
const router = require('../routes/pedidos');

// Mock req and res
const req = {
    query: {
        pedido: '2730',
        only_active: 'true',
        page: '1',
        limit: '50',
        debug: 'true'
    }
};

const res = {
    json: (data) => {
        console.log('✅ Success! Data received.');
        console.log('Sample Item Count:', data.data?.length);
        console.log('First Item Snippet:', JSON.stringify(data.data?.[0], null, 2).substring(0, 300));
        process.exit(0);
    },
    status: (code) => {
        console.log('❌ Error Status:', code);
        return {
            json: (data) => {
                console.error('Error Body:', JSON.stringify(data, null, 2));
                process.exit(1);
            }
        };
    }
};

// Find the handler for GET /flat
const flatLayer = router.stack.find(s => s.route && s.route.path === '/flat');
if (flatLayer) {
    flatLayer.route.stack[0].handle(req, res, (err) => {
        if (err) {
            console.error('❌ Router Error:', err);
            process.exit(1);
        }
    });
} else {
    console.error('❌ Route /flat not found in router.');
    process.exit(1);
}
