const axios = require('axios');
const https = require('https');

const httpsAgent = new https.Agent({ rejectUnauthorized: false });

async function run() {
    try {
        const tokenUrl = 'https://192.168.1.60:47500/tlpp/oauth2/token?grant_type=password&username=sinco&password=Metal1120';
        const tokenRes = await axios.get(tokenUrl, { httpsAgent, timeout: 10000 });
        const accessToken = tokenRes.data.access_token;
        console.log("Token obtained");

        const ordensProducao = [
            {
              "EMPRESA": "01",
              "CFILANT": "0101",
              "NOPER": 3,
              "C2_NUM": "004546",
              "C2_ITEM": "01",
              "C2_PRODUTO": "MT3-14331",
              "C2_QUANT": 3,
              "C2_DATPRI": "20260428",
              "C2_DATPRF": "20260428",
              "C2_OBS": "",
              "C2_ROTEIRO": "00",
              "C2_PEDIDO": "004546",
              "C2_ITEMPV": "01"
            }
        ];

        const payload = { data: { ordensProducao } };

        const protheusRes = await axios.post(
            'https://192.168.1.60:47500/ordem-producao/incluir',
            payload,
            { headers: { 'Authorization': `Bearer ${accessToken}` }, httpsAgent, timeout: 60000 }
        );

        console.log('📬 Resposta Protheus →', JSON.stringify(protheusRes.data, null, 2));
    } catch (err) {
        console.error('Error:', err.response ? JSON.stringify(err.response.data, null, 2) : err.message);
    }
}
run();
