require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/server/.env' });
const mysqlPool = require('C:/Users/adm/Desktop/MetalFisa Anty/server/services/mysqlService');

async function testHistory(id) {
    try {
        console.log(`--- TESTING HISTORY FOR USER ${id} ---`);
        const query = `
            SELECT a.*, 
                   ur.NomeCompleto as remetenteNome, 
                   ud.NomeCompleto as destinatarioNome,
                   g.nome as grupoNome
            FROM sistema_avisos a
            JOIN usuario ur ON a.idRemetente = ur.idUsuario
            LEFT JOIN usuario ud ON a.idDestinatario = ud.idUsuario
            LEFT JOIN sistema_avisos_grupos g ON a.idGrupo = g.idGrupo
            WHERE a.idRemetente = ? 
               OR a.idDestinatario = ? 
               OR (a.idGrupo IS NOT NULL AND a.idGrupo IN (SELECT idGrupo FROM sistema_avisos_grupos_membros WHERE idUsuario = ?))
            ORDER BY a.data_envio DESC
        `;
        const [rows] = await mysqlPool.query(query, [id, id, id]);
        console.log(`Found ${rows.length} messages.`);
        if (rows.length > 0) {
            console.table(rows.slice(0, 5));
        }

        process.exit(0);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
}

testHistory(11); // Testing with Saulo
