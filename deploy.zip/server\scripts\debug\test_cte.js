require('dotenv').config();
const db = require('./db');
const { getInactiveOrdersFilter } = require('./util/pedidoFilterHelper');

async function testCTE() {
    const getInactiveFilter = await getInactiveOrdersFilter();
    const inactiveSql = getInactiveFilter('pl.c2_pedido');
    
    const conditions = ["COALESCE(pl.d_e_l_e_t_, ' ') = ' '", "COALESCE(pl.c2_quant, 0) > COALESCE(pl.c2_quje, 0)"];
    if (inactiveSql) conditions.push(inactiveSql.replace(/^\s*AND\s+/i, ''));

    // Client filter using IN
    conditions.push(`
        pl.c2_pedido IN (
            SELECT sc5.c5_num FROM sc5010 sc5
            JOIN sa1010 sa1 ON sa1.a1_cod = sc5.c5_cliente AND sa1.a1_loja = sc5.c5_lojacli
            WHERE UPPER(sa1.a1_nome) LIKE '%VMI%'
              AND COALESCE(sa1.d_e_l_e_t_, ' ') = ' '
              AND COALESCE(sc5.d_e_l_e_t_, ' ') = ' '
        )
    `);

    const query = `
        WITH FilteredOPs AS MATERIALIZED (
            SELECT 
                RTRIM(pl.c2_num)       AS op,
                RTRIM(pl.c2_item)      AS item_op,
                pl.c2_itempv           AS itempv_raw,
                RTRIM(pl.c2_sequen)    AS sequen,
                pl.c2_pedido           AS pedido_venda_raw,
                RTRIM(pl.c2_pedido)    AS pedido_venda,
                pl.c2_produto          AS produto_raw,
                RTRIM(pl.c2_produto)   AS cod_produto_op,
                COALESCE(pl.c2_quant, 0) AS qtd_total,
                COALESCE(pl.c2_quje, 0)  AS qtd_realizada_header
            FROM sc2010 pl
            WHERE ${conditions.join(' AND ')}
        )
        SELECT 
            f.*,
            RTRIM(sb1.b1_desc)     AS desc_produto,
            RTRIM(sa1.a1_nome)     AS nome_cliente,
            RTRIM(sc6.c6_pedcli)   AS ped_cliente,
            RTRIM(sc6.c6_entreg)   AS prazo_entrega_pedido,
            RTRIM(sg2.g2_recurso)  AS recurso,
            RTRIM(sg2.g2_descri)   AS desc_operacao,
            RTRIM(sg2.g2_operac)   AS operacao
        FROM FilteredOPs f
        LEFT JOIN sb1010 sb1
            ON sb1.b1_cod = f.produto_raw
           AND COALESCE(sb1.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sc5010 sc5
            ON sc5.c5_num = f.pedido_venda_raw
           AND COALESCE(sc5.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sc6010 sc6
            ON sc6.c6_num = f.pedido_venda_raw
           AND sc6.c6_item = f.itempv_raw
           AND COALESCE(sc6.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sa1010 sa1
            ON sa1.a1_cod = sc5.c5_cliente
           AND sa1.a1_loja = sc5.c5_lojacli
           AND COALESCE(sa1.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sg2010 sg2
            ON sg2.g2_produto = f.produto_raw
           AND COALESCE(sg2.d_e_l_e_t_, ' ') = ' '
    `;

    console.log('Running CTE query...');
    const t0 = Date.now();
    try {
        const result = await db.query(query);
        console.log(`Finished in ${Date.now() - t0}ms, returned ${result.rows.length} rows`);
    } catch (e) {
        console.error('Error:', e);
    }
    process.exit();
}
testCTE();
