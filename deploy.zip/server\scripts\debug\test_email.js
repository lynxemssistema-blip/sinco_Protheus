const nodemailer = require('nodemailer');

const SMTP_CONFIG = {
    host: 'smtp.task.com.br',
    port: 587,
    secure: false, // 587 geralmente usa STARTTLS
    auth: {
        user: 'sincometal@metalfisa.com.br',
        pass: 'Pro1042@sm'
    },
    tls: {
        rejectUnauthorized: false
    }
};

async function testEmail() {
    const transporter = nodemailer.createTransport(SMTP_CONFIG);
    try {
        console.log('🔄 Conectando ao SMTP Task Hostings (Porta 587)...');
        const info = await transporter.sendMail({
            from: '"MetalFisa ERP" <sincometal@metalfisa.com.br>',
            to: 'edsonmanoel2012@gmail.com',
            subject: 'Teste de Integração - Módulo de E-mail Metalfisa ERP',
            html: `
                <div style="font-family: Arial, sans-serif; padding: 20px; color: #333;">
                    <h2 style="color: #0284c7;">Olá, Edson! 👋</h2>
                    <p>Se você está lendo esta mensagem, significa que o novo <strong>Módulo Interno de E-mail (SMTP)</strong> do Sistema ERP Integrado Metalfisa foi homologado com sucesso!</p>
                    <p>A partir de agora, o ERP possui comunicação direta de disparo usando a conta <b>sincometal@metalfisa.com.br</b>.</p>
                    <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;" />
                    <p style="font-size: 12px; color: #888;">Enviado automaticamente via Node.js - Task Hostings Server (Port: 587)</p>
                </div>
            `
        });
        console.log('✅ E-mail enviado com sucesso! MessageID:', info.messageId);
    } catch (err) {
        console.error('❌ Falha ao enviar:', err.message);
    }
}
testEmail();
