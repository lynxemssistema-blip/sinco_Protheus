const mysql = require('mysql2/promise');
const { Pool } = require('pg');
require('dotenv').config();

const mysqlPool = mysql.createPool({
    host: process.env.MYSQL_HOST,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASS,
    database: process.env.MYSQL_DB
});

const pgPool = new Pool({
    host: process.env.PGHOST,
    user: process.env.PGUSER,
    password: process.env.PGPASSWORD,
    database: process.env.PGDATABASE,
    port: process.env.PGPORT
});

async function run() {
    try {
        console.log("Adicionando coluna caso não exista...");
        try {
            await mysqlPool.query("ALTER TABLE app_faturamento_solicitacao_itens ADD COLUMN nome_cliente VARCHAR(255) NULL");
            console.log("Coluna nome_cliente adicionada com sucesso!");
        } catch(e) {
            console.log("Coluna possivelmente já existe ou erro: " + e.message);
        }

        const [rows] = await mysqlPool.query("SELECT id, pedido, item, codigo_produto, nome_cliente FROM app_faturamento_solicitacao_itens WHERE nome_cliente IS NULL OR nome_cliente = '' OR nome_cliente = '-' ");
        console.log(`Encontrados ${rows.length} registros sem nome_cliente.`);

        let updated = 0;
        let notFound = [];

        for (const r of rows) {
            const pedidoStr = String(r.pedido).trim();
            const pedidoPadded = pedidoStr.padStart(6, '0');

            let cliName = null;
            
            const { rows: cliRow } = await pgPool.query(`
                SELECT TRIM(sa1.a1_nome) as nome_cliente 
                FROM public.sc5010 c5
                JOIN public.sa1010 sa1 ON sa1.a1_cod = c5.c5_cliente AND sa1.a1_loja = c5.c5_lojacli AND COALESCE(sa1.d_e_l_e_t_, '') = ''
                WHERE (TRIM(c5.c5_num) = $1 OR TRIM(c5.c5_num) = $2) AND COALESCE(c5.d_e_l_e_t_, '') = ''
                LIMIT 1
            `, [pedidoStr, pedidoPadded]);

            if (cliRow.length > 0) {
                cliName = cliRow[0].nome_cliente;
            } else {
                notFound.push(r.pedido);
            }

            if (cliName) {
                await mysqlPool.query("UPDATE app_faturamento_solicitacao_itens SET nome_cliente = ? WHERE id = ?", [cliName, r.id]);
                console.log(`[SUCESSO] Pedido ${r.pedido} atualizado: ${cliName}`);
                updated++;
            }
        }
        
        console.log(`Processo finalizado. Atualizados: ${updated}. Não econtrados no Protheus (tabela c5): ${[...new Set(notFound)]}`);
        process.exit(0);

    } catch (err) {
        console.error('Erro:', err);
        process.exit(1);
    }
}

run();
