const db = require('../db'); // Postgres
const mysqlPool = require('../services/mysqlService'); // MySQL

async function syncUnits() {
    try {
        console.log('🚀 [SYNC] Iniciando sincronização real de unidades...');

        // 1. Buscar todos os registros do Sinco
        const [mysqlRows] = await mysqlPool.execute(`
            SELECT IdMaterial, CodMatFabricante, Unidade 
            FROM material 
            WHERE CodMatFabricante IS NOT NULL AND CodMatFabricante != ''
        `);
        console.log(`📊 Total de registros no Sinco: ${mysqlRows.length}`);

        // 2. Buscar mestre do Protheus
        const protheusQuery = `
            SELECT TRIM(b1_cod) as codigo, TRIM(b1_um) as unidade_protheus
            FROM sb1010
            WHERE COALESCE(d_e_l_e_t_, '') = ''
        `;
        const pgRes = await db.query(protheusQuery);
        const protheusMap = {};
        pgRes.rows.forEach(r => {
            protheusMap[r.codigo] = r.unidade_protheus;
        });
        console.log(`📊 Total de produtos no Protheus: ${pgRes.rows.length}`);

        // 3. Processar atualizações
        let atualizados = 0;
        let erros = 0;

        console.log('⏳ Atualizando registros...');

        for (const row of mysqlRows) {
            const codigo = row.CodMatFabricante.trim();
            const protheusUnit = protheusMap[codigo];

            if (protheusUnit && protheusUnit !== row.Unidade) {
                try {
                    await mysqlPool.execute(
                        'UPDATE material SET Unidade = ? WHERE IdMaterial = ?',
                        [protheusUnit, row.IdMaterial]
                    );
                    atualizados++;
                    if (atualizados % 100 === 0) {
                        console.log(`✅ ${atualizados} itens atualizados...`);
                    }
                } catch (updateErr) {
                    console.error(`❌ Erro ao atualizar item ${codigo}:`, updateErr.message);
                    erros++;
                }
            }
        }

        console.log('\n====================================================');
        console.log('🎉 Sincronização concluída!');
        console.log(`📊 Total atualizados: ${atualizados}`);
        console.log(`📊 Erros: ${erros}`);
        console.log('====================================================');

    } catch (err) {
        console.error("❌ Erro fatal durante a sincronização:", err);
    } finally {
        process.exit();
    }
}

syncUnits();
