const mysql = require('mysql2/promise');
require('dotenv').config();

const dbConfig = {
    host: process.env.MYSQL_HOST,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASS,
    database: process.env.MYSQL_DB,
    port: 3306
};

async function testSaldo() {
    let connection;
    try {
        console.log('Connecting to', dbConfig.host, 'as', dbConfig.user);
        connection = await mysql.createConnection(dbConfig);
        console.log('Connected!');

        const [rows] = await connection.execute(`
            SELECT 
                SUM(CASE WHEN tipo = 'E' THEN quantidade ELSE 0 END) -
                SUM(CASE WHEN tipo = 'S' THEN quantidade ELSE 0 END) as saldo
            FROM app_estoque_movimentos 
            WHERE produto_codigo = ?
        `, ['MPT-2785']);

        console.log('Result:', rows);
    } catch (err) {
        console.error('Error:', err);
    } finally {
        if (connection) await connection.end();
    }
}

testSaldo();
