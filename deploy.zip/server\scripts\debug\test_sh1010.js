const db = require('./db');

async function test() {
    try {
        const query = `
            SELECT
                c2.c2_num     AS op,
                g2.g2_operac  AS operacao,
                g2.g2_recurso AS recurso,
                TRIM(h1.h1_descri) AS desc_recurso
            FROM public.sc2010 c2
            LEFT JOIN public.sg2010 g2 ON btrim(g2.g2_produto) = btrim(c2.c2_produto) AND COALESCE(g2.d_e_l_e_t_, '') IN ('', ' ')
            LEFT JOIN public.sh1010 h1 ON btrim(h1.h1_codigo) = btrim(g2.g2_recurso) AND COALESCE(h1.d_e_l_e_t_, '') IN ('', ' ')
            WHERE c2.c2_num = '004155'
            LIMIT 5
        `;
        const r = await db.query(query);
        console.log('SUCCESS', r.rows);
    } catch (e) {
        console.error('ERROR:', e.message);
    }
    process.exit(0);
}

test();
