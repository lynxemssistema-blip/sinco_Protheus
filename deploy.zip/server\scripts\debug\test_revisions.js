const http = require('http');

const options = {
  hostname: 'localhost',
  port: 3001,
  path: '/api/romaneios/8006/revisions',
  headers: {
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MzcsImxvZ2luIjoiRWRzb24iLCJub21lIjoiRWRzb24gTWFub2VsIiwidGlwbyI6IkEiLCJpYXQiOjE3NzM4MzY0MTgsImV4cCI6MTc3Mzg2NTIxOH0.6c5CyBi0obYLSliadgQF50Aa6cQ-f8CSM1gNogLEmkg'
  }
};

http.get(options, (res) => {
  let data = '';
  res.on('data', (chunk) => data += chunk);
  res.on('end', () => console.log(res.statusCode, data));
});
