require('dotenv').config();
const mysqlPool = require('./services/mysqlService');

async function testDelete() {
    try {
        // Try to delete ID 1041 (pedido 004619, item 50)
        console.log("Attempting to delete ID 1041...");
        const [result] = await mysqlPool.query('DELETE FROM app_pcp_delivery_forecasts WHERE id = ?', [1041]);
        console.log("Delete result:", result);
    } catch (e) {
        console.error("Delete failed:", e.message);
    }
    process.exit(0);
}
testDelete();
