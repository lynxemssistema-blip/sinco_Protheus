const mysqlPool = require('../services/mysqlService');

async function main() {
    try {
        const [rows] = await mysqlPool.execute(`
            SELECT CodProdutoPai, CodMatFabricante, nivel 
            FROM produto_estrutura_item 
            WHERE CodProdutoPai = 'MT3-14719.asm' 
            ORDER BY nivel
        `);
        console.table(rows);
    } catch (err) { }
    process.exit();
}
main();
