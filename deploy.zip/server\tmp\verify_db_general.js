require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/server/.env' });
const mysqlPool = require('C:/Users/adm/Desktop/MetalFisa Anty/server/services/mysqlService');

async function verifyDB() {
    try {
        console.log('--- Verifying MySQL Connectivity ---');
        const [rows] = await mysqlPool.query('SELECT 1 + 1 AS result');
        console.log('MySQL Query Result:', rows[0].result === 2 ? 'OK' : 'FAILED');

        console.log('\n--- Verifying Essential Tables ---');
        const tables = ['usuario', 'sistema_avisos', 'pcpmetal_agentes', 'pedidos'];
        for (const table of tables) {
            try {
                const [result] = await mysqlPool.query(`SELECT COUNT(*) as count FROM ${table}`);
                console.log(`Table '${table}': ${result[0].count} records`);
            } catch (e) {
                console.log(`Table '${table}': MISSING OR ERROR (${e.message})`);
            }
        }
        process.exit(0);
    } catch (err) {
        console.error('CRITICAL DATABASE ERROR:', err.message);
        process.exit(1);
    }
}

verifyDB();
