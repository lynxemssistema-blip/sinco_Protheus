const axios = require('axios');
const https = require('https');
const httpsAgent = new https.Agent({ rejectUnauthorized: false });

async function run() {
  let accessToken = '';
  try {
      const tokenRes = await axios.get('https://192.168.1.60:47500/tlpp/oauth2/token?grant_type=password&username=sinco&password=Metal1120', { httpsAgent, timeout: 10000 });
      accessToken = tokenRes.data.access_token;
  } catch (e) {
      console.error(e);
      return;
  }
  
  const payload = {
    "data": {
      "ordensProducao": [
        {
          "EMPRESA": "01",
          "CFILANT": "01",
          "NOPER": 3,
          "C2_NUM": "000001",
          "C2_ITEM": "06",
          "C2_PRODUTO": "MT6-7544",
          "C2_QUANT": 1,
          "C2_DATPRI": "20260430",
          "C2_DATPRF": "20260430",
          "C2_OBS": "",
          "C2_ROTEIRO": "01",
          "C2_PEDIDO": "004546",
          "C2_ITEMPV": "06"
        }
      ]
    }
  };

  try {
      const res = await axios.post('https://192.168.1.60:47500/ordem-producao/incluir', payload, {
          headers: { 'Authorization': `Bearer ${accessToken}` },
          httpsAgent
      });
      console.log(JSON.stringify(res.data, null, 2));
  } catch (err) {
      console.error("ERRO", err.response?.data || err.message);
  }
}
run();
