const db = require('../db');

async function testFast() {
    try {
        console.time("Query");
        const query = `
            WITH active_c6 AS (
                SELECT c6.c6_produto, c6.c6_item, c5.c5_num, c6.c6_xrevm, c6.c6_xrevc
                FROM public.sc5010 c5
                JOIN public.sc6010 c6
                    ON c6.c6_filial = c5.c5_filial
                    AND c6.c6_num   = c5.c5_num
                    AND COALESCE(c6.d_e_l_e_t_, '') = ''
                WHERE COALESCE(c5.d_e_l_e_t_, '') = ''
                  AND c5.c5_tipo <> 'B'
                  AND ((c6.c6_qtdven - c6.c6_qtdent) > 0 OR c6.c6_qtdlib > 0)
            )
            SELECT
                COUNT(*)::integer AS total,
                CASE
                    WHEN sb1.b1_msblql IN ('1','S','T','Y') OR sz0_agg.cod IS NOT NULL THEN 'Restrição'
                    WHEN COALESCE(c6.c6_xrevm, '') <> COALESCE(c6.c6_xrevc, '') THEN 'Revisão'
                    WHEN sg1_agg.cod IS NULL AND sg2_agg.cod IS NULL THEN 'Novo'
                    WHEN c2_agg.pedido IS NOT NULL THEN 'PCP (Com OP)'
                    ELSE 'PCP (Sem OP) - Urgente Liberação'
                END AS status_tipo_item
            FROM active_c6 c6
            LEFT JOIN public.sb1010 sb1
                ON sb1.b1_cod = c6.c6_produto
                AND COALESCE(sb1.d_e_l_e_t_, '') = ''
            LEFT JOIN (
                SELECT DISTINCT TRIM(z0_produto) AS cod FROM public.sz0010 WHERE COALESCE(d_e_l_e_t_, '') <> '*' AND z0_status = 'P'
            ) sz0_agg ON sz0_agg.cod = TRIM(c6.c6_produto)
            LEFT JOIN (
                SELECT DISTINCT TRIM(g1_cod) AS cod FROM public.sg1010 WHERE COALESCE(d_e_l_e_t_, '') <> '*'
            ) sg1_agg ON sg1_agg.cod = TRIM(c6.c6_produto)
            LEFT JOIN (
                SELECT DISTINCT TRIM(g2_produto) AS cod FROM public.sg2010 WHERE COALESCE(d_e_l_e_t_, '') <> '*'
            ) sg2_agg ON sg2_agg.cod = TRIM(c6.c6_produto)
            LEFT JOIN (
                SELECT DISTINCT TRIM(c2_pedido) AS pedido, TRIM(c2_itempv) AS item FROM public.sc2010 WHERE COALESCE(d_e_l_e_t_, '') = ''
            ) c2_agg ON c2_agg.pedido = TRIM(c6.c5_num) AND c2_agg.item = TRIM(c6.c6_item)
            GROUP BY 2
        `;
        const result = await db.query(query);
        console.timeEnd("Query");
        console.log(result.rows);
        process.exit(0);
    } catch (e) {
        console.error("ERROR:");
        console.error(e.message);
        process.exit(1);
    }
}
testFast();
