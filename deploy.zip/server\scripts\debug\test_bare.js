require('dotenv').config();
const db = require('./db');
const { getInactiveOrdersFilter } = require('./util/pedidoFilterHelper');

async function testBare() {
    const getInactiveFilter = await getInactiveOrdersFilter();
    const inactiveSql = getInactiveFilter('pl.c2_pedido');
    
    const conditions = ["COALESCE(pl.d_e_l_e_t_, ' ') = ' '", "COALESCE(pl.c2_quant, 0) > COALESCE(pl.c2_quje, 0)"];
    if (inactiveSql) conditions.push(inactiveSql.replace(/^\s*AND\s+/i, ''));

    const params = [];
    const cliente = 'vmi';
    if (cliente) {
        conditions.push(`
        pl.c2_pedido IN (
            SELECT sc5.c5_num FROM sc5010 sc5
            JOIN sa1010 sa1 ON sa1.a1_cod = sc5.c5_cliente AND sa1.a1_loja = sc5.c5_lojacli
            WHERE UPPER(sa1.a1_nome) LIKE '%VMI%'
              AND COALESCE(sa1.d_e_l_e_t_, ' ') = ' '
              AND COALESCE(sc5.d_e_l_e_t_, ' ') = ' '
        )
        `);
    }

    const opsQuery = `
        SELECT
            RTRIM(pl.c2_num)       AS op,
            RTRIM(pl.c2_item)      AS item_op,
            RTRIM(pl.c2_sequen)    AS sequen,
            pl.c2_pedido           AS pedido_venda_raw,
            RTRIM(pl.c2_pedido)    AS pedido_venda,
            pl.c2_produto          AS produto_raw,
            RTRIM(pl.c2_produto)   AS cod_produto_op,
            pl.c2_itempv           AS itempv_raw,
            COALESCE(pl.c2_quant, 0) AS qtd_total,
            COALESCE(pl.c2_quje, 0)  AS qtd_realizada_header
        FROM sc2010 pl
        WHERE ${conditions.join(' AND ')}
    `;

    console.log('Running BARE query...');
    const t0 = Date.now();
    try {
        const result = await db.query(opsQuery);
        console.log(`BARE Query finished in ${Date.now() - t0}ms, returned ${result.rows.length} rows`);
    } catch (e) {
        console.error('Error:', e);
    }
    process.exit();
}
testBare();
