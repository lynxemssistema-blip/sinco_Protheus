require('dotenv').config();
const db = require('./db');
const fs = require('fs');
const { getInactiveOrdersFilter } = require('./util/pedidoFilterHelper');

async function testExplain() {
    const getInactiveFilter = await getInactiveOrdersFilter();
    const inactiveSql = getInactiveFilter('pl.c2_pedido');
    
    const conditions = ["COALESCE(pl.d_e_l_e_t_, ' ') = ' '", "COALESCE(pl.c2_quant, 0) > COALESCE(pl.c2_quje, 0)"];
    if (inactiveSql) conditions.push(inactiveSql.replace(/^\s*AND\s+/i, ''));

    const query = `
        EXPLAIN 
        SELECT
            RTRIM(pl.c2_num)       AS op,
            RTRIM(pl.c2_item)      AS item_op,
            RTRIM(pl.c2_sequen)    AS sequen,
            RTRIM(pl.c2_pedido)    AS pedido_venda,
            RTRIM(sc6.c6_pedcli)   AS ped_cliente,
            RTRIM(pl.c2_produto)   AS cod_produto_op,
            RTRIM(sb1.b1_desc)     AS desc_produto,
            RTRIM(sa1.a1_nome)     AS nome_cliente,
            RTRIM(sc6.c6_entreg)   AS prazo_entrega_pedido,
            COALESCE(pl.c2_quant, 0) AS qtd_total,
            COALESCE(pl.c2_quje, 0)  AS qtd_realizada_header,
            RTRIM(sg2.g2_recurso)  AS recurso,
            RTRIM(sg2.g2_descri)   AS desc_operacao,
            RTRIM(sg2.g2_operac)   AS operacao
        FROM sc2010 pl
        LEFT JOIN sb1010 sb1
            ON RTRIM(sb1.b1_cod) = RTRIM(pl.c2_produto)
           AND COALESCE(sb1.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sc5010 sc5
            ON RTRIM(sc5.c5_num) = RTRIM(pl.c2_pedido)
           AND COALESCE(sc5.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sc6010 sc6
            ON RTRIM(sc6.c6_num) = RTRIM(pl.c2_pedido)
           AND sc6.c6_item = pl.c2_itempv
           AND COALESCE(sc6.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sa1010 sa1
            ON RTRIM(sa1.a1_cod) = RTRIM(sc5.c5_cliente)
           AND sa1.a1_loja = sc5.c5_lojacli
           AND COALESCE(sa1.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sg2010 sg2
            ON RTRIM(sg2.g2_produto) = RTRIM(pl.c2_produto)
           AND COALESCE(sg2.d_e_l_e_t_, ' ') = ' '
        WHERE ${conditions.join(' AND ')}
          AND UPPER(sa1.a1_nome) LIKE '%VMI%'
    `;

    try {
        const result = await db.query(query);
        fs.writeFileSync('explain_output.txt', result.rows.map(r => r['QUERY PLAN']).join('\n'));
    } catch (e) {
        console.error(e);
    }
    process.exit();
}
testExplain();
