const mysql = require('mysql2/promise');
require('dotenv').config({ path: './.env' });

async function run() {
    try {
        const pool = mysql.createPool({
            host: process.env.MYSQL_HOST,
            user: process.env.MYSQL_USER,
            password: process.env.MYSQL_PASS,
            database: process.env.MYSQL_DB
        });

        const query = `
            SELECT 
                i.id as item_id,
                COALESCE(SUM(rec.quantidade), 0) as quantidade_recebida,
                MAX(rec.data_recebimento) as data_ultimo_recebimento,
                SUBSTRING_INDEX(GROUP_CONCAT(rec.usuario ORDER BY rec.data_recebimento DESC SEPARATOR '|'), '|', 1) as ultimo_usuario
            FROM app_romaneio_items i
            LEFT JOIN app_romaneio_recebimentos rec ON i.id = rec.romaneio_item_id
            WHERE i.romaneio_id = 11
            GROUP BY i.id
        `;

        const [rows] = await pool.query(query);
        console.log(JSON.stringify(rows, null, 2));
        process.exit(0);
    } catch (e) {
        console.error(e);
        process.exit(1);
    }
}
run();
