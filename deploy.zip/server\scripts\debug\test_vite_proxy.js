const axios = require('axios');

async function testProxy() {
    try {
        const res = await axios.post('http://localhost:5174/api/auth/login', {
            login: 'Edson',
            senha: 'edsonmetal'
        }, {
            headers: {
                "Accept": "application/json, text/plain, */*",
                "Content-Type": "application/json"
            }
        });
        console.log("✅ PROXY OK!", res.status);
    } catch(e) {
        if (e.response) {
            console.log("❌ ERRO PROXY HTTP:", e.response.status, e.response.data);
        } else {
            console.log("❌ ERRO PROXY MSG:", e.message);
        }
    }
}

testProxy();
