const axios = require('axios');
const https = require('https');

const httpsAgent = new https.Agent({ rejectUnauthorized: false });

async function run() {
    try {
        const tokenUrl = 'https://192.168.1.60:47500/tlpp/oauth2/token?grant_type=password&username=sinco&password=Metal1120';
        const tokenRes = await axios.get(tokenUrl, { httpsAgent, timeout: 10000 });
        const accessToken = tokenRes.data.access_token;
        console.log("Token obtained");

        const testCases = [
            {
                name: "1. NOPER as string",
                payload: { data: { ordensProducao: [ { "EMPRESA": "01", "CFILANT": "01", "NOPER": "3", "C2_NUM": "004546", "C2_ITEM": "01", "C2_PRODUTO": "MT3-14331", "C2_QUANT": 3, "C2_DATPRI": "20260428", "C2_DATPRF": "20260428", "C2_OBS": "", "C2_ROTEIRO": "01", "C2_PEDIDO": "004546", "C2_ITEMPV": "01" } ] } }
            },
            {
                name: "2. Missing EMPRESA/CFILANT",
                payload: { data: { ordensProducao: [ { "NOPER": 3, "C2_NUM": "004546", "C2_ITEM": "01", "C2_PRODUTO": "MT3-14331", "C2_QUANT": 3, "C2_DATPRI": "20260428", "C2_DATPRF": "20260428", "C2_OBS": "", "C2_ROTEIRO": "01", "C2_PEDIDO": "004546", "C2_ITEMPV": "01" } ] } }
            },
            {
                name: "3. Root EMPRESA/CFILANT",
                payload: { data: { EMPRESA: "01", CFILANT: "01", ordensProducao: [ { "NOPER": 3, "C2_NUM": "004546", "C2_ITEM": "01", "C2_PRODUTO": "MT3-14331", "C2_QUANT": 3, "C2_DATPRI": "20260428", "C2_DATPRF": "20260428", "C2_OBS": "", "C2_ROTEIRO": "01", "C2_PEDIDO": "004546", "C2_ITEMPV": "01" } ] } }
            },
            {
                name: "4. Lowercase keys",
                payload: { data: { ordensProducao: [ { "empresa": "01", "cfilant": "01", "noper": 3, "c2_num": "004546", "c2_item": "01", "c2_produto": "MT3-14331", "c2_quant": 3, "c2_datpri": "20260428", "c2_datprf": "20260428", "c2_obs": "", "c2_roteiro": "01", "c2_pedido": "004546", "c2_itempv": "01" } ] } }
            },
            {
                name: "5. EMPRESA 01 CFILANT 0101",
                payload: { data: { ordensProducao: [ { "EMPRESA": "01", "CFILANT": "0101", "NOPER": 3, "C2_NUM": "004546", "C2_ITEM": "01", "C2_PRODUTO": "MT3-14331", "C2_QUANT": 3, "C2_DATPRI": "20260428", "C2_DATPRF": "20260428", "C2_OBS": "", "C2_ROTEIRO": "01", "C2_PEDIDO": "004546", "C2_ITEMPV": "01" } ] } }
            }
        ];

        for (const tc of testCases) {
            console.log(`\nTesting: ${tc.name}`);
            try {
                const protheusRes = await axios.post(
                    'https://192.168.1.60:47500/ordem-producao/incluir',
                    tc.payload,
                    { headers: { 'Authorization': `Bearer ${accessToken}` }, httpsAgent, timeout: 60000 }
                );
                console.log('Result:', JSON.stringify(protheusRes.data));
            } catch (err) {
                console.log('Error:', err.response ? JSON.stringify(err.response.data) : err.message);
            }
        }

    } catch (err) {
        console.error('Fatal Error:', err.message);
    }
}
run();
