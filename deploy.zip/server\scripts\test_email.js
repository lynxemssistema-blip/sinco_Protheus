const nodemailer = require('nodemailer');
const SMTP_CONFIG = {
    host: 'smtp.task.com.br',
    port: 587,
    secure: false,
    auth: { user: 'sincometal@metalfisa.com.br', pass: 'Pro1042@sm' },
    tls: { rejectUnauthorized: false }
};
const transporter = nodemailer.createTransport(SMTP_CONFIG);
transporter.sendMail({
    from: '"MetalFisa ERP" <sincometal@metalfisa.com.br>',
    to: 'edsonmanoel2012@gmail.com',
    subject: '⚠️ ERRO NO SISTEMA - Teste de Integração (Antigravity)',
    html: '<div style="padding: 20px; font-family: Arial, sans-serif; border: 1px solid #ccc; max-width: 600px;"><h2 style="color: #e63946;">Teste de Integração de Log de Erro</h2><p>Olá, Edson.</p><p>Este é um e-mail de teste disparado pelo Antigravity para confirmar que a configuração de e-mail e o serviço SMTP estão funcionando corretamente para a nova funcionalidade de reporte de logs (sem bloqueio de permissão).</p><p>Se você recebeu esta mensagem, o sistema está pronto para produção!</p><hr><small style="color: #666;">Sistema ERP MetalFisa - Mensagem Automática</small></div>'
}).then(info => console.log('Email enviado com sucesso!', info.messageId)).catch(err => console.error('Falha ao enviar:', err));
