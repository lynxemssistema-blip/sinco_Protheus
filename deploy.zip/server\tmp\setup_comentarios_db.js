const mysqlPool = require('../services/mysqlService');

async function setupDB() {
    try {
        console.log('🔄 Criando tabela sinco_comentarios_engenharia...');
        await mysqlPool.execute(`
            CREATE TABLE IF NOT EXISTS sinco_comentarios_engenharia (
                id INT AUTO_INCREMENT PRIMARY KEY,
                CodMatFabricante VARCHAR(100) NOT NULL,
                ProdutoPai VARCHAR(100) NOT NULL,
                Nivel INT NOT NULL,
                UsuarioCriacao VARCHAR(100) NOT NULL,
                Comentario TEXT NOT NULL,
                Status VARCHAR(50) DEFAULT 'ABERTO', 
                ObservacaoProjetista TEXT,
                UsuarioResolucao VARCHAR(100),
                DataResolucao DATETIME,
                DataCriacao DATETIME DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        `);
        console.log('✅ Tabela sinco_comentarios_engenharia criada ou já existente.');
    } catch (error) {
        console.error('❌ Erro ao criar tabela:', error);
    } finally {
        process.exit();
    }
}

setupDB();
