const mysqlPool = require('../services/mysqlService');
const db = require('../db');

async function testCascata(op_numero, op_item, op_sequencia, quantidade_pai) {
    try {
        console.log(`\n=== INICIANDO TESTE CASCATA PARA OP ${op_numero} ===`);
        
        // 1. Get parent product
        const pgRes = await db.query(
            `SELECT TRIM(c2_produto) as produto_pai 
             FROM sc2010 
             WHERE c2_num = $1 AND c2_item = $2 AND c2_sequen = $3
             AND COALESCE(d_e_l_e_t_, '') IN ('', ' ')`,
            [op_numero, op_item, op_sequencia]
        );
        
        if (pgRes.rows.length === 0) {
            console.log("Produto pai nao encontrado na SC2010");
            return;
        }
        
        const produtoPai = pgRes.rows[0].produto_pai;
        console.log(`Produto Pai: ${produtoPai}`);
        
        // 2. Explode BOM
        const bomRes = await db.query(`
            WITH RECURSIVE bom_tree AS (
                SELECT 
                    TRIM(g1.g1_cod) AS pai,
                    TRIM(g1.g1_comp) AS componente,
                    g1.g1_quant::numeric AS qtde_necessaria,
                    1 AS nivel,
                    ARRAY[TRIM(g1.g1_comp)] as path
                FROM public.sg1010 g1
                WHERE TRIM(g1.g1_cod) = $1 AND COALESCE(g1.d_e_l_e_t_, '') IN ('', ' ')
                
                UNION ALL
                
                SELECT 
                    TRIM(g1.g1_cod),
                    TRIM(g1.g1_comp),
                    (bt.qtde_necessaria * g1.g1_quant::numeric)::numeric,
                    bt.nivel + 1,
                    bt.path || TRIM(g1.g1_comp)
                FROM public.sg1010 g1
                INNER JOIN bom_tree bt ON TRIM(g1.g1_cod) = bt.componente
                WHERE COALESCE(g1.d_e_l_e_t_, '') IN ('', ' ')
                AND NOT (TRIM(g1.g1_comp) = ANY(bt.path))
            )
            SELECT componente, qtde_necessaria, nivel FROM bom_tree ORDER BY nivel;
        `, [produtoPai]);
        
        console.log(`Componentes na Estrutura (${bomRes.rows.length}):`);
        
        for (const row of bomRes.rows) {
            const qtdRequeridaTotal = row.qtde_necessaria * quantidade_pai;
            console.log(`- Nivel ${row.nivel}: ${row.componente} | Qtd P/1: ${row.qtde_necessaria} | Total Requerido: ${qtdRequeridaTotal}`);
            
            // 3. Find in SC2010 / SG2010
            const opRes = await db.query(`
                SELECT 
                    TRIM(c2.c2_item) as item_op, 
                    TRIM(c2.c2_sequen) as sequen_op,
                    TRIM(g2.g2_operac) as operacao
                FROM public.sc2010 c2
                LEFT JOIN public.sg2010 g2 ON btrim(g2.g2_produto) = btrim(c2.c2_produto) AND COALESCE(g2.d_e_l_e_t_, '') IN ('', ' ')
                WHERE c2.c2_num = $1 AND TRIM(c2.c2_produto) = $2
                AND COALESCE(c2.d_e_l_e_t_, '') IN ('', ' ')
            `, [op_numero, row.componente]);
            
            if (opRes.rows.length === 0) {
                console.log(`  -> Não encontrado na SC2010 para a OP ${op_numero}`);
                continue;
            }
            
            for (const opRow of opRes.rows) {
                if (!opRow.operacao) {
                    console.log(`  -> Sem roteiro (SG2010) para item ${opRow.item_op} seq ${opRow.sequen_op}`);
                    continue;
                }
                
                // 4. Check appointed quantity in MySQL
                const [appRows] = await mysqlPool.execute(`
                    SELECT COALESCE(SUM(quantidade), 0) as total_apontado
                    FROM app_production_appointments
                    WHERE op_numero = ? AND op_item = ? AND op_sequencia = ? AND operacao_codigo = ?
                `, [op_numero, opRow.item_op, opRow.sequen_op, opRow.operacao]);
                
                const apontado = Number(appRows[0].total_apontado);
                const faltante = qtdRequeridaTotal - apontado;
                
                console.log(`  -> Op: ${opRow.operacao} | Apontado: ${apontado} | Faltante: ${faltante}`);
                if (faltante > 0) {
                    console.log(`     *** INSERIR APONTAMENTO DE ${faltante} ***`);
                }
            }
        }
        
    } catch (err) {
        console.error(err);
    } finally {
        process.exit(0);
    }
}

// Find a recent OP to test
async function findOp() {
    const res = await db.query(`SELECT TRIM(c2_num) as num, TRIM(c2_item) as item, TRIM(c2_sequen) as seq FROM sc2010 WHERE COALESCE(d_e_l_e_t_,'')='' ORDER BY c2_emissao DESC LIMIT 1`);
    if(res.rows.length > 0) {
        await testCascata(res.rows[0].num, res.rows[0].item, res.rows[0].seq, 10);
    } else {
        process.exit(0);
    }
}
findOp();
