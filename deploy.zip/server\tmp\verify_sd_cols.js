require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/server/.env' });
const { Pool } = require('pg');

async function listSdCols() {
    const pool = new Pool({
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        user: process.env.DB_USER,
        password: process.env.DB_PASS,
        database: process.env.DB_NAME,
    });

    try {
        const t = 'sd2010';
        console.log(`--- SAMPLE COLUMNS FOR ${t} ---`);
        const res = await pool.query(`
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name = $1
            LIMIT 200
        `, [t]);
        const cols = res.rows.map(r => r.column_name);
        console.log('d2_cf exists:', cols.includes('d2_cf'));
        console.log('d2_doc exists:', cols.includes('d2_doc'));
        console.log('d2_serie exists:', cols.includes('d2_serie'));
        console.log('d2_itempv exists:', cols.includes('d2_itempv'));
        console.log('d2_pedido exists:', cols.includes('d2_pedido'));

        await pool.end();
    } catch (err) {
        console.error('Error:', err.message);
    }
}

listSdCols();
