const { Pool } = require('pg');

const db = new Pool({
  host: '192.168.1.61',
  port: 5432,
  user: 'sinco2',
  password: 'sinco25',
  database: 'p12prd',
});

async function run() {
  const todayStr = '20260507';
  const todosRecursos = ['MO0001', 'MO0002', 'MO0003', 'MO0004'];

  try {
    const start = Date.now();
    
    // Stage 1: Get OPs for the day
    const res1 = await db.query(`
        SELECT 
            TRIM(c2_num) AS op_numero, 
            TRIM(c2_item) AS op_item, 
            TRIM(c2_sequen) AS op_sequencia, 
            TRIM(c2_produto) AS produto, 
            c2_quant::numeric AS qtd_planejada
        FROM sc2010
        WHERE c2_datprf = $1 AND COALESCE(d_e_l_e_t_, ' ') = ' '
    `, [todayStr]);
    
    const ops = res1.rows;
    console.log(`Found ${ops.length} OPs planned for today. Stage 1 time: ${Date.now() - start}ms`);
    
    if (ops.length === 0) return;
    
    const produtos = [...new Set(ops.map(o => o.produto))];
    console.log(`Unique products: ${produtos.length}`);

    const start2 = Date.now();
    // Stage 2: Get routings for these products on the specific resources
    const res2 = await db.query(`
        SELECT 
            TRIM(g2_produto) AS produto,
            TRIM(g2_operac) AS operacao_codigo,
            TRIM(g2_descri) AS operacao_nome,
            TRIM(g2_recurso) AS recurso
        FROM sg2010
        WHERE TRIM(g2_produto) = ANY($1)
          AND TRIM(g2_recurso) = ANY($2)
          AND COALESCE(d_e_l_e_t_, ' ') = ' '
    `, [produtos, todosRecursos]);
    
    const routings = res2.rows;
    console.log(`Found ${routings.length} routings. Stage 2 time: ${Date.now() - start2}ms`);
    
    // Merge them in JS
    const result = [];
    for (const op of ops) {
        const productRoutings = routings.filter(r => r.produto === op.produto);
        for (const pr of productRoutings) {
            result.push({
                ...op,
                operacao_codigo: pr.operacao_codigo,
                operacao_nome: pr.operacao_nome,
                recurso: pr.recurso
            });
        }
    }
    
    console.log(`Final result length: ${result.length}. Total time: ${Date.now() - start}ms`);

  } catch(e) {
    console.error(e);
  } finally {
    db.end();
  }
}

run();
