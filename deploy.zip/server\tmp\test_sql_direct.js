require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/server/.env' });
const { Pool } = require('pg');

async function testSqlDirectly() {
    const pool = new Pool({
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        user: process.env.DB_USER,
        password: process.env.DB_PASS,
        database: process.env.DB_NAME,
    });

    try {
        console.log('--- Testing Corrected FLAT Query ---');
        // Simplified version of the flat query focusing on the problematic part
        const query = `
            SELECT
                TRIM(c5.c5_num) as pedido,
                (
                    SELECT json_agg(
                        json_build_object(
                            'nota', TRIM(d2.d2_doc),
                            'serie', TRIM(d2.d2_serie),
                            'emissao', TO_CHAR(TO_DATE(NULLIF(TRIM(f2.f2_emissao), ''), 'YYYYMMDD'), 'DD/MM/YY'),
                            'natureza', '',
                            'cfop', TRIM(d2.d2_cf),
                            'qtd', d2.d2_quant::numeric(18,2),
                            'valor_unit', d2.d2_prunit::numeric(18,2),
                            'valor_total', d2.d2_total::numeric(18,2),
                            'valor_icms', d2.d2_valicm::numeric(18,2),
                            'valor_ipi', d2.d2_valipi::numeric(18,2),
                            'valor_frete', d2.d2_valfre::numeric(18,2),
                            'peso_bruto', f2.f2_pbruto::numeric(18,2),
                            'peso_liquido', f2.f2_pliqui::numeric(18,2),
                            'transporte', TRIM(f2.f2_transp)
                        )
                    )
                    FROM public.sd2010 d2
                    JOIN public.sf2010 f2 
                        ON f2.f2_doc = d2.d2_doc 
                        AND f2.f2_serie = d2.d2_serie 
                        AND COALESCE(f2.d_e_l_e_t_, '') = ''
                    WHERE d2.d2_pedido = c5.c5_num 
                      AND d2.d2_itempv = c6.c6_item 
                      AND COALESCE(d2.d_e_l_e_t_, '') = ''
                ) AS notas_fiscais
            FROM public.sc5010 c5
            JOIN public.sc6010 c6 
                ON COALESCE(c6.d_e_l_e_t_, '') = ''
                AND c6.c6_filial = c5.c5_filial
                AND c6.c6_num = c5.c5_num
            LIMIT 1
        `;

        const res = await pool.query(query);
        console.log('✅ Query executed successfully!');
        if (res.rows.length > 0) {
            console.log('Result:', JSON.stringify(res.rows[0], null, 2));
        }

        await pool.end();
        process.exit(0);
    } catch (err) {
        console.error('❌ Query failed!');
        console.error(err.message);
        process.exit(1);
    }
}

testSqlDirectly();
