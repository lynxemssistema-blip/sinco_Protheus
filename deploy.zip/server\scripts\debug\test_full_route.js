const db = require('./db');
const mysqlPool = require('./services/mysqlService');

async function testRoute() {
    try {
        const id = '004543';

        const query = `
            SELECT
                TRIM(c5.c5_num)     AS pedido,
                TRIM(c5.c5_cliente) AS cod_cliente,
                TRIM(c5.c5_lojacli) AS loja_cliente,
                TRIM(c6.c6_item)    AS item,
                TRIM(c6.c6_produto) AS codigo,
                TRIM(c6.c6_xrevm) AS rev_codigo,
                TRIM(c6.c6_xrevc) AS c6_rev_cliente,
                sb1.b1_desc   AS descricao,
                c6.c6_um      AS unidade,
                COALESCE(c6.c6_qtdven, 0)::numeric(18,6)  AS quantidade,
                TO_CHAR(TO_DATE(NULLIF(TRIM(c6.c6_entreg), ''), 'YYYYMMDD'), 'DD/MM/YY') AS entrega,
                TRIM(c6.c6_pedcli) AS ped_cliente,
                TRIM(c2.c2_num) || TRIM(c2.c2_item) || TRIM(c2.c2_sequen) AS op_num,
                c2.c2_quant   AS op_qtd,
                COALESCE(c6.c6_qtdent, 0)::numeric(18,6) AS qtd_entreg,
                (COALESCE(c6.c6_qtdven, 0) - COALESCE(c6.c6_qtdent, 0))::numeric(18,6) AS qtd_faturar,
                CASE
                    WHEN sb1.b1_msblql IN ('1','S','T','Y') OR sz0_chk.ok IS NOT NULL THEN 'Restrição'
                    WHEN COALESCE(c6.c6_xrevm, '') <> COALESCE(c6.c6_xrevc, '') THEN 'Revisão'
                    WHEN sg1_chk.ok IS NULL AND sg2_chk.ok IS NULL THEN 'Novo'
                    ELSE 'PCP'
                END AS status_tipo_item,
                CASE
                    WHEN sb1.b1_msblql IN ('1','S','T','Y') THEN 'Produto bloqueado no cadastro (SB1 b1_msblql). Rev. MF: ' || COALESCE(TRIM(c6.c6_xrevm), '-') || ' / Rev. Cli: ' || COALESCE(TRIM(c6.c6_xrevc), '-')
                    WHEN sz0_chk.ok IS NOT NULL THEN 'Restrição pendente no cadastro (SZ0 status=P). Rev. MF: ' || COALESCE(TRIM(c6.c6_xrevm), '-') || ' / Rev. Cli: ' || COALESCE(TRIM(c6.c6_xrevc), '-')
                    WHEN COALESCE(c6.c6_xrevm, '') <> COALESCE(c6.c6_xrevc, '') THEN 'Diferença de revisão detectada. Rev. MF: ' || COALESCE(TRIM(c6.c6_xrevm), '-') || ' / Rev. Cli: ' || COALESCE(TRIM(c6.c6_xrevc), '-')
                    WHEN sg1_chk.ok IS NULL AND sg2_chk.ok IS NULL THEN 'Produto novo — sem estrutura (BOM) cadastrada no Protheus.'
                    ELSE 'Item com estrutura existente, liberado para PCP.'
                END AS status_tipo_detalhe
            FROM public.sc5010 c5
            JOIN public.sc6010 c6
                ON COALESCE(c6.d_e_l_e_t_, '') = ''
                AND c6.c6_filial = c5.c5_filial
                AND c6.c6_num = c5.c5_num
            LEFT JOIN public.sb1010 sb1
                ON COALESCE(sb1.d_e_l_e_t_, '') = ''
                AND TRIM(sb1.b1_cod) = TRIM(c6.c6_produto)
            LEFT JOIN public.sc2010 c2
                ON (c2.c2_pedido = c5.c5_num OR (TRIM(COALESCE(c2.c2_pedido, '')) = '' AND c2.c2_obs LIKE c5.c5_num || '%'))
                AND c2.c2_itempv = c6.c6_item
                AND COALESCE(c2.d_e_l_e_t_, '') = ''
            LEFT JOIN LATERAL (
                SELECT 1 as ok FROM public.sz0010
                WHERE TRIM(z0_produto) = TRIM(c6.c6_produto)
                AND COALESCE(d_e_l_e_t_, '') <> '*' AND z0_status = 'P' LIMIT 1
            ) sz0_chk ON true
            LEFT JOIN LATERAL (
                SELECT 1 as ok FROM public.sg1010
                WHERE TRIM(g1_cod) = TRIM(c6.c6_produto)
                AND COALESCE(d_e_l_e_t_, '') <> '*' LIMIT 1
            ) sg1_chk ON true
            LEFT JOIN LATERAL (
                SELECT 1 as ok FROM public.sg2010
                WHERE TRIM(g2_produto) = TRIM(c6.c6_produto)
                AND COALESCE(d_e_l_e_t_, '') <> '*' LIMIT 1
            ) sg2_chk ON true
            WHERE c5.c5_num = $1
            AND COALESCE(c5.d_e_l_e_t_, '') = ''
            AND c5.c5_tipo <> 'B'
            ORDER BY c6.c6_item ASC
        `;

        const result = await db.query(query, [id]);

        // Parallel Enrichment: Notes + Docs + NFs + Ref/Rev cliente
        const items = result.rows;
        if (items.length > 0) {
            const productCodes = [...new Set(items.map(i => i.codigo).filter(c => c))];
            const codCliente = items[0]?.cod_cliente;
            const lojaCliente = items[0]?.loja_cliente;

            const [notesResult, docsResult, nfResult, sz1Result] = await Promise.allSettled([
                mysqlPool.query('SELECT * FROM app_sales_order_item_notes WHERE pedido = ?', [id]),
                (async () => {
                    if (productCodes.length === 0) return {};
                    const placeholders = productCodes.map(() => '?').join(',');
                    const [docsRows] = await mysqlPool.execute(
                        `SELECT TRIM(produto_codigo) as produto_codigo, url_arquivo, tipo FROM produtos_docs WHERE produto_codigo IN (${placeholders})`,
                        productCodes
                    );
                    const docsMap = {};
                    docsRows.forEach(row => {
                        if (!docsMap[row.produto_codigo]) docsMap[row.produto_codigo] = [];
                        docsMap[row.produto_codigo].push(row);
                    });
                    return docsMap;
                })(),
                db.query(`
                    SELECT d2.d2_itempv as item,
                        TRIM(d2.d2_doc) as nota, TRIM(d2.d2_serie) as serie,
                        TO_CHAR(TO_DATE(NULLIF(TRIM(f2.f2_emissao), ''), 'YYYYMMDD'), 'DD/MM/YY') as emissao,
                        '' as natureza, TRIM(d2.d2_cf) as cfop,
                        d2.d2_quant::numeric(18,2) as qtd, d2.d2_prunit::numeric(18,2) as valor_unit,
                        d2.d2_total::numeric(18,2) as valor_total, d2.d2_valicm::numeric(18,2) as valor_icms,
                        d2.d2_valipi::numeric(18,2) as valor_ipi, d2.d2_valfre::numeric(18,2) as valor_frete,
                        f2.f2_pbruto::numeric(18,2) as peso_bruto, f2.f2_pliqui::numeric(18,2) as peso_liquido,
                        TRIM(f2.f2_transp) as transporte
                    FROM public.sd2010 d2
                    JOIN public.sf2010 f2 ON f2.f2_doc = d2.d2_doc AND f2.f2_serie = d2.d2_serie AND COALESCE(f2.d_e_l_e_t_, '') = ''
                    WHERE d2.d2_pedido = $1 AND COALESCE(d2.d_e_l_e_t_, '') = ''
                `, [id]),
                codCliente ? db.query(`
                    SELECT TRIM(z1.z1_produto) as produto,
                        STRING_AGG(DISTINCT TRIM(z1.z1_codcli), ' / ') as ref_cliente,
                        STRING_AGG(DISTINCT TRIM(z1.z1_revisao), ' / ') as rev_cliente
                    FROM public.sz1010 z1
                    WHERE z1.z1_cliente = $1 AND z1.z1_loja = $2
                    AND TRIM(z1.z1_produto) = ANY($3)
                    AND COALESCE(z1.d_e_l_e_t_, '') = ''
                    GROUP BY TRIM(z1.z1_produto)
                `, [codCliente, lojaCliente, productCodes]) : Promise.resolve({ rows: [] })
            ]);

            try {
                const [forecasts] = await mysqlPool.query(`
                        SELECT f1.*, TRIM(f1.item) as item_trim
                        FROM app_pcp_delivery_forecasts f1
                        INNER JOIN (
                            SELECT pedido, item, MAX(id) as max_id
                            FROM app_pcp_delivery_forecasts
                            WHERE TRIM(pedido) = ?
                            GROUP BY pedido, item
                        ) f2 ON f1.id = f2.max_id
                    `, [id]);
            } catch (err) {
                console.error('Error merging PCP forecasts:', err);
            }
        }
        console.log("SUCCESS!");
    } catch (err) {
        console.error(`Erro SQL ao buscar itens pedido 004543: `, err.message);
        console.error("FULL ERROR:", err);
    } finally {
        process.exit();
    }
}
testRoute();
