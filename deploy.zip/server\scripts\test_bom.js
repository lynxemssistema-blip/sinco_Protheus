const { Client } = require('pg');

async function run() {
    const db = new Client({ 
        user: 'postgres', 
        host: '192.168.1.61', 
        database: 'p12prd', 
        password: 'pgsql', 
        port: 5432, 
        statement_timeout: 30000, 
        query_timeout: 30000 
    });
    
    await db.connect();
    
    const query = `
        SELECT C2.C2_NUM AS "OP", C2.C2_PRODUTO AS "Produto_Final", G1.G1_COMP AS "Cod_Componente", B1_COMP.B1_DESC AS "Descricao_Componente", G1.G1_QUANT AS "Qtd_Por_Unidade", (G1.G1_QUANT * C2.C2_QUANT) AS "Total_Necessario", B1_COMP.B1_UM AS "UM" 
        FROM SC2010 C2 
        INNER JOIN SG1010 G1 ON TRIM(G1.G1_COD) = TRIM(C2.C2_PRODUTO) AND COALESCE(G1.D_E_L_E_T_, '') = '' 
        INNER JOIN SB1010 B1_COMP ON TRIM(B1_COMP.B1_COD) = TRIM(G1.G1_COMP) AND COALESCE(B1_COMP.D_E_L_E_T_, '') = '' 
        WHERE TRIM(C2.C2_PEDIDO) = '003731' AND COALESCE(C2.D_E_L_E_T_, '') = '' 
        ORDER BY C2.C2_NUM, G1.G1_COMP;
    `;
    
    const res = await db.query(query);
    console.log(res.rows.length, 'rows');
    console.log(res.rows.slice(0, 5));
    
    await db.end();
}

run().catch(console.error);
