const axios = require('axios');
const https = require('https');

async function run() {
    try {
        const httpsAgent = new https.Agent({ rejectUnauthorized: false });
        
        let accessToken = '';
        const tokenUrl = 'https://192.168.1.60:47500/tlpp/oauth2/token?grant_type=password&username=sinco&password=Metal1120';
        const tokenRes = await axios.get(tokenUrl, { httpsAgent, timeout: 10000 });
        accessToken = tokenRes.data.access_token;
        
        const ordensProducao = [{
            EMPRESA:   "01",
            CFILANT:   "01",
            NOPER:     3,
            C2_NUM:    "999999",
            C2_ITEM:   "01",
            C2_PRODUTO: "MT2-2587       ",
            C2_QUANT:  1,
            C2_DATPRI: "20260506",
            C2_DATPRF: "20260506",
            C2_OBS:    "Teste",
            C2_ROTEIRO: "01",
            C2_PEDIDO: "003954",
            C2_ITEMPV: "01"
        }];

        const payload = { data: { ordensProducao } };

        const protheusRes = await axios.post(
            'https://192.168.1.60:47500/ordem-producao/incluir',
            payload,
            { headers: { 'Authorization': `Bearer ${accessToken}` }, httpsAgent, timeout: 60000 }
        );

        console.log("Response:", JSON.stringify(protheusRes.data, null, 2));

    } catch (error) {
        console.error("Error:", error.response ? JSON.stringify(error.response.data, null, 2) : error.message);
    }
}
run();
