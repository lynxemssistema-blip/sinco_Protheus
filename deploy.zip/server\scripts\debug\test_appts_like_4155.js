const mysqlPool = require('./services/mysqlService');

async function test() {
    const apptsSql = `
        SELECT 
            op_numero, 
            operacao_codigo, 
            SUM(quantidade) as total_produzido
        FROM app_production_appointments
        WHERE op_numero LIKE '%4155%'
        GROUP BY op_numero, operacao_codigo
    `;
    const [apptsRows] = await mysqlPool.query(apptsSql);
    console.log("\nAppointments:");
    console.table(apptsRows.slice(0, 50));
    
    process.exit(0);
}

test().catch(e => { console.error(e); process.exit(1); });
