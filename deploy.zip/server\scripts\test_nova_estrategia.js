require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.PGHOST, port: process.env.PGPORT,
  user: process.env.PGUSER, password: process.env.PGPASSWORD,
  database: process.env.PGDATABASE,
  statement_timeout: 30000
});

async function test() {
  const RECURSO = 'MO0013';
  const PRODUTO = 'MT4-17997';
  console.log(`\n🔍 NOVA ESTRATÉGIA — recurso=${RECURSO}  produto=${PRODUTO}\n`);

  // ETAPA 1: sg2010 filtrada por recurso (pequena, rápida)
  let t = Date.now();
  const sg = await pool.query(`
    SELECT TRIM(g2.g2_produto) AS produto, TRIM(g2.g2_operac) AS operacao_codigo,
           TRIM(g2.g2_recurso) AS recurso_codigo, TRIM(h1.h1_descri) AS operacao_desc
    FROM public.sg2010 g2
    LEFT JOIN public.sh1010 h1 ON TRIM(h1.h1_codigo) = TRIM(g2.g2_recurso)
      AND COALESCE(h1.d_e_l_e_t_, '') IN ('', ' ')
    WHERE TRIM(g2.g2_recurso) = $1 AND COALESCE(g2.d_e_l_e_t_, '') IN ('', ' ')
  `, [RECURSO]);
  console.log(`✅ Etapa 1 (sg2010 por recurso): ${sg.rows.length} produtos em ${Date.now()-t}ms`);

  const routingMap = {};
  sg.rows.forEach(r => { if (!routingMap[r.produto]) routingMap[r.produto] = []; routingMap[r.produto].push(r); });
  const produtos = Object.keys(routingMap);
  console.log(`   Produtos do recurso: ${produtos.join(', ')}`);

  // ETAPA 2: sc2010 usando = ANY(array) — sem JOIN com sg2010
  t = Date.now();
  const sc = await pool.query(`
    SELECT TRIM(c2.c2_num) AS op, TRIM(c2.c2_item) AS item_op, TRIM(c2.c2_sequen) AS sequen_op,
           TRIM(c2.c2_produto) AS produto,
           COALESCE(NULLIF(TRIM(c2.c2_pedido),''), NULLIF(TRIM(root_op.c2_pedido),'')) AS raw_pedido,
           c2.c2_quant::numeric AS qtd_op,
           COALESCE(TRIM(c6.c6_descri), TRIM(b1.b1_desc)) AS desc_produto,
           CASE WHEN c6.c6_entreg IS NOT NULL AND c6.c6_entreg <> ''
                THEN TO_CHAR(TO_DATE(c6.c6_entreg,'YYYYMMDD'),'YYYY-MM-DD') ELSE NULL END AS data_entrega,
           TRIM(a1.a1_nome) AS nome_cliente
    FROM public.sc2010 c2
    LEFT JOIN public.sc2010 root_op ON root_op.c2_num=c2.c2_num AND root_op.c2_item=c2.c2_item
      AND root_op.c2_sequen='001' AND COALESCE(root_op.d_e_l_e_t_,'')=''
    LEFT JOIN public.sc6010 c6 ON TRIM(c6.c6_num)=COALESCE(NULLIF(TRIM(c2.c2_pedido),''),NULLIF(TRIM(root_op.c2_pedido),''))
      AND TRIM(c6.c6_item)=COALESCE(NULLIF(TRIM(c2.c2_itempv),''),NULLIF(TRIM(root_op.c2_itempv),''))
      AND COALESCE(c6.d_e_l_e_t_,'')=''
    LEFT JOIN public.sa1010 a1 ON TRIM(a1.a1_cod)=TRIM(c6.c6_cli) AND TRIM(a1.a1_loja)=TRIM(c6.c6_loja)
      AND COALESCE(a1.d_e_l_e_t_,'')=''
    LEFT JOIN public.sb1010 b1 ON TRIM(b1.b1_cod)=TRIM(c2.c2_produto) AND COALESCE(b1.d_e_l_e_t_,'')=''
    WHERE COALESCE(c2.d_e_l_e_t_,'')=''
      AND TRIM(c2.c2_produto) = ANY($1)
      AND TRIM(c2.c2_produto) ILIKE $2
    ORDER BY c6.c6_entreg ASC NULLS LAST, c2.c2_pedido, c2.c2_num
    LIMIT 200
  `, [produtos, `%${PRODUTO}%`]);
  console.log(`✅ Etapa 2 (sc2010 ANY array): ${sc.rows.length} OPs em ${Date.now()-t}ms\n`);

  sc.rows.forEach(row => {
    const route = (routingMap[row.produto] || [])[0] || {};
    console.log(`  OP: ${row.op}/${row.item_op} | Prod: ${row.produto} | Oper: ${route.operacao_codigo} | Recurso: ${route.recurso_codigo} | Qtd: ${row.qtd_op} | Pedido: ${row.raw_pedido||'—'} | Entrega: ${row.data_entrega||'—'}`);
  });

  await pool.end();
  process.exit(0);
}

test().catch(e => { console.error('ERRO:', e.message); pool.end(); process.exit(1); });
