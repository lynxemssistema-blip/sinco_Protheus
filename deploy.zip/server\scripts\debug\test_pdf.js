require('dotenv').config();
const fs = require('fs');
const { generateRomaneioBundle } = require('./services/pdfBundleService');

async function test() {
    try {
        console.log('Iniciando geração bundle para ID 8006...');
        const buffer = await generateRomaneioBundle(8006);
        fs.writeFileSync('test-out.pdf', buffer);
        console.log('Sucesso! Arquivo test-out.pdf gerado localmente.');
        process.exit(0);
    } catch (err) {
        console.error('Falhou a geração', err);
        process.exit(1);
    }
}

test();
