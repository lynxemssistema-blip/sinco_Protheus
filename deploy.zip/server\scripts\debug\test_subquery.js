require('dotenv').config();
const db = require('./db');
const fs = require('fs');

async function testSubquery() {
    const query = `
        EXPLAIN
        SELECT
            pl.c2_num AS op,
            pl.c2_item AS item_op,
            pl.c2_sequen AS sequen,
            pl.c2_pedido AS pedido_venda,
            pl.c2_produto AS cod_produto_op,
            COALESCE(pl.c2_quant, 0) AS qtd_total,
            COALESCE(pl.c2_quje, 0)  AS qtd_realizada_header
        FROM sc2010 pl
        WHERE COALESCE(pl.d_e_l_e_t_, ' ') = ' '
          AND COALESCE(pl.c2_quant, 0) > COALESCE(pl.c2_quje, 0)
          AND pl.c2_pedido IN (
              SELECT sc5.c5_num FROM sc5010 sc5
              JOIN sa1010 sa1 ON RTRIM(sa1.a1_cod) = RTRIM(sc5.c5_cliente) AND sa1.a1_loja = sc5.c5_lojacli
              WHERE UPPER(sa1.a1_nome) LIKE '%VMI%'
                AND COALESCE(sa1.d_e_l_e_t_, ' ') = ' '
                AND COALESCE(sc5.d_e_l_e_t_, ' ') = ' '
          )
    `;

    try {
        const result = await db.query(query);
        fs.writeFileSync('explain_subquery.txt', result.rows.map(r => r['QUERY PLAN']).join('\n'));
        console.log('EXPLAIN saved to explain_subquery.txt');
    } catch (e) {
        console.error(e);
    }
    process.exit();
}
testSubquery();
