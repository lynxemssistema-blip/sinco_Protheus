const pg = require('./db');

async function run() {
    try {
        const query = "SELECT TRIM(c6_numop) as op FROM public.sc6010 WHERE TRIM(c6_num) = '003954' AND c6_item='01'";
        const res = await pg.query(query);
        console.log(res.rows);
    } catch(err) {
        console.error(err);
    } finally {
        process.exit(0);
    }
}
run();
