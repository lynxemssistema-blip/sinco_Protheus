require('dotenv').config();
const db = require('./db');
const { getInactiveOrdersFilter } = require('./util/pedidoFilterHelper');

async function explainVisao() {
    const getInactiveFilter = await getInactiveOrdersFilter();
    const inactiveSql = getInactiveFilter('pl.c2_pedido');
    
    const conditions = ["COALESCE(pl.d_e_l_e_t_, ' ') = ' '"];
    if (inactiveSql) conditions.push(inactiveSql.replace(/^\s*AND\s+/i, ''));

    const params = [];
    const cliente = 'vmi';
    const apenas_pendentes = 'true';

    if (cliente) {
        params.push(`%${cliente.toUpperCase()}%`);
        conditions.push(`UPPER(sa1.a1_nome) LIKE $${params.length}`);
    }
    if (apenas_pendentes === 'true') {
        conditions.push(`COALESCE(pl.c2_quant, 0) > COALESCE(pl.c2_quje, 0)`);
    }

    const opsQuery = `
        EXPLAIN ANALYZE SELECT
            RTRIM(pl.c2_num)       AS op
        FROM sc2010 pl
        LEFT JOIN sb1010 sb1
            ON RTRIM(sb1.b1_cod) = RTRIM(pl.c2_produto)
           AND COALESCE(sb1.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sc5010 sc5
            ON RTRIM(sc5.c5_num) = RTRIM(pl.c2_pedido)
           AND COALESCE(sc5.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sc6010 sc6
            ON RTRIM(sc6.c6_num) = RTRIM(pl.c2_pedido)
           AND sc6.c6_item = pl.c2_itempv
           AND COALESCE(sc6.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sa1010 sa1
            ON RTRIM(sa1.a1_cod) = RTRIM(sc5.c5_cliente)
           AND sa1.a1_loja = sc5.c5_lojacli
           AND COALESCE(sa1.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sg2010 sg2
            ON RTRIM(sg2.g2_produto) = RTRIM(pl.c2_produto)
           AND COALESCE(sg2.d_e_l_e_t_, ' ') = ' '
        WHERE ${conditions.join(' AND ')}
    `;

    console.log('Running EXPLAIN ANALYZE...');
    try {
        const result = await db.query(opsQuery, params);
        console.log(result.rows.map(r => r['QUERY PLAN']).join('\n'));
    } catch (e) {
        console.error('Error:', e);
    }
    process.exit();
}
explainVisao();
