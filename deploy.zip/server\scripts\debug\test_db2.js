const pg = require('./db');

async function run() {
    try {
        console.log("Checking SG1 (BOM)...");
        const resG1 = await pg.query("SELECT TRIM(g1_comp) as comp FROM public.sg1010 WHERE TRIM(g1_cod) = 'MT2-2587' AND COALESCE(d_e_l_e_t_,'')=''");
        console.log("BOM:", resG1.rows);
        
        console.log("Checking SG2 (Routing)...");
        const resG2 = await pg.query("SELECT g2_codigo, TRIM(g2_operac) as seq, TRIM(g2_recurso) as rec FROM public.sg2010 WHERE TRIM(g2_produto) = 'MT2-2587' AND COALESCE(d_e_l_e_t_,'')=''");
        console.log("Routing:", resG2.rows);

    } catch(err) {
        console.error(err);
    } finally {
        process.exit(0);
    }
}
run();
