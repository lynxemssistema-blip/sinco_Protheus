const { Client } = require('pg');
const pgConfig = { host: '192.168.1.61', port: 5432, user: 'sinco2', password: 'sinco25', database: 'p12prd' };
async function run() {
    const client = new Client(pgConfig);
    await client.connect();
    try {
        const sc6 = await client.query("SELECT c6_num, c6_item, c6_produto, c6_descri, c6_qtdven FROM public.sc6010 WHERE c6_num = '002730' AND c6_item = '02' AND d_e_l_e_t_ = ' '");
        console.log('SC6 (Pedido):', sc6.rows);
        
        const sc2 = await client.query("SELECT c2_num, c2_item, c2_produto, c2_quant, c2_datpri, c2_datprf FROM public.sc2010 WHERE c2_pedido = '002730' AND c2_itempv = '02' AND d_e_l_e_t_ = ' '");
        console.log('SC2 (OP existente):', sc2.rows);
        
        // Also look up what PTG-7283 is in SB1
        const sb1 = await client.query("SELECT b1_cod, b1_desc FROM public.sb1010 WHERE b1_cod = 'PTG-7283' AND d_e_l_e_t_ = ' '");
        console.log('SB1 (PTG-7283 info):', sb1.rows);
    } catch(e) {
        console.error(e);
    } finally {
        await client.end();
    }
}
run();
