const mysqlPool = require('../services/mysqlService');

async function main() {
    try {
        console.log('--- SHOW COLUMNS FROM processos ---');
        const [ps_cols] = await mysqlPool.execute("DESCRIBE processos");
        console.log(ps_cols.map(c => c.Field).join(', '));

        console.log('--- SHOW COLUMNS FROM produto_estrutura_item ---');
        const [pe_cols] = await mysqlPool.execute("DESCRIBE produto_estrutura_item");
        console.log(pe_cols.map(c => c.Field).join(', '));

        const [ps_rows] = await mysqlPool.execute("SELECT * FROM processos LIMIT 3");
        console.log("Processos:", ps_rows);

    } catch (err) {
        console.error("Error:", err);
    } finally {
        process.exit();
    }
}
main();
