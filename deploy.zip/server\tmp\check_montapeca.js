const mysqlPool = require('../services/mysqlService');
async function main() {
    try {
        const [m_rows] = await mysqlPool.execute(`
            SELECT m.CodMatFabricante as mat_sinco, m.CodMatFabricantePeca as peca, m.PecaQtde, mat.DescResumo as material 
            FROM montapeca m 
            LEFT JOIN material mat ON m.IdMaterial = mat.IdMaterial 
            WHERE m.CodMatFabricantePeca IS NOT NULL AND m.CodMatFabricantePeca != ''
            LIMIT 5
        `);
        console.table(m_rows);
    } catch (e) {
        console.error(e);
    }
    process.exit();
}
main();
