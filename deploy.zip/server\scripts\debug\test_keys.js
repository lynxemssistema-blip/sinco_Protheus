const db = require('./db');
async function run() {
    try {
        const res = await db.query(`SELECT * FROM public.sc6010 WHERE c6_num LIKE '%2730%' LIMIT 1`);
        const keys = Object.keys(res.rows[0]);
        console.log(keys.filter(k => k.includes('data') || k.includes('dat') || k.includes('pcp')));
    } catch(e) {
        console.error(e);
    } finally {
        process.exit(0);
    }
}
run();
