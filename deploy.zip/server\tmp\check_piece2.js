const mysqlPool = require('../services/mysqlService');

async function main() {
    try {
        const pieceCode = 'MT4-24112.psm';

        console.log(`--- Materials for ${pieceCode} using IdMaterialPeca ---`);
        const [materials2] = await mysqlPool.execute(`
            SELECT mat_comp.CodMatFabricante as componentCode, 
                   mat_comp.DescResumo as componentDesc,
                   m.PecaQtde as quantity
            FROM montapeca m
            JOIN material mat_peca ON m.IdMaterialPeca = mat_peca.IdMaterial
            JOIN material mat_comp ON m.IdMaterial = mat_comp.IdMaterial
            WHERE mat_peca.CodMatFabricante = ?
        `, [pieceCode]);
        console.table(materials2);

    } catch (err) {
        console.error("Error:", err);
    } finally {
        process.exit();
    }
}
main();
