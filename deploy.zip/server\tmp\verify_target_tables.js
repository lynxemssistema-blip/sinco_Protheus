require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/server/.env' });
const { Pool } = require('pg');

async function checkSpecificTables() {
    const pool = new Pool({
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        user: process.env.DB_USER,
        password: process.env.DB_PASS,
        database: process.env.DB_NAME,
    });

    try {
        const tables = ['sc5010', 'sc6010', 'sa1010', 'sb1010', 'sd2010', 'sf2010', 'sc2010', 'sz1010'];
        console.log('--- CHECKING TABLES ---');
        for (const t of tables) {
            const res = await pool.query(`
                SELECT table_schema, table_name 
                FROM information_schema.tables 
                WHERE table_name = $1
            `, [t]);
            if (res.rows.length > 0) {
                console.log(`✅ Table ${t} exists in schema: ${res.rows[0].table_schema}`);

                // If it exists, let's list its columns to find Natureza
                if (t === 'sf2010') {
                    console.log(`Columns for ${t}:`);
                    const cols = await pool.query(`
                        SELECT column_name, data_type 
                        FROM information_schema.columns 
                        WHERE table_name = $1
                    `, [t]);
                    cols.rows.forEach(c => {
                        if (c.column_name.toLowerCase().includes('nat')) {
                            console.log(`  - ${c.column_name} (${c.data_type})`);
                        }
                    });
                }
            } else {
                console.log(`❌ Table ${t} DOES NOT EXIST`);
            }
        }

        await pool.end();
    } catch (err) {
        console.error('Error:', err.message);
    }
}

checkSpecificTables();
