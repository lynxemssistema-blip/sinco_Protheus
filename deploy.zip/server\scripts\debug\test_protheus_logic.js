const pg = require('./db');
async function run() {
    try {
        const produto = 'MT2-2587';
        const rotRows = await pg.query(
            `SELECT g2_codigo FROM public.sg2010 WHERE btrim(g2_produto) = $1 AND TRIM(COALESCE(d_e_l_e_t_, '')) = '' ORDER BY g2_codigo DESC LIMIT 1`,
            [produto]
        );
        console.log("Found:", rotRows.rows);
    } catch(err) {
        console.error(err);
    } finally {
        process.exit(0);
    }
}
run();
