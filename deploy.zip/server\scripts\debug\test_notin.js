require('dotenv').config();
const db = require('./db');
const { getInactiveOrdersFilter } = require('./util/pedidoFilterHelper');

async function testNotIn() {
    const getInactiveFilter = await getInactiveOrdersFilter();
    const inactiveSql = getInactiveFilter('pl.c2_pedido');
    
    const conditionsWith = ["COALESCE(pl.d_e_l_e_t_, ' ') = ' '", "COALESCE(pl.c2_quant, 0) > COALESCE(pl.c2_quje, 0)"];
    if (inactiveSql) conditionsWith.push(inactiveSql.replace(/^\s*AND\s+/i, ''));

    const conditionsWithout = ["COALESCE(pl.d_e_l_e_t_, ' ') = ' '", "COALESCE(pl.c2_quant, 0) > COALESCE(pl.c2_quje, 0)"];

    const buildQuery = (conds) => `
        SELECT count(*)
        FROM sc2010 pl
        LEFT JOIN sb1010 sb1
            ON RTRIM(sb1.b1_cod) = RTRIM(pl.c2_produto)
           AND COALESCE(sb1.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sc5010 sc5
            ON RTRIM(sc5.c5_num) = RTRIM(pl.c2_pedido)
           AND COALESCE(sc5.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sc6010 sc6
            ON RTRIM(sc6.c6_num) = RTRIM(pl.c2_pedido)
           AND sc6.c6_item = pl.c2_itempv
           AND COALESCE(sc6.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sa1010 sa1
            ON RTRIM(sa1.a1_cod) = RTRIM(sc5.c5_cliente)
           AND sa1.a1_loja = sc5.c5_lojacli
           AND COALESCE(sa1.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sg2010 sg2
            ON RTRIM(sg2.g2_produto) = RTRIM(pl.c2_produto)
           AND COALESCE(sg2.d_e_l_e_t_, ' ') = ' '
        WHERE ${conds.join(' AND ')}
          AND UPPER(sa1.a1_nome) LIKE '%VMI%'
    `;

    console.log('Running WITHOUT INACTIVE FILTER...');
    let t0 = Date.now();
    try {
        await db.query(buildQuery(conditionsWithout));
        console.log(`WITHOUT finished in ${Date.now() - t0}ms`);
    } catch (e) {
        console.error('Error without:', e);
    }

    console.log('Running WITH INACTIVE FILTER...');
    t0 = Date.now();
    try {
        await db.query(buildQuery(conditionsWith));
        console.log(`WITH finished in ${Date.now() - t0}ms`);
    } catch (e) {
        console.error('Error with:', e);
    }
    
    process.exit();
}
testNotIn();
