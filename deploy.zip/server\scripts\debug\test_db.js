const db = require('./services/mysqlService');

async function test() {
    try {
        const [rows] = await db.query('SELECT role, message, created_at FROM app_protheus_study_chat ORDER BY created_at DESC LIMIT 15');
        console.log(rows);
    } catch (e) {
        console.error(e);
    } finally {
        process.exit();
    }
}

test();
