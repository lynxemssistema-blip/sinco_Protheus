const db = require('./db');

async function run() {
    try {
        const query = `
            SELECT TRIM(b1_cod) as b1_cod, TRIM(b1_desc) as b1_desc
            FROM public.sb1010
            WHERE (REGEXP_REPLACE(TRIM(b1_cod), '[^a-zA-Z0-9]', '', 'g') ILIKE '%' || $1 || '%'
               OR REGEXP_REPLACE(TRIM(b1_codcli), '[^a-zA-Z0-9]', '', 'g') ILIKE '%' || $1 || '%')
            AND COALESCE(d_e_l_e_t_, '') = ''
            ORDER BY b1_cod DESC
            LIMIT 10
        `;
        const res = await db.query(query, ['212301762']);
        console.log("Success:", res.rows);
        process.exit(0);
    } catch (e) {
        console.error("DB Error:", e);
        process.exit(1);
    }
}
run();
