require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/server/.env' });
const mysqlPool = require('C:/Users/adm/Desktop/MetalFisa Anty/server/services/mysqlService');

async function check() {
    try {
        console.log('--- MESSAGE COUNTS ---');
        const [total] = await mysqlPool.query('SELECT COUNT(*) as cnt FROM sistema_avisos');
        console.log('Total messages:', total[0].cnt);

        console.log('\n--- ORPHAN REMETENTES (not in usuario) ---');
        const [orphansR] = await mysqlPool.query(`
            SELECT DISTINCT idRemetente FROM sistema_avisos 
            WHERE idRemetente NOT IN (SELECT idUsuario FROM usuario)
        `);
        console.table(orphansR);

        console.log('\n--- ORPHAN DESTINATARIOS (not in usuario and not null) ---');
        const [orphansD] = await mysqlPool.query(`
            SELECT DISTINCT idDestinatario FROM sistema_avisos 
            WHERE idDestinatario IS NOT NULL AND idDestinatario NOT IN (SELECT idUsuario FROM usuario)
        `);
        console.table(orphansD);

        console.log('\n--- SAMPLE USERS ---');
        const [users] = await mysqlPool.query('SELECT idUsuario, NomeCompleto, Login FROM usuario LIMIT 10');
        console.table(users);

        process.exit(0);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
}

check();
