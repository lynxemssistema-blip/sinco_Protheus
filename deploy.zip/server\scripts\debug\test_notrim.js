require('dotenv').config();
const db = require('./db');
const { getInactiveOrdersFilter } = require('./util/pedidoFilterHelper');

async function testNoTrim() {
    const getInactiveFilter = await getInactiveOrdersFilter();
    const inactiveSql = getInactiveFilter('pl.c2_pedido');
    
    const conditions = ["COALESCE(pl.d_e_l_e_t_, ' ') = ' '", "COALESCE(pl.c2_quant, 0) > COALESCE(pl.c2_quje, 0)"];
    if (inactiveSql) conditions.push(inactiveSql.replace(/^\s*AND\s+/i, ''));

    const params = [];
    const cliente = 'vmi';
    if (cliente) {
        params.push(`%${cliente.toUpperCase()}%`);
        conditions.push(`UPPER(sa1.a1_nome) LIKE $${params.length}`);
    }

    const opsQuery = `
        SELECT
            pl.c2_num       AS op,
            pl.c2_item      AS item_op,
            pl.c2_sequen    AS sequen,
            pl.c2_pedido    AS pedido_venda,
            sc6.c6_pedcli   AS ped_cliente,
            pl.c2_produto   AS cod_produto_op,
            sb1.b1_desc     AS desc_produto,
            sa1.a1_nome     AS nome_cliente,
            sc6.c6_entreg   AS prazo_entrega_pedido,
            pl.c2_itempv    AS itempv_raw,
            COALESCE(pl.c2_quant, 0) AS qtd_total,
            COALESCE(pl.c2_quje, 0)  AS qtd_realizada_header
        FROM sc2010 pl
        LEFT JOIN sb1010 sb1
            ON sb1.b1_cod = pl.c2_produto
           AND COALESCE(sb1.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sc5010 sc5
            ON sc5.c5_num = pl.c2_pedido
           AND COALESCE(sc5.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sc6010 sc6
            ON sc6.c6_num = pl.c2_pedido
           AND sc6.c6_item = pl.c2_itempv
           AND COALESCE(sc6.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sa1010 sa1
            ON sa1.a1_cod = sc5.c5_cliente
           AND sa1.a1_loja = sc5.c5_lojacli
           AND COALESCE(sa1.d_e_l_e_t_, ' ') = ' '
        WHERE ${conditions.join(' AND ')}
    `;

    console.log('Running query 1 WITHOUT ANY TRIM...');
    let t0 = Date.now();
    try {
        const result = await db.query(opsQuery, params);
        console.log(`Query 1 finished in ${Date.now() - t0}ms, returned ${result.rows.length} rows`);
    } catch (e) {
        console.error('Error:', e);
    }
    process.exit();
}
testNoTrim();
