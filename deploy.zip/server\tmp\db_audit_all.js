require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/server/.env' });
const { Pool } = require('pg');

async function auditAllColumns() {
    const pool = new Pool({
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        user: process.env.DB_USER,
        password: process.env.DB_PASS,
        database: process.env.DB_NAME,
    });

    const tables = {
        sc5010: ['c5_num', 'c5_filial', 'c5_cliente', 'c5_lojacli', 'c5_tipo', 'c5_emissao', 'c5_liberok', 'c5_nota', 'c5_orcres', 'd_e_l_e_t_'],
        sc6010: ['c6_num', 'c6_filial', 'c6_item', 'c6_produto', 'c6_um', 'c6_qtdven', 'c6_qtdent', 'c6_qtdlib', 'c6_entreg', 'c6_pedcli', 'd_e_l_e_t_'],
        sa1010: ['a1_cod', 'a1_loja', 'a1_nome', 'd_e_l_e_t_'],
        sb1010: ['b1_cod', 'b1_desc', 'd_e_l_e_t_'],
        sc2010: ['c2_pedido', 'c2_itempv', 'c2_num', 'c2_quant', 'd_e_l_e_t_'],
        sd2010: ['d2_doc', 'd2_serie', 'd2_pedido', 'd2_itempv', 'd2_quant', 'd2_prunit', 'd2_total', 'd2_valicm', 'd2_valipi', 'd2_valfre', 'd2_cf', 'd_e_l_e_t_'],
        sf2010: ['f2_doc', 'f2_serie', 'f2_emissao', 'f2_pbruto', 'f2_pliqui', 'f2_transp', 'd_e_l_e_t_'],
        sz1010: ['z1_cliente', 'z1_loja', 'z1_produto', 'z1_codcli', 'z1_revisao', 'd_e_l_e_t_']
    };

    try {
        console.log('--- DATABASE COLUMN AUDIT ---');
        for (const [table, columns] of Object.entries(tables)) {
            console.log(`\nChecking table: ${table}`);
            const res = await pool.query(`
                SELECT column_name 
                FROM information_schema.columns 
                WHERE table_name = $1
            `, [table]);

            const existingCols = res.rows.map(r => r.column_name.toLowerCase());

            columns.forEach(col => {
                if (existingCols.includes(col.toLowerCase())) {
                    console.log(`✅ ${col}`);
                } else {
                    console.log(`❌ ${col} (NOT FOUND)`);
                    // Find alternatives
                    const matches = existingCols.filter(c => c.includes(col.split('_')[1] || col));
                    if (matches.length > 0) {
                        console.log(`   Alternatives: ${matches.join(', ')}`);
                    }
                }
            });
        }

        await pool.end();
    } catch (err) {
        console.error('Audit Error:', err.message);
    }
}

auditAllColumns();
