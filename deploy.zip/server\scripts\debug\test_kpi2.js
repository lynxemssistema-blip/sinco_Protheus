const { Pool } = require('pg');

const db = new Pool({
  host: '192.168.1.61',
  port: 5432,
  user: 'sinco2',
  password: 'sinco25',
  database: 'p12prd',
});

async function run() {
  const todayStr = '20260507';
  const todosRecursos = ['MO0001', 'MO0002'];

  try {
    const start = Date.now();
    const pgRes = await db.query(`
        EXPLAIN ANALYZE
        SELECT DISTINCT ON (c2.c2_num, c2.c2_item, c2.c2_sequen, g2.g2_operac, g2.g2_recurso)
            TRIM(c2.c2_num)     AS op_numero,
            TRIM(c2.c2_item)    AS op_item,
            TRIM(c2.c2_sequen)  AS op_sequencia,
            TRIM(c2.c2_produto) AS produto,
            c2.c2_quant::numeric AS qtd_planejada,
            TRIM(g2.g2_operac)  AS operacao_codigo,
            TRIM(g2.g2_descri)  AS operacao_nome,
            TRIM(g2.g2_recurso) AS recurso
        FROM sc2010 c2
        JOIN sg2010 g2
            ON btrim(g2.g2_produto) = btrim(c2.c2_produto)
           AND COALESCE(g2.d_e_l_e_t_, ' ') = ' '
        WHERE btrim(g2.g2_recurso) = ANY($1)
          AND c2.c2_datprf = $2
          AND COALESCE(c2.d_e_l_e_t_, ' ') = ' '
        ORDER BY c2.c2_num, c2.c2_item, c2.c2_sequen, g2.g2_operac, g2.g2_recurso
    `, [todosRecursos, todayStr]);
    
    console.log(`Execution time: ${Date.now() - start}ms`);
    console.log(pgRes.rows.map(r => r['QUERY PLAN']).join('\n'));
  } catch(e) {
    console.error(e);
  } finally {
    db.end();
  }
}

run();
