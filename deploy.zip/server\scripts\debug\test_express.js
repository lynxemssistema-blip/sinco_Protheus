const express = require('express');
const app = express();
app.use('/api', (req, res, next) => { console.log('1', req.url); next(); });
app.use('/api', (req, res, next) => { console.log('2', req.url); next(); });
app.get('/api/users', (req, res) => res.send('OK GET'));
app.use('/api/users', (req, res) => res.send('OK USE'));
app.listen(3060, () => {
    require('http').get('http://localhost:3060/api/users', res => {
        let d = ''; res.on('data', c => d+=c); res.on('end', () => { console.log(res.statusCode, d); process.exit(0); })
    });
});
