const axios = require('axios');

async function testApi() {
    try {
        console.log('Testing /api/production...');
        const res = await axios.get('http://localhost:3001/api/production?pedido=3731&pending_delivery=false&limit=5000');
        console.log('Status:', res.status);
        console.log('Data length:', res.data.length);
        
        console.log('Testing /api/avisos/nao-concluidos/37...');
        const res2 = await axios.get('http://localhost:3001/api/avisos/nao-concluidos/37');
        console.log('Status:', res2.status);
        console.log('Data length:', res2.data.length);
    } catch (e) {
        console.error('API Error:', e.message);
        if (e.response) {
            console.error('Status:', e.response.status);
            console.error('Data:', e.response.data);
        }
    }
}
testApi();
