const mysqlPool = require('./services/mysqlService');

async function test() {
    const apptsSql = `
        SELECT *
        FROM app_production_appointments
        WHERE op_numero LIKE '%4155%'
        LIMIT 5
    `;
    const [apptsRows] = await mysqlPool.query(apptsSql);
    console.log(apptsRows);
    process.exit(0);
}

test().catch(e => { console.error(e); process.exit(1); });
