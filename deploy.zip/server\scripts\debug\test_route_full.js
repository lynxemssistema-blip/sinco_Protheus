require('dotenv').config();
const db = require('./db');
const { getInactiveOrdersFilter } = require('./util/pedidoFilterHelper');

async function testRoute() {
    const t0 = Date.now();
    const getInactiveFilter = await getInactiveOrdersFilter();
    let whereClause = "WHERE COALESCE(c5.d_e_l_e_t_, '') = '' AND c5.c5_tipo <> 'B' AND COALESCE(c6.d_e_l_e_t_, '') = ''" + getInactiveFilter('c5.c5_num');
    
    whereClause += ` AND (
        COALESCE(c5.c5_nota, '') = '' 
        OR EXISTS (
            SELECT 1 FROM public.sc6010 c6_ex 
            WHERE c6_ex.c6_num = c5.c5_num 
            AND c6_ex.c6_filial = c5.c5_filial 
            AND COALESCE(c6_ex.d_e_l_e_t_, '') = ''
            AND ((c6_ex.c6_qtdven - c6_ex.c6_qtdent) > 0 OR c6_ex.c6_qtdlib > 0)
        )
    )`;
    whereClause += ` AND ((c6.c6_qtdven - c6.c6_qtdent) > 0 OR c6.c6_qtdlib > 0)`;

    let query = `
        SELECT
            TRIM(c5.c5_num) as pedido,
            TRIM(c5.c5_cliente) as cod_cliente,
            TRIM(c5.c5_lojacli) as loja_cliente,
            NULLIF(TRIM(COALESCE(c5.c5_mennota, '') || ' ' || COALESCE(c5.c5_zobs, '') || ' ' || COALESCE(c5.c5_zobsorc, '')), '') AS observacoes_gerais,
            sa1.a1_nome as nome_cliente,
            c5.c5_emissao as emissao,
            c5.c5_orcres as orcamento,
            TRIM(c6.c6_item) as item,
            TRIM(c6.c6_produto) as codigo,
            TRIM(c6.c6_xrevm) as rev_codigo,
            TRIM(c6.c6_xrevc) as c6_rev_cliente,
            sb1.b1_desc as descricao,
            c6.c6_um as unidade,
            COALESCE(c6.c6_qtdven, 0)::numeric(18,6) as quantidade,
            COALESCE(c6.c6_qtdent, 0)::numeric(18,6) as qtd_entreg,
            (COALESCE(c6.c6_qtdven, 0) - COALESCE(c6.c6_qtdent, 0))::numeric(18,6) as qtd_faturar,
            c6.c6_prcven::numeric(18,2) as valor_unitario,
            c6.c6_valor::numeric(18,2) as valor_total,
            TRIM(COALESCE(c6.c6_entreg, '')) as entrega,
            c6.c6_pedcli as ped_cliente,
            TRIM(c2.c2_num) || TRIM(c2.c2_item) || TRIM(c2.c2_sequen) AS op_num,
            c2.c2_quant as op_qtd,
            c5.c5_liberok as status_cor
        FROM public.sc5010 c5
        JOIN public.sc6010 c6
            ON COALESCE(c6.d_e_l_e_t_, '') = ''
            AND c6.c6_filial = c5.c5_filial
            AND c6.c6_num = c5.c5_num
        LEFT JOIN public.sa1010 sa1
            ON sa1.a1_cod = c5.c5_cliente
            AND sa1.a1_loja = c5.c5_lojacli
            AND COALESCE(sa1.d_e_l_e_t_, '') = ''
        LEFT JOIN public.sb1010 sb1
            ON sb1.b1_cod = c6.c6_produto
            AND COALESCE(sb1.d_e_l_e_t_, '') = ''
        LEFT JOIN public.sc2010 c2
            ON (c2.c2_pedido = c5.c5_num )
            AND c2.c2_itempv = c6.c6_item
            AND COALESCE(c2.d_e_l_e_t_, '') = ''
        ${whereClause}
        ORDER BY c5.c5_num DESC, c6.c6_item ASC
        LIMIT 50 OFFSET 0
    `;

    const countQuery = `
        SELECT count(*) as total
        FROM public.sc5010 c5
        JOIN public.sc6010 c6
            ON COALESCE(c6.d_e_l_e_t_, '') = ''
            AND c6.c6_filial = c5.c5_filial
            AND c6.c6_num = c5.c5_num
        LEFT JOIN public.sa1010 sa1
            ON sa1.a1_cod = c5.c5_cliente
            AND sa1.a1_loja = c5.c5_lojacli
            AND COALESCE(sa1.d_e_l_e_t_, '') = ''
        ${whereClause}
    `;

    console.log('Running Queries...');
    const p1 = Date.now();
    const [result, countResult] = await Promise.all([
        db.query(query, []),
        db.query(countQuery, [])
    ]);
    console.log('Queries took:', Date.now() - p1, 'ms');
    console.log('Rows:', result.rows.length, 'Total:', countResult.rows[0].total);
    process.exit();
}
testRoute();
