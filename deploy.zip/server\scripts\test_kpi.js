const axios = require('axios');

async function testEndpoint() {
    try {
        console.time("Request");
        const response = await axios.get('http://localhost:3002/api/pedidos/kpi-faturar');
        console.timeEnd("Request");
        console.log(response.data);
    } catch (e) {
        console.error(e.response ? e.response.data : e.message);
    }
}
testEndpoint();
