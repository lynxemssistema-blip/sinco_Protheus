const pg = require('./db');

async function run() {
    try {
        const orderId = '003954';
        const itemPedido = '01'; // Try without item param first to see all items
        
        let itemCondition = "";
        let params = [orderId];
        
        if (itemPedido) {
            itemCondition = "AND c6.c6_item = $2";
            params.push(itemPedido);
        }

        const explosionQuery = `
            WITH RECURSIVE
            estrutura AS (
                -- NÍVEL 0: Itens do Pedido de Venda
                SELECT
                    TRIM(c6.c6_item) AS item_pedido,
                    0 AS nivel,
                    TRIM(c6.c6_produto) AS produto_pai,
                    TRIM(c6.c6_produto) AS componente,
                    TRIM(c6.c6_descri) AS descricao,
                    TRIM(sb1.b1_tipo) AS tipo,
                    TRIM(sb1.b1_um) AS unidade,
                    TRIM(c6.c6_xrevm) AS revisao,
                    COALESCE(c6.c6_qtdven::numeric, 0) AS qtd_necessaria,
                    TRIM(c6.c6_numop) AS op_relacionada,
                    TRIM(sc2.c2_tipo) AS op_tipo_relacionada
                FROM sc6010 c6
                LEFT JOIN sb1010 sb1
                    ON TRIM(sb1.b1_cod) = TRIM(c6.c6_produto)
                    AND COALESCE(sb1.d_e_l_e_t_, '') IN ('', ' ')
                LEFT JOIN sc2010 sc2
                    ON TRIM(sc2.c2_num) = LEFT(TRIM(c6.c6_numop), 6)
                    AND TRIM(sc2.c2_item) = SUBSTRING(TRIM(c6.c6_numop) FROM 7 FOR 2)
                    AND TRIM(sc2.c2_sequen) = SUBSTRING(TRIM(c6.c6_numop) FROM 9 FOR 3)
                    AND COALESCE(sc2.d_e_l_e_t_, '') IN ('', ' ')
                WHERE TRIM(c6.c6_num) = $1
                  AND COALESCE(c6.d_e_l_e_t_, '') IN ('', ' ')
                  ${itemCondition}

                UNION ALL

                -- NÍVEL N: Componentes da Estrutura (BOM)
                SELECT
                    e.item_pedido,
                    e.nivel + 1,
                    TRIM(sg1.g1_cod),
                    TRIM(sg1.g1_comp),
                    TRIM(sb1.b1_desc),
                    TRIM(sb1.b1_tipo),
                    TRIM(sb1.b1_um),
                    TRIM(sg1.g1_revfim),
                    (e.qtd_necessaria * COALESCE(sg1.g1_quant::numeric, 1)),
                    NULL::VARCHAR AS op_relacionada,
                    NULL::VARCHAR AS op_tipo_relacionada
                FROM estrutura e
                JOIN sg1010 sg1
                    ON TRIM(sg1.g1_cod) = e.componente
                    AND COALESCE(sg1.d_e_l_e_t_, '') IN ('', ' ')
                LEFT JOIN sb1010 sb1
                    ON TRIM(sb1.b1_cod) = TRIM(sg1.g1_comp)
                    AND COALESCE(sb1.d_e_l_e_t_, '') IN ('', ' ')
                WHERE e.nivel < 10
            ),
            pecas_distintas AS (
                SELECT DISTINCT componente FROM estrutura
            ),
            max_rev_por_produto AS (
                SELECT TRIM(g2_produto) AS produto, MAX(TRIM(g2_codigo)) AS max_codigo
                FROM sg2010
                WHERE COALESCE(d_e_l_e_t_, '') IN ('', ' ')
                  AND TRIM(g2_produto) IN (SELECT componente FROM pecas_distintas)
                GROUP BY TRIM(g2_produto)
            ),
            roteiro_agregado AS (
                SELECT
                    TRIM(g2.g2_produto) AS g2_produto_limpo,
                    json_agg(
                        json_build_object(
                            'seq',           TRIM(g2.g2_operac),
                            'recurso',       TRIM(g2.g2_recurso),
                            'desc_operacao', TRIM(h1.h1_descri),
                            'setup',         g2.g2_setup,
                            'tempo_padrao',  g2.g2_tempad,
                            'ferramenta',    TRIM(g2.g2_ferram)
                        ) ORDER BY TRIM(g2.g2_operac)
                    ) AS operacoes
                FROM sg2010 g2
                JOIN max_rev_por_produto mr
                    ON TRIM(g2.g2_produto) = mr.produto
                    AND TRIM(g2.g2_codigo) = mr.max_codigo
                LEFT JOIN sh1010 h1
                    ON TRIM(h1.h1_codigo) = TRIM(g2.g2_recurso)
                    AND COALESCE(h1.d_e_l_e_t_, '') IN ('', ' ')
                WHERE COALESCE(g2.d_e_l_e_t_, '') IN ('', ' ')
                GROUP BY TRIM(g2.g2_produto)
            )
            SELECT
                e.item_pedido,
                e.nivel,
                e.produto_pai,
                e.componente,
                e.descricao,
                e.tipo,
                e.unidade,
                e.revisao,
                e.qtd_necessaria,
                e.op_relacionada,
                e.op_tipo_relacionada,
                COALESCE(ra.operacoes, '[]'::json) AS operacoes
            FROM estrutura e
            LEFT JOIN roteiro_agregado ra ON ra.g2_produto_limpo = e.componente
            ORDER BY e.item_pedido ASC, e.nivel ASC, e.produto_pai ASC, e.componente ASC;
        `;

        const res = await pg.query(explosionQuery, params);
        console.log("Rows returned:", res.rows.length);
        if (res.rows.length > 0) {
            console.log("First row:", JSON.stringify(res.rows[0], null, 2));
            const operationsCount = res.rows.filter(r => r.operacoes && r.operacoes.length > 0).length;
            console.log("Rows with operations:", operationsCount);
        }

    } catch(err) {
        console.error(err);
    } finally {
        process.exit(0);
    }
}
run();
