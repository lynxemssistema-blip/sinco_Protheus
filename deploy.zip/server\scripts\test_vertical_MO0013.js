require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const db = require('../db');
const mysqlPool = require('../services/mysqlService');
const { getInactiveOrdersFilter } = require('../util/pedidoFilterHelper');

async function test() {
  const RECURSO  = 'MO0013';
  const PRODUTO  = 'MT4-17997';

  console.log(`\n🔍 Teste: recurso=${RECURSO}  produto=${PRODUTO}\n`);

  // ── Replicar exatamente a lógica da rota /vertical/:operacao ──────────────
  const getInactiveFilter = await getInactiveOrdersFilter();
  let conditions = ["COALESCE(c2.d_e_l_e_t_, '') = ''", "TRIM(g2.g2_recurso) = $1"];
  const inactiveSql = getInactiveFilter('c2.c2_pedido');
  if (inactiveSql) conditions.push(inactiveSql.replace(/^\s*AND\s+/i, ''));
  let paramsArr = [RECURSO];
  let pCount = 2;

  // Filtro por produto
  conditions.push(`(TRIM(c2.c2_produto) ILIKE $${pCount} OR TRIM(b1.b1_desc) ILIKE $${pCount})`);
  paramsArr.push(`%${PRODUTO}%`);
  pCount++;

  const whereClause = `WHERE ${conditions.join(' AND ')}`;

  const pgQuery = `
    SELECT
      TRIM(c2.c2_num)     AS op,
      TRIM(c2.c2_item)    AS item_op,
      TRIM(c2.c2_sequen)  AS sequen_op,
      TRIM(c2.c2_produto) AS produto,
      COALESCE(NULLIF(TRIM(c2.c2_pedido),''), NULLIF(TRIM(root_op.c2_pedido),'')) AS raw_pedido,
      c2.c2_quant::numeric AS qtd_op,
      COALESCE(TRIM(c6.c6_descri), TRIM(b1.b1_desc)) AS desc_produto,
      TRIM(g2.g2_operac)  AS operacao_codigo,
      TRIM(h1.h1_descri)  AS operacao_desc,
      TRIM(g2.g2_recurso) AS recurso_codigo,
      CASE
        WHEN c6.c6_entreg IS NOT NULL AND c6.c6_entreg <> ''
        THEN TO_CHAR(TO_DATE(c6.c6_entreg, 'YYYYMMDD'), 'YYYY-MM-DD')
        ELSE NULL
      END AS data_entrega
    FROM public.sc2010 c2
    LEFT JOIN public.sc2010 root_op
      ON root_op.c2_num = c2.c2_num AND root_op.c2_item = c2.c2_item
      AND root_op.c2_sequen = '001' AND COALESCE(root_op.d_e_l_e_t_, '') = ''
    INNER JOIN public.sg2010 g2
      ON btrim(g2.g2_produto) = btrim(c2.c2_produto) AND COALESCE(g2.d_e_l_e_t_, '') = ''
    LEFT JOIN public.sh1010 h1
      ON h1.h1_codigo = g2.g2_recurso AND COALESCE(h1.d_e_l_e_t_, '') IN ('', ' ')
    LEFT JOIN public.sc6010 c6
      ON TRIM(c6.c6_num)  = COALESCE(NULLIF(TRIM(c2.c2_pedido),''), NULLIF(TRIM(root_op.c2_pedido),''))
      AND TRIM(c6.c6_item) = COALESCE(NULLIF(TRIM(c2.c2_itempv),''), NULLIF(TRIM(root_op.c2_itempv),''))
      AND COALESCE(c6.d_e_l_e_t_, '') = ''
    LEFT JOIN public.sb1010 b1
      ON TRIM(b1.b1_cod) = TRIM(c2.c2_produto) AND COALESCE(b1.d_e_l_e_t_, '') = ''
    ${whereClause}
    ORDER BY c6.c6_entreg ASC NULLS LAST, c2.c2_pedido ASC, c2.c2_num ASC
  `;

  console.log('▶ Executando query no PostgreSQL (timeout: 120s)...\n');
  const t0 = Date.now();
  // Usamos pool diretamente para sobrescrever o statement_timeout do db.js (45s)
  const { Pool } = require('pg');
  const rawPool = new Pool({
    host: process.env.PGHOST, port: process.env.PGPORT,
    user: process.env.PGUSER, password: process.env.PGPASSWORD,
    database: process.env.PGDATABASE,
    statement_timeout: 120000
  });
  const pgResult = await rawPool.query(pgQuery, paramsArr);
  await rawPool.end();
  console.log(`✅ PostgreSQL: ${pgResult.rows.length} linhas em ${Date.now()-t0}ms\n`);

  if (pgResult.rows.length === 0) {
    console.log('⚠️  Nenhuma OP encontrada para esse recurso + produto.');
    process.exit(0);
  }

  // Exibir linhas do PG
  pgResult.rows.forEach(r => {
    console.log(`  OP: ${r.op} | Item: ${r.item_op} | Seq: ${r.sequen_op} | Produto: ${r.produto} | Recurso: ${r.recurso_codigo} | Operação: ${r.operacao_codigo} (${r.operacao_desc}) | Pedido: ${r.raw_pedido || '—'} | Entrega: ${r.data_entrega || '—'} | Qtd: ${r.qtd_op}`);
  });

  // ── Enriquecimento MySQL ──────────────────────────────────────────────────
  const opCodes = [...new Set(pgResult.rows.map(o => o.op))];
  const opCodOperacoes = [...new Set(pgResult.rows.map(o => o.operacao_codigo).filter(Boolean))];
  const opPH = opCodes.map(() => '?').join(',');
  const opPH2 = opCodOperacoes.map(() => '?').join(',');

  console.log(`\n▶ Buscando planejamentos no MySQL para ${opCodes.length} OPs e ${opCodOperacoes.length} operações...`);
  const t1 = Date.now();
  const [pRows] = await mysqlPool.query(`
    SELECT op_numero, op_item, op_sequencia, operacao_codigo,
           data_planejada_inicio, data_planejada_fim
    FROM app_production_planning
    WHERE op_numero IN (${opPH}) AND operacao_codigo IN (${opPH2})
  `, [...opCodes, ...opCodOperacoes]);
  console.log(`✅ MySQL planning: ${pRows.length} linhas em ${Date.now()-t1}ms`);

  const [aRows] = await mysqlPool.query(`
    SELECT op_numero, op_item, op_sequencia, operacao_codigo,
           SUM(quantidade) as total_produzido,
           GROUP_CONCAT(DISTINCT usuario SEPARATOR ', ') as usuarios
    FROM app_production_appointments
    WHERE op_numero IN (${opPH}) AND operacao_codigo IN (${opPH2})
    GROUP BY op_numero, op_item, op_sequencia, operacao_codigo
  `, [...opCodes, ...opCodOperacoes]);
  console.log(`✅ MySQL appointments: ${aRows.length} linhas em ${Date.now()-t1}ms\n`);

  // ── Resultado enriquecido ─────────────────────────────────────────────────
  console.log('─'.repeat(110));
  console.log('RESULTADO FINAL (como a API retornaria):');
  console.log('─'.repeat(110));

  pgResult.rows.forEach(row => {
    const p = pRows.find(x =>
      x.op_numero === row.op && x.op_item === row.item_op &&
      x.op_sequencia === row.sequen_op && x.operacao_codigo === row.operacao_codigo
    );
    const a = aRows.find(x =>
      x.op_numero === row.op && x.op_item === row.item_op &&
      x.op_sequencia === row.sequen_op && x.operacao_codigo === row.operacao_codigo
    );
    const qtd_apontada = a ? parseFloat(a.total_produzido) : 0;
    const qtd_planejada = parseFloat(row.qtd_op) || 0;
    let status = qtd_apontada >= qtd_planejada && qtd_planejada > 0 ? 'CONCLUIDO'
               : qtd_apontada > 0 ? 'PARCIAL' : 'PENDENTE';

    console.log([
      `OP: ${row.op}/${row.item_op}`,
      `Prod: ${row.produto}`,
      `Oper: ${row.operacao_codigo}`,
      `Recurso: ${row.recurso_codigo}`,
      `Plan.Início: ${p?.data_planejada_inicio ? new Date(p.data_planejada_inicio).toLocaleDateString('pt-BR') : '—'}`,
      `Plan.Fim: ${p?.data_planejada_fim   ? new Date(p.data_planejada_fim  ).toLocaleDateString('pt-BR') : '—'}`,
      `Apontado: ${qtd_apontada}/${qtd_planejada}`,
      `Status: ${status}`,
      a?.usuarios ? `Usuários: ${a.usuarios}` : ''
    ].filter(Boolean).join(' | '));
  });

  console.log('─'.repeat(110));
  console.log(`\nTotal: ${pgResult.rows.length} linha(s) | OPs únicas: ${opCodes.join(', ')}\n`);
  process.exit(0);
}

test().catch(e => { console.error('ERRO:', e.message, e.stack); process.exit(1); });
