const db = require('../db');

async function testQuery() {
    try {
        console.log("Starting query...");
        const query = `
            SELECT
                COUNT(*)::integer AS total,
                CASE
                    WHEN sb1.b1_msblql IN ('1','S','T','Y')
                      OR EXISTS (
                            SELECT 1 FROM public.sz0010
                            WHERE TRIM(z0_produto) = TRIM(c6.c6_produto)
                              AND COALESCE(d_e_l_e_t_, '') <> '*'
                              AND z0_status = 'P'
                            LIMIT 1
                         ) THEN 'Restrição'
                    WHEN COALESCE(c6.c6_xrevm, '') <> COALESCE(c6.c6_xrevc, '') THEN 'Revisão'
                    WHEN NOT EXISTS (
                            SELECT 1 FROM public.sg1010
                            WHERE TRIM(g1_cod) = TRIM(c6.c6_produto)
                              AND COALESCE(d_e_l_e_t_, '') <> '*'
                            LIMIT 1
                         )
                     AND NOT EXISTS (
                            SELECT 1 FROM public.sg2010
                            WHERE TRIM(g2_produto) = TRIM(c6.c6_produto)
                              AND COALESCE(d_e_l_e_t_, '') <> '*'
                            LIMIT 1
                         ) THEN 'Novo'
                    WHEN EXISTS (
                            SELECT 1 FROM public.sc2010
                            WHERE TRIM(c2_pedido) = TRIM(c5.c5_num)
                              AND TRIM(c2_itempv) = TRIM(c6.c6_item)
                              AND COALESCE(d_e_l_e_t_, '') = ''
                            LIMIT 1
                         ) THEN 'PCP (Com OP)'
                    ELSE 'PCP (Sem OP) - Urgente Liberação'
                END AS status_tipo_item
            FROM public.sc5010 c5
            JOIN public.sc6010 c6
                ON c6.c6_filial = c5.c5_filial
                AND c6.c6_num   = c5.c5_num
                AND COALESCE(c6.d_e_l_e_t_, '') = ''
            LEFT JOIN public.sb1010 sb1
                ON sb1.b1_cod = c6.c6_produto
                AND COALESCE(sb1.d_e_l_e_t_, '') = ''
            WHERE COALESCE(c5.d_e_l_e_t_, '') = ''
              AND c5.c5_tipo <> 'B'
              AND ((c6.c6_qtdven - c6.c6_qtdent) > 0 OR c6.c6_qtdlib > 0)
            GROUP BY 2
        `;
        const result = await db.query(query);
        console.log(result.rows);
        process.exit(0);
    } catch (e) {
        console.error("ERROR:");
        console.error(e.message);
        process.exit(1);
    }
}
testQuery();
