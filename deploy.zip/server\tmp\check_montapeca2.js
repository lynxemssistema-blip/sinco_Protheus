const mysqlPool = require('../services/mysqlService');
async function main() {
    try {
        const [m_rows] = await mysqlPool.execute(`
            SELECT m.IdMontaPeca, m.IdMaterial as raw_mat_id, mat1.CodMatFabricante as raw_mat_codigo, mat1.DescResumo as raw_mat_desc,
                   m.IdMaterialPeca as peca_id, mat2.CodMatFabricante as peca_codigo, mat2.DescResumo as peca_desc, m.PecaQtde
            FROM montapeca m 
            LEFT JOIN material mat1 ON m.IdMaterial = mat1.IdMaterial 
            LEFT JOIN material mat2 ON m.IdMaterialPeca = mat2.IdMaterial
            LIMIT 5
        `);
        console.table(m_rows);
    } catch (e) {
        console.error(e);
    }
    process.exit();
}
main();
