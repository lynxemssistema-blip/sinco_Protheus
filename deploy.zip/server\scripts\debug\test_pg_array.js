require('dotenv').config({ path: '.env' });
const { Pool } = require('pg');
const pool = new Pool({
  user: process.env.PG_USER,
  host: process.env.PG_HOST,
  database: process.env.PG_DATABASE,
  password: process.env.PG_PASSWORD,
  port: process.env.PG_PORT,
});

async function test() {
  try {
    const productCodes = ['MT4-31551', 'OUTROCOD'];
    const paddedCodes = productCodes.map(c => c.padEnd(15, ' '));
    const start = Date.now();
    const res = await pool.query(`
                    SELECT 'sg1' as type, TRIM(g1_cod) as cod FROM public.sg1010 WHERE g1_cod = ANY($1::varchar[]) AND COALESCE(d_e_l_e_t_, '') <> '*'
                    UNION ALL
                    SELECT 'sg2' as type, TRIM(g2_produto) as cod FROM public.sg2010 WHERE g2_produto = ANY($1::varchar[]) AND COALESCE(d_e_l_e_t_, '') <> '*'
                    UNION ALL
                    SELECT 'sz0' as type, TRIM(z0_produto) as cod FROM public.sz0010 WHERE z0_produto = ANY($1::varchar[]) AND COALESCE(d_e_l_e_t_, '') <> '*' AND z0_status = 'P'
    `, [paddedCodes]);
    const elapsed = Date.now() - start;
    console.log(`FASE 5 OK - Encontrou ${res.rows.length} rows em ${elapsed}ms`);
  } catch (err) {
    console.error('ERRO FASE 5 (Postgres array):', err.message);
  } finally {
    pool.end();
  }
}
test();
