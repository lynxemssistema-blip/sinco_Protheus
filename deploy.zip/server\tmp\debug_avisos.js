require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/server/.env' });
const mysqlPool = require('C:/Users/adm/Desktop/MetalFisa Anty/server/services/mysqlService');

async function check() {
    try {
        console.log('--- TABLES ---');
        const [tables] = await mysqlPool.query('SHOW TABLES');
        console.table(tables);

        console.log('\n--- SCHEMA sistema_avisos ---');
        const [columns] = await mysqlPool.query('SHOW COLUMNS FROM sistema_avisos');
        console.table(columns);

        console.log('\n--- SAMPLE DATA ---');
        const [data] = await mysqlPool.query('SELECT * FROM sistema_avisos LIMIT 5');
        console.table(data);

        process.exit(0);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
}

check();
