const db = require('./db');
const { getInactiveOrdersFilter } = require('./util/pedidoFilterHelper');

async function test() {
    try {
        const params = [];
        let paramCount = 1;

        const getInactiveFilter = await getInactiveOrdersFilter();
        let whereExtra = "WHERE COALESCE(c5.d_e_l_e_t_, '') = '' AND c5.c5_tipo <> 'B' AND COALESCE(c6.d_e_l_e_t_, '') = '' " + getInactiveFilter('c5.c5_num');
        
        whereExtra += ` AND ((c6.c6_qtdven - c6.c6_qtdent) > 0 OR c6.c6_qtdlib > 0)`;
        
        whereExtra += ` AND (
            COALESCE(c5.c5_nota, '') = '' 
            OR EXISTS (
                SELECT 1 FROM sc6010 c6_ex 
                WHERE c6_ex.c6_num = c5.c5_num 
                AND c6_ex.c6_filial = c5.c5_filial 
                AND COALESCE(c6_ex.d_e_l_e_t_, '') = ''
                AND ((c6_ex.c6_qtdven - c6_ex.c6_qtdent) > 0 OR c6_ex.c6_qtdlib > 0)
            )
        )`;
        
        const query = `
            SELECT
                TRIM(c5.c5_num)                                                        AS pedido,
                TRIM(c6.c6_item)                                                       AS item,
                TRIM(c6.c6_produto)                                                    AS produto,
                TRIM(sb1.b1_desc)                                                      AS descricao,
                COALESCE(c6.c6_qtdven, 0)::numeric(18,6)                               AS quantidade,
                COALESCE(c6.c6_qtdent, 0)::numeric(18,6)                               AS qtd_entreg,
                (COALESCE(c6.c6_qtdven, 0) - COALESCE(c6.c6_qtdent, 0))::numeric(18,6) AS qtd_faturar,
                CASE 
                    WHEN (COALESCE(c6.c6_qtdven, 0) - COALESCE(c6.c6_qtdent, 0)) <= 0 THEN 'ENTREGUE'
                    ELSE 'PENDENTE'
                END                                                                    AS status,
                TRIM(c6.c6_um)                                                         AS unidade,
                TO_CHAR(
                    TO_DATE(NULLIF(TRIM(c6.c6_entreg), ''), 'YYYYMMDD'),
                    'DD/MM/YYYY'
                )                                                                       AS data_entrega,
                TRIM(c6.c6_entreg)                                                     AS data_entrega_raw,
                TRIM(sa1.a1_nome)                                                      AS cliente,
                EXISTS (
                    SELECT 1 FROM sg1010 sg1
                    WHERE TRIM(sg1.g1_cod) = TRIM(c6.c6_produto)
                      AND COALESCE(sg1.d_e_l_e_t_, '') = ''
                )                                                                       AS tem_estrutura
            FROM sc6010 c6
            JOIN sc5010 c5
                ON  c5.c5_num    = c6.c6_num
                AND c5.c5_filial = c6.c6_filial
                AND COALESCE(c5.d_e_l_e_t_, '') = ''
                AND c5.c5_tipo  <> 'B'
            LEFT JOIN sa1010 sa1
                ON  TRIM(sa1.a1_cod)  = TRIM(c5.c5_cliente)
                AND TRIM(sa1.a1_loja) = TRIM(c5.c5_lojacli)
                AND COALESCE(sa1.d_e_l_e_t_, '') = ''
            LEFT JOIN sb1010 sb1
                ON  TRIM(sb1.b1_cod) = TRIM(c6.c6_produto)
                AND COALESCE(sb1.d_e_l_e_t_, '') = ''
            ${whereExtra}
            ORDER BY c5.c5_num DESC, c6.c6_item ASC
            LIMIT 10
        `;

        console.log("Query:", query);
        const result = await db.query(query, params);
        console.log("Rows:", result.rows.length);
    } catch (err) {
        console.error("Erro:", err);
    } finally {
        process.exit();
    }
}
test();
