require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/server/.env' });
const { Pool } = require('pg');

async function listPgTables() {
    const pool = new Pool({
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        user: process.env.DB_USER,
        password: process.env.DB_PASS,
        database: process.env.DB_NAME,
    });

    try {
        console.log('--- ALL TABLES IN DATABASE ---');
        const res = await pool.query(`
            SELECT table_schema, table_name 
            FROM information_schema.tables 
            WHERE table_schema NOT IN ('information_schema', 'pg_catalog')
            ORDER BY table_name
        `);
        res.rows.forEach(r => {
            console.log(`- ${r.table_schema}.${r.table_name}`);
        });

        await pool.end();
    } catch (err) {
        console.error('Error connecting to PG:', err.message);
    }
}

listPgTables();
