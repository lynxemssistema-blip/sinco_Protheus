require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/server/.env' });
const { Pool } = require('pg');

async function listAllSdCols() {
    const pool = new Pool({
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        user: process.env.DB_USER,
        password: process.env.DB_PASS,
        database: process.env.DB_NAME,
    });

    try {
        const t = 'sd2010';
        console.log(`--- ALL COLUMNS FOR ${t} ---`);
        const res = await pool.query(`
            SELECT column_name, data_type 
            FROM information_schema.columns 
            WHERE table_name = $1
            ORDER BY column_name
        `, [t]);
        res.rows.forEach(c => {
            console.log(`- ${c.column_name} (${c.data_type})`);
        });

        await pool.end();
    } catch (err) {
        console.error('Error:', err.message);
    }
}

listAllSdCols();
