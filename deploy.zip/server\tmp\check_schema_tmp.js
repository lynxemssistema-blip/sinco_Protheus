const mysqlPool = require('../services/mysqlService');
async function run() {
    try {
        const [rows] = await mysqlPool.query("SHOW COLUMNS FROM app_production_appointments");
        console.log(rows);
    } catch(e) {
        console.error(e);
    } finally {
        process.exit();
    }
}
run();
