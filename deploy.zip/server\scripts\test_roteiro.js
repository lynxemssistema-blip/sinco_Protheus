const { Client } = require('pg');

const client = new Client({
    host: '192.168.1.61',
    user: 'sinco2',
    password: 'sinco25',
    database: 'p12prd'
});

async function checkRoteiro() {
    await client.connect();
    try {
        const res = await client.query(`
            SELECT g2_codigo, g2_operac, g2_recurso 
            FROM public.sg2010 
            WHERE btrim(g2_produto) = 'MT3-14331' 
            AND COALESCE(d_e_l_e_t_, '') = ''
        `);
        console.log('Roteiros encontrados:', res.rows);
    } catch (err) {
        console.error(err);
    } finally {
        await client.end();
    }
}

checkRoteiro();
