require('dotenv').config();
const db = require('./db');
const { getInactiveOrdersFilter } = require('./util/pedidoFilterHelper');

async function testFastJoin() {
    const getInactiveFilter = await getInactiveOrdersFilter();
    const inactiveSql = getInactiveFilter('pl.c2_pedido');
    
    const conditions = ["COALESCE(pl.d_e_l_e_t_, ' ') = ' '", "COALESCE(pl.c2_quant, 0) > COALESCE(pl.c2_quje, 0)"];
    if (inactiveSql) conditions.push(inactiveSql.replace(/^\s*AND\s+/i, ''));

    const query = `
        SELECT count(*) as total
        FROM sc2010 pl
        LEFT JOIN sb1010 sb1
            ON sb1.b1_cod = pl.c2_produto
           AND COALESCE(sb1.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sc5010 sc5
            ON sc5.c5_num = pl.c2_pedido
           AND COALESCE(sc5.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sc6010 sc6
            ON sc6.c6_num = pl.c2_pedido
           AND sc6.c6_item = pl.c2_itempv
           AND COALESCE(sc6.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sa1010 sa1
            ON sa1.a1_cod = sc5.c5_cliente
           AND sa1.a1_loja = sc5.c5_lojacli
           AND COALESCE(sa1.d_e_l_e_t_, ' ') = ' '
        LEFT JOIN sg2010 sg2
            ON sg2.g2_produto = pl.c2_produto
           AND COALESCE(sg2.d_e_l_e_t_, ' ') = ' '
        WHERE ${conditions.join(' AND ')}
          AND UPPER(sa1.a1_nome) LIKE '%VMI%'
    `;

    console.log('Running WITHOUT RTRIM...');
    const t0 = Date.now();
    try {
        const result = await db.query(query);
        console.log(`Finished in ${Date.now() - t0}ms, total rows matching:`, result.rows[0].total);
    } catch (e) {
        console.error(e);
    }
    process.exit();
}
testFastJoin();
