const axios = require('axios');

async function testApi() {
    try {
        const res = await axios.post('http://localhost:3001/api/auth/login', {
            login: 'Edson',
            senha: 'EdsonMetal'
        });
        console.log("✅ OK!", Object.keys(res.data));
    } catch(e) {
        console.log("❌ ERRO:", e.response?.status, e.response?.data);
    }
}

testApi();
