require('dotenv').config();
const { Pool } = require('pg');

const db = new Pool({
  host: process.env.PG_HOST || '192.168.1.77',
  port: process.env.PG_PORT || 5432,
  user: process.env.PG_USER || 'postgres',
  password: process.env.PG_PASSWORD || 'O&sZ2021@!*#@Mtf',
  database: process.env.PG_DATABASE || 'protheus_test',
});

async function run() {
  try {
    const q = `
      SELECT DISTINCT
        TRIM(h1.h1_codigo) AS cod_recurso,
        TRIM(h1.h1_descri) AS desc_recurso
      FROM public.sh1010 h1
      WHERE COALESCE(h1.d_e_l_e_t_, '') IN ('', ' ')
        AND TRIM(h1.h1_codigo) <> ''
      ORDER BY TRIM(h1.h1_codigo)
    `;
    const res = await db.query(q);
    console.log(`Resources found: ${res.rows.length}`);
    console.log(res.rows.slice(0, 10));
  } catch(e) {
    console.error(e);
  } finally {
    db.end();
  }
}

run();
