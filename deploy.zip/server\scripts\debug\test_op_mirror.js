require('dotenv').config();
const db = require('./db');

// Use a real pedido number from the app logs
const PEDIDO_ID = process.argv[2] || '002730';

async function testOpMirror() {
    console.log(`\n🔍 Testing /op-mirror SQL for pedido: ${PEDIDO_ID}\n`);

    // Step 1: Order header query
    try {
        const orderQuery = `
            SELECT
                TRIM(c5.c5_num) AS pedido,
                TO_CHAR(TO_DATE(NULLIF(TRIM(c5.c5_emissao), ''), 'YYYYMMDD'), 'DD/MM/YY') AS emissao,
                TRIM(sa1.a1_nome) AS nome_cliente
            FROM sc5010 c5
            LEFT JOIN sa1010 sa1
                ON sa1.a1_cod = c5.c5_cliente
                AND sa1.a1_loja = c5.c5_lojacli
                AND COALESCE(sa1.d_e_l_e_t_, '') = ''
            WHERE TRIM(c5.c5_num) = $1
              AND COALESCE(c5.d_e_l_e_t_, '') = ''
        `;
        const r = await db.query(orderQuery, [PEDIDO_ID]);
        if (r.rows.length === 0) {
            console.log('❌ Step 1: Pedido NOT FOUND - check the pedido ID');
        } else {
            console.log('✅ Step 1: Order header OK:', r.rows[0]);
        }
    } catch (e) {
        console.error('❌ Step 1 FAILED:', e.message);
        process.exit(1);
    }

    // Step 2: Check SC6 items with OP
    try {
        const sc6Query = `
            SELECT TRIM(c6.c6_item) AS item, TRIM(c6.c6_produto) AS produto,
                   c6.c6_qtdven AS qtd, TRIM(c6.c6_numop) AS op_num
            FROM sc6010 c6
            WHERE TRIM(c6.c6_num) = $1
              AND COALESCE(c6.d_e_l_e_t_, '') = ''
              AND COALESCE(TRIM(c6.c6_numop), '') != ''
        `;
        const r = await db.query(sc6Query, [PEDIDO_ID]);
        console.log(`✅ Step 2: Found ${r.rows.length} SC6 items with OP:`, r.rows.slice(0, 3));
        if (r.rows.length === 0) {
            console.log('⚠️  No items with OP found - the BOM explosion will return empty');
        }
    } catch (e) {
        console.error('❌ Step 2 FAILED:', e.message);
    }

    // Step 3: Full recursive explosion query
    try {
        const explosionQuery = `
            WITH RECURSIVE
            pv_itens AS (
                SELECT
                    TRIM(c6.c6_item) AS item_pedido,
                    TRIM(c6.c6_produto) AS produto_venda,
                    TRIM(sb1.b1_desc) AS desc_venda,
                    COALESCE(c6.c6_qtdven, 0)::numeric AS qtd_venda,
                    TRIM(c6.c6_um) as unid_venda,
                    TRIM(c6.c6_xrevm) as rev_metalfisa,
                    TRIM(c6.c6_numop) as op_num
                FROM sc6010 c6
                LEFT JOIN sb1010 sb1 ON TRIM(sb1.b1_cod) = TRIM(c6.c6_produto) AND COALESCE(sb1.d_e_l_e_t_, '') = ''
                WHERE TRIM(c6.c6_num) = $1
                  AND COALESCE(c6.d_e_l_e_t_, '') = ''
                  AND COALESCE(TRIM(c6.c6_numop), '') != ''
            ),
            estrutura AS (
                SELECT
                    pv.item_pedido,
                    0 AS nivel,
                    pv.produto_venda AS produto_pai,
                    pv.produto_venda AS componente,
                    pv.desc_venda AS descricao,
                    pv.unid_venda AS unidade,
                    pv.rev_metalfisa AS revisao,
                    1::numeric AS qtd_base,
                    pv.qtd_venda AS qtd_necessaria,
                    pv.op_num AS op_relacionada
                FROM pv_itens pv

                UNION ALL

                SELECT
                    e.item_pedido,
                    e.nivel + 1,
                    CAST(TRIM(e.componente) AS VARCHAR(30)) AS produto_pai,
                    CAST(TRIM(g1.g1_comp) AS VARCHAR(30)) AS componente,
                    CAST(TRIM(sb1.b1_desc) AS VARCHAR(100)) AS descricao,
                    CAST(TRIM(sb1.b1_um) AS VARCHAR(10)) AS unidade,
                    CAST(TRIM(sb1.b1_urev) AS VARCHAR(10)) AS revisao,
                    g1.g1_quant::numeric AS qtd_base,
                    (e.qtd_necessaria * g1.g1_quant::numeric)::numeric AS qtd_necessaria,
                    e.op_relacionada
                FROM estrutura e
                JOIN sg1010 g1 ON TRIM(g1.g1_cod) = TRIM(e.componente) AND COALESCE(g1.d_e_l_e_t_, '') = ''
                LEFT JOIN sb1010 sb1 ON TRIM(sb1.b1_cod) = TRIM(g1.g1_comp) AND COALESCE(sb1.d_e_l_e_t_, '') = ''
                WHERE e.nivel < 15
            )
            SELECT
                e.item_pedido,
                e.nivel,
                e.produto_pai,
                e.componente,
                e.descricao,
                e.unidade,
                e.revisao,
                e.qtd_necessaria,
                e.op_relacionada,
                COALESCE(
                    (
                        SELECT json_agg(
                            json_build_object(
                                'seq', TRIM(g2.g2_operac),
                                'recurso', TRIM(g2.g2_recurso),
                                'desc_operacao', TRIM(g2.g2_descri),
                                'setup', g2.g2_setup,
                                'tempo_padrao', g2.g2_tempad,
                                'ferramenta', TRIM(g2.g2_ferram)
                            ) ORDER BY TRIM(g2.g2_operac)
                        )
                        FROM sg2010 g2
                        WHERE TRIM(g2.g2_produto) = e.componente
                          AND COALESCE(g2.d_e_l_e_t_, '') IN ('', ' ')
                    ), '[]'::json
                ) AS operacoes
            FROM estrutura e
            ORDER BY e.item_pedido ASC, e.nivel ASC, e.produto_pai ASC, e.componente ASC;
        `;

        const r = await db.query(explosionQuery, [PEDIDO_ID]);
        console.log(`\n✅ Step 3: Full explosion query OK! ${r.rows.length} rows returned`);
        if (r.rows.length > 0) {
            console.log('Sample row:', JSON.stringify(r.rows[0], null, 2));
        }
    } catch (e) {
        console.error('\n❌ Step 3 FAILED - Recursive explosion query error:');
        console.error('  Message:', e.message);
        console.error('  Detail:', e.detail);
        console.error('  Hint:', e.hint);
    }

    process.exit(0);
}

testOpMirror();
