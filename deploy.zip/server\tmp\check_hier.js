const mysqlPool = require('../services/mysqlService');

async function main() {
    try {
        const [rows] = await mysqlPool.execute(`
            SELECT IdProdutoEstruturaItem, CodProdutoPai, CodMatFabricante, nivel, QtdeTotal, DescResumo
            FROM produto_estrutura_item
            WHERE CodProdutoPai = 'MT3-14719.asm'
            ORDER BY nivel ASC
        `);
        console.table(rows);
    } catch (err) {
        console.error("Error:", err);
    } finally {
        process.exit();
    }
}
main();
