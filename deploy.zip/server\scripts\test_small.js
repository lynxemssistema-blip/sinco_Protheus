const db = require('../db');

async function testSmall() {
    try {
        const query = `
            SELECT
                COUNT(*)::integer AS total,
                CASE
                    WHEN EXISTS (
                            SELECT 1 FROM public.sz0010
                            WHERE TRIM(z0_produto) = TRIM(c6.c6_produto)
                            LIMIT 1
                         ) THEN 'Restrição'
                    ELSE 'OK'
                END AS status_tipo_item
            FROM public.sc6010 c6
            GROUP BY 2
            LIMIT 10
        `;
        const result = await db.query(query);
        console.log("Success");
        process.exit(0);
    } catch (e) {
        console.error("ERROR:", e.message);
        process.exit(1);
    }
}
testSmall();
