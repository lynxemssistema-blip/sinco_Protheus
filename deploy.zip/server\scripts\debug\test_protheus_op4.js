const axios = require('axios');
const https = require('https');

const httpsAgent = new https.Agent({ rejectUnauthorized: false });

async function run() {
    try {
        const tokenUrl = 'https://192.168.1.60:47500/tlpp/oauth2/token?grant_type=password&username=sinco&password=Metal1120';
        const tokenRes = await axios.get(tokenUrl, { httpsAgent, timeout: 10000 });
        const accessToken = tokenRes.data.access_token;
        console.log("Token obtained");

        const ordensProducao = [];

        const payload = { data: { ordensProducao } };

        const protheusRes = await axios.post(
            'https://192.168.1.60:47500/ordem-producao/incluir',
            payload,
            { headers: { 'Authorization': `Bearer ${accessToken}` }, httpsAgent, timeout: 60000 }
        );

        console.log('📬 Resposta Protheus →', JSON.stringify(protheusRes.data, null, 2));
    } catch (err) {
        console.error('Error:', err.response ? JSON.stringify(err.response.data, null, 2) : err.message);
    }
}
run();
