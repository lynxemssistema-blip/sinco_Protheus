require('dotenv').config();
const db = require('./db');
const mysql = require('./services/mysqlService');

async function testFilter() {
    const [rows] = await mysql.query("SELECT pedido_numero FROM app_pedidos_inativos");
    const pedidos = rows.map(r => `'${r.pedido_numero.trim().padEnd(6, ' ')}'`);
    
    // Using ARRAY
    const inactiveSql = ` AND c5.c5_num <> ALL (ARRAY[${pedidos.join(', ')}]::character(6)[]) `;

    const query = `
        EXPLAIN ANALYZE SELECT
            c5.c5_num as pedido,
            c5.c5_cliente as cod_cliente,
            sa1.a1_nome as nome_cliente,
            c6.c6_item as item,
            c6.c6_produto as codigo,
            sb1.b1_desc as descricao,
            COALESCE(c6.c6_qtdven, 0)::numeric(18,6) as quantidade,
            COALESCE(c6.c6_qtdent, 0)::numeric(18,6) as qtd_entreg,
            (COALESCE(c6.c6_qtdven, 0) - COALESCE(c6.c6_qtdent, 0))::numeric(18,6) as qtd_faturar,
            c6.c6_prcven::numeric(18,2) as valor_unitario,
            ((COALESCE(c6.c6_qtdven, 0) - COALESCE(c6.c6_qtdent, 0)) * COALESCE(c6.c6_prcven, 0))::numeric(18,2) as valor_saldo,
            c5.c5_emissao as c5_emissao_raw,
            c6.c6_entreg as c6_entreg_raw
        FROM public.sc5010 c5
        JOIN public.sc6010 c6
            ON COALESCE(c6.d_e_l_e_t_, '') = ''
            AND c6.c6_filial = c5.c5_filial
            AND c6.c6_num = c5.c5_num
        LEFT JOIN public.sa1010 sa1
            ON sa1.a1_cod = c5.c5_cliente
            AND sa1.a1_loja = c5.c5_lojacli
            AND COALESCE(sa1.d_e_l_e_t_, '') = ''
        LEFT JOIN public.sb1010 sb1
            ON sb1.b1_cod = c6.c6_produto
            AND COALESCE(sb1.d_e_l_e_t_, '') = ''
        WHERE COALESCE(c5.d_e_l_e_t_, '') = '' 
          AND c5.c5_tipo <> 'B'
          AND (COALESCE(c6.c6_qtdven, 0) - COALESCE(c6.c6_qtdent, 0)) > 0
          AND NULLIF(TRIM(c6.c6_entreg), '') IS NOT NULL
          ${inactiveSql}
        ORDER BY c6.c6_entreg ASC, c5.c5_num ASC;
    `;

    console.log('Running testFilter...');
    const t0 = Date.now();
    try {
        const result = await db.query(query);
        console.log(`Finished in ${Date.now() - t0}ms, returned ${result.rows.length} rows`);
    } catch (e) {
        console.error('Error:', e);
    }
    process.exit();
}
testFilter();
