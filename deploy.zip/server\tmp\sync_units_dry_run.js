const path = require('path');
require('dotenv').config(); // Carrega do server/.env se rodar de dentro de server
const db = require('../db'); // Postgres
const mysqlPool = require('../services/mysqlService'); // MySQL

async function dryRun() {
    try {
        console.log('🔍 [SYNC] Iniciando dry run para sincronização de unidades...');

        // 1. Verificar se a tabela material existe no MySQL
        const [tables] = await mysqlPool.execute("SHOW TABLES LIKE 'material'");
        if (tables.length === 0) {
            console.error("❌ Tabela 'material' não encontrada no MySQL.");
            const [allTables] = await mysqlPool.execute("SHOW TABLES");
            console.log("Tabelas disponíveis no MySQL:", allTables.map(t => Object.values(t)[0]));
            return;
        }

        // 2. Buscar dados do MySQL (material)
        const [mysqlRows] = await mysqlPool.execute(`
            SELECT IdMaterial, CodMatFabricante, Unidade 
            FROM material 
            WHERE CodMatFabricante IS NOT NULL AND CodMatFabricante != ''
            LIMIT 5000
        `);
        console.log(`📊 Encontrados ${mysqlRows.length} registros na tabela material do Sinco.`);

        if (mysqlRows.length === 0) return;

        // 3. Buscar correspondentes no Protheus (Postgres)
        const protheusQuery = `
            SELECT TRIM(b1_cod) as codigo, TRIM(b1_um) as unidade_protheus
            FROM sb1010
            WHERE COALESCE(d_e_l_e_t_, '') = ''
        `;
        const pgRes = await db.query(protheusQuery);
        const protheusMap = {};
        pgRes.rows.forEach(r => {
            protheusMap[r.codigo] = r.unidade_protheus;
        });
        console.log(`📊 Mapeados ${pgRes.rows.length} produtos do Protheus.`);

        // 4. Identificar divergências
        const diverget = [];
        for (const row of mysqlRows) {
            const protheusUnit = protheusMap[row.CodMatFabricante.trim()];
            if (protheusUnit && protheusUnit !== row.Unidade) {
                diverget.push({
                    id: row.IdMaterial,
                    codigo: row.CodMatFabricante,
                    unidade_sinco: row.Unidade,
                    unidade_protheus: protheusUnit
                });
            }
        }

        console.log(`⚠️ Encontradas ${diverget.length} divergências de unidade.`);

        if (diverget.length > 0) {
            console.log("\n💎 Exemplo Real:");
            console.table(diverget.slice(0, 10));
        } else {
            console.log("✅ Nenhuma divergência encontrada nos primeiros 5000 registros.");
        }

    } catch (err) {
        console.error("❌ Erro durante o dry run:", err);
    } finally {
        process.exit();
    }
}

dryRun();
