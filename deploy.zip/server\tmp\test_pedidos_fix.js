require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/server/.env' });
const express = require('express');
const request = require('supertest');
const router = require('../routes/pedidos');
const app = express();

app.use(express.json());
app.use('/api/pedidos', router);

async function testEndpoint() {
    console.log('--- Testing /api/pedidos/flat ---');
    try {
        const response = await request(app)
            .get('/api/pedidos/flat?limit=1')
            .expect(200);

        console.log('✅ Success! Data received.');
        console.log('Sample Item:', JSON.stringify(response.body.data[0], null, 2).substring(0, 500) + '...');
        process.exit(0);
    } catch (err) {
        console.error('❌ Failed!');
        console.error(err.response?.body || err.message);
        process.exit(1);
    }
}

testEndpoint();
