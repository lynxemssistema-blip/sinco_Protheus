require('dotenv').config({ path: 'C:/Users/adm/Desktop/MetalFisa Anty/server/.env' });
const { Pool } = require('pg');

async function checkMoreTables() {
    const pool = new Pool({
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        user: process.env.DB_USER,
        password: process.env.DB_PASS,
        database: process.env.DB_NAME,
    });

    try {
        const tables = ['sc6010', 'sa1010'];
        for (const t of tables) {
            console.log(`--- ALL COLUMNS FOR ${t} ---`);
            const res = await pool.query(`
                SELECT column_name, data_type 
                FROM information_schema.columns 
                WHERE table_name = $1
                ORDER BY column_name
            `, [t]);
            res.rows.forEach(c => {
                // Focus on the ones I use
                if (t === 'sc6010' && (c.column_name.includes('qtd') || c.column_name.includes('entreg'))) {
                    console.log(`- ${c.column_name} (${c.data_type})`);
                }
                if (t === 'sa1010' && (c.column_name.includes('cod') || c.column_name.includes('loja'))) {
                    console.log(`- ${c.column_name} (${c.data_type})`);
                }
            });
        }

        await pool.end();
    } catch (err) {
        console.error('Error:', err.message);
    }
}

checkMoreTables();
