const axios = require('axios');
const https = require('https');

async function testProtheus() {
    const httpsAgent = new https.Agent({ rejectUnauthorized: false });
    
    let accessToken = '';
    try {
        const tokenUrl = 'https://192.168.1.60:47500/tlpp/oauth2/token?grant_type=password&username=sinco&password=Metal1120';
        const tokenRes = await axios.get(tokenUrl, { httpsAgent, timeout: 10000 });
        accessToken = tokenRes.data.access_token;
    } catch (authError) {
        process.exit(1);
    }

    const paddedProduto = "MT3-14331".padEnd(15, ' ');
    
    const payload = {
      "data": {
        "ordensProducao": [
          {
            "EMPRESA": "01",
            "CFILANT": "01",
            "NOPER": 3,
            "C2_NUM": "004546",
            "C2_ITEM": "02",
            "C2_PRODUTO": paddedProduto,
            "C2_QUANT": 2,
            "C2_DATPRI": "20260429",
            "C2_DATPRF": "20260429",
            "C2_OBS": "TESTE SEM SEQ",
            "C2_ROTEIRO": "01",
            "C2_PEDIDO": "004546",
            "C2_ITEMPV": "02"
          }
        ]
      }
    };

    try {
        const createUrl = 'https://192.168.1.60:47500/ordem-producao/incluir';
        const createRes = await axios.post(createUrl, payload, {
            headers: { 'Authorization': `Bearer ${accessToken}` },
            httpsAgent,
            timeout: 30000
        });

        console.log('3. Resposta SUCESSO:', JSON.stringify(createRes.data, null, 2));
    } catch (err) {
        if (err.response) {
            console.error('3. Resposta ERRO (Catch):', err.response.status);
            console.error('Detalhes do Erro:', JSON.stringify(err.response.data, null, 2));
        } else {
            console.error('3. Resposta ERRO (Rede/Sistema):', err.message);
        }
    }
}

testProtheus();
