const mysqlPool = require('../services/mysqlService');

async function main() {
    try {
        console.log('--- SHOW TABLES ---');
        const [tables] = await mysqlPool.execute("SHOW TABLES LIKE '%processo%'");
        console.log(tables.map(t => Object.values(t)[0]));

        console.log('--- SHOW COLUMNS FROM montapeca ---');
        const [m_cols] = await mysqlPool.execute("DESCRIBE montapeca");
        console.log(m_cols.map(c => c.Field).join(', '));

        console.log('--- SHOW COLUMNS FROM material_processo ---');
        const [mp_cols] = await mysqlPool.execute("DESCRIBE material_processo");
        console.log(mp_cols.map(c => c.Field).join(', '));

        console.log('--- SHOW COLUMNS FROM processo ---');
        try {
            const [p_cols] = await mysqlPool.execute("DESCRIBE processo");
            console.log(p_cols.map(c => c.Field).join(', '));
        } catch (e) {
            console.log('Table processo not found.');
        }

        try {
            const [sp_cols] = await mysqlPool.execute("DESCRIBE sinco_processos");
            console.log('sinco_processos:', sp_cols.map(c => c.Field).join(', '));
        } catch (e) { }

        const [app_p_cols] = await mysqlPool.execute("DESCRIBE app_processos");
        console.log('app_processos:', app_p_cols.map(c => c.Field).join(', '));

    } catch (err) {
        console.error("Error:", err);
    } finally {
        process.exit();
    }
}
main();
