const path = require('path');
require('dotenv').config();
const db = require('../db'); // Postgres
const mysqlPool = require('../services/mysqlService'); // MySQL

async function dryRun() {
    try {
        console.log('🔍 [SYNC-OSI] Iniciando dry run para ordemservicoitem...');

        const [mysqlRows] = await mysqlPool.execute(`
            SELECT IdOrdemServicoItem, CodMatFabricante, Unidade 
            FROM ordemservicoitem 
            WHERE CodMatFabricante IS NOT NULL AND CodMatFabricante != ''
            LIMIT 5000
        `);
        console.log(`📊 Encontrados ${mysqlRows.length} registros na tabela ordemservicoitem.`);

        if (mysqlRows.length === 0) return;

        const protheusQuery = `
            SELECT TRIM(b1_cod) as codigo, TRIM(b1_um) as unidade_protheus
            FROM sb1010
            WHERE COALESCE(d_e_l_e_t_, '') = ''
        `;
        const pgRes = await db.query(protheusQuery);
        const protheusMap = {};
        pgRes.rows.forEach(r => {
            protheusMap[r.codigo] = r.unidade_protheus;
        });

        const diverget = [];
        for (const row of mysqlRows) {
            const codigo = row.CodMatFabricante ? row.CodMatFabricante.trim() : null;
            const protheusUnit = protheusMap[codigo];
            if (protheusUnit && protheusUnit !== row.Unidade) {
                diverget.push({
                    id: row.IdOrdemServicoItem,
                    codigo: row.CodMatFabricante,
                    unidade_sinco: row.Unidade,
                    unidade_protheus: protheusUnit
                });
            }
        }

        console.log(`⚠️ Encontradas ${diverget.length} divergências em ordemservicoitem.`);
        if (diverget.length > 0) {
            console.log("\n💎 Exemplo Real (OSI):");
            console.table(diverget.slice(0, 10));
        }

    } catch (err) {
        console.error("❌ Erro no dry run OSI:", err);
    } finally {
        process.exit();
    }
}

dryRun();
