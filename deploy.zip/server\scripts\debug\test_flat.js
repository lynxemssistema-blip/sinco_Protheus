const { Pool } = require('pg');

const db = new Pool({
  host: '192.168.1.61',
  port: 5432,
  user: 'sinco2',
  password: 'sinco25',
  database: 'p12prd',
});

async function run() {
  try {
    const start = Date.now();
    const pgRes = await db.query(`
        EXPLAIN ANALYZE
        WITH paged_items AS (
                SELECT
                    TRIM(c5.c5_num) as pedido,
                    TRIM(c6.c6_item) as item,
                    TRIM(c6.c6_produto) as codigo,
                    CASE
                        WHEN sb1.b1_msblql IN ('1','S','T','Y') OR sz0_agg.produto IS NOT NULL THEN 'Restrição'
                        WHEN COALESCE(c6.c6_xrevm, '') <> COALESCE(c6.c6_xrevc, '') THEN 'Revisão'
                        WHEN sg1_agg.produto IS NULL AND sg2_agg.produto IS NULL THEN 'Novo'
                        ELSE 'PCP'
                    END AS status_tipo_item
                FROM public.sc5010 c5
                JOIN public.sc6010 c6
                    ON COALESCE(c6.d_e_l_e_t_, '') = ''
                    AND c6.c6_filial = c5.c5_filial
                    AND c6.c6_num = c5.c5_num
                LEFT JOIN public.sb1010 sb1
                    ON sb1.b1_cod = c6.c6_produto
                    AND COALESCE(sb1.d_e_l_e_t_, '') = ''
                LEFT JOIN LATERAL (
                    SELECT 1 AS produto FROM public.sz0010
                    WHERE TRIM(z0_produto) = TRIM(c6.c6_produto) AND COALESCE(d_e_l_e_t_, '') <> '*' AND z0_status = 'P'
                    LIMIT 1
                ) sz0_agg ON true
                LEFT JOIN LATERAL (
                    SELECT 1 AS produto FROM public.sg1010
                    WHERE TRIM(g1_cod) = TRIM(c6.c6_produto) AND COALESCE(d_e_l_e_t_, '') <> '*'
                    LIMIT 1
                ) sg1_agg ON true
                LEFT JOIN LATERAL (
                    SELECT 1 AS produto FROM public.sg2010
                    WHERE TRIM(g2_produto) = TRIM(c6.c6_produto) AND COALESCE(d_e_l_e_t_, '') <> '*'
                    LIMIT 1
                ) sg2_agg ON true
                WHERE COALESCE(c5.d_e_l_e_t_, '') = '' AND c5.c5_tipo <> 'B'
                ORDER BY c5.c5_num DESC, c6.c6_item ASC
                LIMIT 50 OFFSET 0
            )
            SELECT
                pi.*,
                TRIM(c2.c2_num) AS op_num,
                c2.c2_quant::numeric(18,6) AS op_qtd
            FROM paged_items pi
            LEFT JOIN public.sc2010 c2
                ON TRIM(c2.c2_pedido) = pi.pedido
                AND TRIM(c2.c2_itempv) = pi.item
                AND COALESCE(c2.d_e_l_e_t_, '') = ''
            ORDER BY pi.pedido DESC, pi.item ASC, c2.c2_sequen ASC, c2.c2_num ASC
    `);
    
    console.log(`Execution time: ${Date.now() - start}ms`);
    console.log(pgRes.rows.map(r => r['QUERY PLAN']).join('\n'));
  } catch(e) {
    console.error(e);
  } finally {
    db.end();
  }
}

run();
