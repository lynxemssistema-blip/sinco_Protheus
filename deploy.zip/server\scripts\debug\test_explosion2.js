const pg = require('./db');

async function run() {
    try {
        const query = `
            WITH RECURSIVE
            -- Pre-fetch SC2 para o pedido inteiro (1 scan em vez de N correlated subqueries)
            sc2_lookup AS (
                SELECT
                    c2.c2_itempv,
                    TRIM(c2.c2_produto) AS produto,
                    TRIM(c2.c2_num)     AS op_num,
                    TRIM(c2.c2_tpop)   AS op_tipo,
                    ROW_NUMBER() OVER (
                        PARTITION BY c2.c2_itempv, TRIM(c2.c2_produto)
                        ORDER BY c2.c2_num
                    ) AS rn
                FROM sc2010 c2
                WHERE TRIM(c2.c2_pedido) = '003954'
                  AND COALESCE(c2.d_e_l_e_t_, '') IN ('', ' ')
            ),
            sc2_first AS (
                SELECT c2_itempv, produto, op_num, op_tipo FROM sc2_lookup WHERE rn = 1
            ),
            -- 1. Capa de Itens do PV
            pv_itens AS (
                SELECT
                    TRIM(c6.c6_item) AS item_pedido,
                    TRIM(c6.c6_produto) AS produto_venda,
                    TRIM(sb1.b1_desc) AS desc_venda,
                    TRIM(sb1.b1_tipo) AS tipo_venda,
                    COALESCE(NULLIF(c6.c6_qtdven::numeric, 0), c2.c2_quant::numeric, 0) AS qtd_venda,
                    TRIM(c6.c6_um) AS unid_venda,
                    TRIM(c6.c6_xrevm) AS rev_metalfisa,
                    COALESCE(TRIM(c2.c2_num), SUBSTRING(TRIM(c6.c6_numop), 1, 6)) AS op_num,
                    TRIM(c2.c2_tpop) AS op_tipo
                FROM sc6010 c6
                LEFT JOIN sc2010 c2
                    ON c2.c2_filial = c6.c6_filial
                    AND TRIM(c2.c2_pedido) = TRIM(c6.c6_num)
                    AND c2.c2_itempv = c6.c6_item
                    AND c2.c2_sequen = '001'
                    AND COALESCE(c2.d_e_l_e_t_, '') IN ('', ' ')
                LEFT JOIN sb1010 sb1
                    ON TRIM(sb1.b1_cod) = TRIM(c6.c6_produto)
                    AND COALESCE(sb1.d_e_l_e_t_, '') IN ('', ' ')
                WHERE TRIM(c6.c6_num) = '003954'
                  AND COALESCE(c6.d_e_l_e_t_, '') IN ('', ' ')
                  AND COALESCE(TRIM(c6.c6_numop), '') != ''
                  AND TRIM(c6.c6_item) = '01'
            ),
            -- 2. Explosão Recursiva de BOM
            estrutura AS (
                -- Nível 0: produtos vendidos
                SELECT
                    pv.item_pedido,
                    0 AS nivel,
                    pv.produto_venda AS produto_pai,
                    pv.produto_venda AS componente,
                    pv.desc_venda AS descricao,
                    pv.tipo_venda AS tipo,
                    pv.unid_venda AS unidade,
                    pv.rev_metalfisa AS revisao,
                    1::numeric AS qtd_base,
                    pv.qtd_venda AS qtd_necessaria,
                    pv.op_num AS op_relacionada,
                    pv.op_tipo AS op_tipo_relacionada
                FROM pv_itens pv

                UNION ALL

                -- Nível N: Componentes
                SELECT
                    e.item_pedido,
                    e.nivel + 1,
                    TRIM(sg1.g1_cod),
                    TRIM(sg1.g1_comp),
                    TRIM(sb1.b1_desc),
                    TRIM(sb1.b1_tipo),
                    TRIM(sb1.b1_um),
                    TRIM(sg1.g1_revfim),
                    COALESCE(sg1.g1_quant::numeric, 1) AS qtd_base,
                    (e.qtd_necessaria * COALESCE(sg1.g1_quant::numeric, 1)) AS qtd_necessaria,
                    COALESCE(sf.op_num, '') AS op_relacionada,
                    COALESCE(sf.op_tipo, '') AS op_tipo_relacionada
                FROM estrutura e
                JOIN sg1010 sg1
                    ON TRIM(sg1.g1_cod) = e.componente
                    AND COALESCE(sg1.d_e_l_e_t_, '') IN ('', ' ')
                LEFT JOIN sb1010 sb1
                    ON TRIM(sb1.b1_cod) = TRIM(sg1.g1_comp)
                    AND COALESCE(sb1.d_e_l_e_t_, '') IN ('', ' ')
                LEFT JOIN sc2_first sf
                    ON sf.c2_itempv = e.item_pedido
                    AND sf.produto = TRIM(sg1.g1_comp)
                WHERE e.nivel < 10
            ),
            pecas_distintas AS (
                SELECT DISTINCT componente FROM estrutura
            ),
            -- 3. Roteiro SG2: pré-materializa a revisão máxima por produto (O(N))
            max_rev_por_produto AS (
                SELECT TRIM(g2_produto) AS produto, MAX(TRIM(g2_codigo)) AS max_codigo
                FROM sg2010
                WHERE COALESCE(d_e_l_e_t_, '') IN ('', ' ')
                  AND TRIM(g2_produto) IN (SELECT componente FROM pecas_distintas)
                GROUP BY TRIM(g2_produto)
            ),
            roteiro_agregado AS (
                SELECT
                    TRIM(g2.g2_produto) AS g2_produto_limpo,
                    json_agg(
                        json_build_object(
                            'seq',           TRIM(g2.g2_operac),
                            'recurso',       TRIM(g2.g2_recurso),
                            'desc_operacao', TRIM(h1.h1_descri),
                            'setup',         g2.g2_setup,
                            'tempo_padrao',  g2.g2_tempad,
                            'ferramenta',    TRIM(g2.g2_ferram)
                        ) ORDER BY TRIM(g2.g2_operac)
                    ) AS operacoes
                FROM sg2010 g2
                JOIN max_rev_por_produto mr
                    ON TRIM(g2.g2_produto) = mr.produto
                    AND TRIM(g2.g2_codigo) = mr.max_codigo
                LEFT JOIN sh1010 h1
                    ON TRIM(h1.h1_codigo) = TRIM(g2.g2_recurso)
                    AND COALESCE(h1.d_e_l_e_t_, '') IN ('', ' ')
                WHERE COALESCE(g2.d_e_l_e_t_, '') IN ('', ' ')
                GROUP BY TRIM(g2.g2_produto)
            )
            -- RESULTADO + ROTEIRO (SG2) OTIMIZADO
            SELECT
                e.item_pedido,
                e.nivel,
                e.produto_pai,
                e.componente,
                e.descricao,
                e.tipo,
                e.unidade,
                e.revisao,
                e.qtd_necessaria,
                e.op_relacionada,
                e.op_tipo_relacionada,
                COALESCE(ra.operacoes, '[]'::json) AS operacoes
            FROM estrutura e
            LEFT JOIN roteiro_agregado ra ON ra.g2_produto_limpo = e.componente
            ORDER BY e.item_pedido ASC, e.nivel ASC, e.produto_pai ASC, e.componente ASC;
        `;

        const res = await pg.query(query);
        console.log("Rows returned:", res.rows.length);
        if (res.rows.length === 0) {
            console.log("Query returned empty!");
        } else {
            console.log("Level 0:", res.rows[0]);
        }

    } catch(err) {
        console.error(err);
    } finally {
        process.exit(0);
    }
}
run();
