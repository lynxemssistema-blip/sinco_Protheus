const { Pool } = require('pg');
const pool = new Pool({ 
  user: 'sinco2', 
  host: '192.168.1.61', 
  password: 'sinco25', 
  database: 'p12prd', 
  port: 5432 
});

async function test() {
    // Fetch OPs
    const sql = `
        SELECT
            btrim(c2.c2_num) as op,
            btrim(c2.c2_pedido) as pedido,
            btrim(c2.c2_produto) as produto,
            c2.c2_quant as qtd_plan
        FROM sc2010 c2
        WHERE TRIM(c2.c2_pedido) LIKE '%4155%' AND COALESCE(c2.d_e_l_e_t_, '') = ''
    `;
    const res = await pool.query(sql);
    console.log("OPs:");
    console.table(res.rows);

    const productCodes = [...new Set(res.rows.map(r => r.produto))];

    if (productCodes.length > 0) {
        const pgPlaceholders = productCodes.map((_, i) => `$${i + 1}`).join(',');
        const mapSql = `
            SELECT 
                btrim(g2.g2_produto) as produto, 
                btrim(g2.g2_operac) as operacao_codigo, 
                btrim(g2.g2_recurso) as h1_codigo, 
                btrim(h1.h1_descri) as h1_descri
            FROM sg2010 g2
            LEFT JOIN sh1010 h1 ON btrim(h1.h1_codigo) = btrim(g2.g2_recurso) AND COALESCE(h1.d_e_l_e_t_, '') IN ('', ' ')
            WHERE btrim(g2.g2_produto) IN (${pgPlaceholders}) AND COALESCE(g2.d_e_l_e_t_, '') IN ('', ' ')
        `;
        const mapRes = await pool.query(mapSql, productCodes);
        console.log("\nMapping (sg2010):");
        console.table(mapRes.rows.slice(0, 20));
    }
    
    process.exit(0);
}

test().catch(e => { console.error(e); process.exit(1); });
