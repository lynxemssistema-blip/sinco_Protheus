const express = require('express');
const router = require('./reports.js');
console.log(router.stack.map(r => r.route && r.route.path));
