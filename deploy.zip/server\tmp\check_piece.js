const mysqlPool = require('../services/mysqlService');

async function main() {
    try {
        const pieceCode = 'MT4-24112.psm';

        console.log(`--- Materials for ${pieceCode} ---`);
        const [materials] = await mysqlPool.execute(`
            SELECT m.CodMatFabricante as componentCode, 
                   mat.DescResumo as componentDesc,
                   m.PecaQtde as quantity
            FROM montapeca m
            LEFT JOIN material mat ON m.IdMaterial = mat.IdMaterial
            WHERE m.CodMatFabricantePeca = ?
        `, [pieceCode]);
        console.table(materials);

        console.log(`--- Processes for ${pieceCode} ---`);
        const [processes] = await mysqlPool.execute(`
            SELECT p.processofabricacao, mp.SequenciaExecucao, mp.TempoPadraoMin
            FROM material_processo mp
            LEFT JOIN processofabricacao p ON mp.IdProcesso = p.IdProcessoFabricacao
            WHERE mp.codmatFabricante = ?
            ORDER BY mp.SequenciaExecucao ASC
        `, [pieceCode]);
        console.table(processes);

    } catch (err) {
        console.error("Error:", err);
    } finally {
        process.exit();
    }
}
main();
