const db = require('./services/mysqlService');
db.execute("SELECT produto_codigo FROM produtos_docs WHERE TRIM(produto_codigo) = ?", ['MT4-30718'])
  .then(r => {
      console.log('Result MATCH: ', r[0]);
      process.exit();
  });
