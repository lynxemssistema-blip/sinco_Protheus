require('dotenv').config();
const { Pool } = require('pg');

const db = new Pool({
  host: process.env.PG_HOST || '192.168.1.77',
  port: process.env.PG_PORT || 5432,
  user: process.env.PG_USER || 'postgres',
  password: process.env.PG_PASSWORD || 'O&sZ2021@!*#@Mtf',
  database: process.env.PG_DATABASE || 'protheus_test',
});

async function run() {
  try {
    const pedido = '4543';
    const p = String(pedido).trim().padStart(6, '0');
    
    // 1. The original query with OR c2_obs ILIKE
    const q1 = `
      EXPLAIN ANALYZE SELECT c2_num, c2_pedido, c2_obs 
      FROM public.sc2010 c2 
      WHERE (c2.c2_pedido = $1 OR TRIM(c2.c2_obs) ILIKE '%' || $1 || '%')
      AND COALESCE(d_e_l_e_t_, '') = ''
    `;
    
    // 2. The optimized query restricted to empty c2_pedido
    const q2 = `
      EXPLAIN ANALYZE SELECT c2_num, c2_pedido, c2_obs 
      FROM public.sc2010 c2 
      WHERE (c2.c2_pedido = $1 OR (TRIM(COALESCE(c2.c2_pedido, '')) = '' AND TRIM(c2.c2_obs) LIKE $2))
      AND COALESCE(d_e_l_e_t_, '') = ''
    `;

    console.log('--- ORIGINAL QUERY ---');
    let res = await db.query(q1, [p]);
    console.log(res.rows.map(r => r['QUERY PLAN']).join('\n'));

    console.log('\n--- OPTIMIZED QUERY ---');
    res = await db.query(q2, [p, `%${pedido.trim()}%`]);
    console.log(res.rows.map(r => r['QUERY PLAN']).join('\n'));
    
  } catch(e) {
    console.error(e);
  } finally {
    db.end();
  }
}

run();
