const mysqlPool = require('../services/mysqlService');

async function main() {
    try {
        console.log('--- montapeca ---');
        const [rows] = await mysqlPool.execute(
            `SELECT m.CodMatFabricante as mat_sinco, 
                    IFNULL(m.CodMatFabricantePeca, '') as peca, 
                    m.PecaQtde, 
                    mat.DescResumo as material 
             FROM montapeca m 
             LEFT JOIN material mat ON m.IdMaterial = mat.IdMaterial 
             LIMIT 10`
        );
        console.table(rows);

        console.log('--- material_processo ---');
        const [mp_rows] = await mysqlPool.execute(
            `SELECT mp.codmatFabricante, p.processofabricacao, mp.SequenciaExecucao, mp.TempoPadraoMin
             FROM material_processo mp
             LEFT JOIN processofabricacao p ON mp.IdProcesso = p.IdProcessoFabricacao
             LIMIT 10`
        );
        console.table(mp_rows);

    } catch (err) {
        console.error("Error:", err);
    } finally {
        process.exit();
    }
}
main();
