require('dotenv').config({ path: '.env' });
const { Pool } = require('pg');
const pool = new Pool({
  user: process.env.PG_USER,
  host: process.env.PG_HOST,
  database: process.env.PG_DATABASE,
  password: process.env.PG_PASSWORD,
  port: process.env.PG_PORT,
});

async function test() {
  try {
    const res = await pool.query(`
            SELECT
                TRIM(c5.c5_num)     AS pedido,
                TRIM(c5.c5_cliente) AS cod_cliente,
                TRIM(c5.c5_lojacli) AS loja_cliente,
                TRIM(c6.c6_item)    AS item,
                TRIM(c6.c6_produto) AS codigo,
                TRIM(c6.c6_xrevm) AS rev_codigo,
                TRIM(c6.c6_xrevc) AS c6_rev_cliente,
                sb1.b1_desc   AS descricao,
                c6.c6_um      AS unidade,
                COALESCE(c6.c6_qtdven, 0)::numeric(18,6)  AS quantidade,
                TRIM(c6.c6_entreg) AS entrega_raw,
                TRIM(c6.c6_pedcli) AS ped_cliente,
                TRIM(c2.c2_num) AS op_num,
                TRIM(c2.c2_num) || TRIM(c2.c2_item) || TRIM(c2.c2_sequen) AS op_num_completa,
                TRIM(c2.c2_tpop) AS op_tipo,
                c2.c2_quant   AS op_qtd,
                COALESCE(c6.c6_qtdent, 0)::numeric(18,6) AS qtd_entreg,
                (COALESCE(c6.c6_qtdven, 0) - COALESCE(c6.c6_qtdent, 0))::numeric(18,6) AS qtd_faturar,
                CASE
                    WHEN sb1.b1_msblql IN ('1','S','T','Y') OR sz0_chk.ok IS NOT NULL THEN 'Restrição'
                    WHEN COALESCE(c6.c6_xrevm, '') <> COALESCE(c6.c6_xrevc, '') THEN 'Revisão'
                    WHEN sg1_chk.ok IS NULL AND sg2_chk.ok IS NULL THEN 'Novo'
                    ELSE 'PCP'
                END AS status_tipo_item,
                CASE
                    WHEN sb1.b1_msblql IN ('1','S','T','Y') THEN 'Produto bloqueado no cadastro (SB1 b1_msblql). Rev. MF: ' || COALESCE(TRIM(c6.c6_xrevm), '-') || ' / Rev. Cli: ' || COALESCE(TRIM(c6.c6_xrevc), '-')
                    WHEN sz0_chk.ok IS NOT NULL THEN 'Restrição pendente no cadastro (SZ0 status=P). Rev. MF: ' || COALESCE(TRIM(c6.c6_xrevm), '-') || ' / Rev. Cli: ' || COALESCE(TRIM(c6.c6_xrevc), '-')
                    WHEN COALESCE(c6.c6_xrevm, '') <> COALESCE(c6.c6_xrevc, '') THEN 'Diferença de revisão detectada. Rev. MF: ' || COALESCE(TRIM(c6.c6_xrevm), '-') || ' / Rev. Cli: ' || COALESCE(TRIM(c6.c6_xrevc), '-')
                    WHEN sg1_chk.ok IS NULL AND sg2_chk.ok IS NULL THEN 'Produto novo — sem estrutura (BOM) cadastrada no Protheus.'
                    ELSE 'Item com estrutura existente, liberado para PCP.'
                END AS status_tipo_detalhe
            FROM public.sc5010 c5
            JOIN public.sc6010 c6
                ON COALESCE(c6.d_e_l_e_t_, '') = ''
                AND c6.c6_filial = c5.c5_filial
                AND c6.c6_num = c5.c5_num
            LEFT JOIN public.sb1010 sb1
                ON COALESCE(sb1.d_e_l_e_t_, '') = ''
                AND TRIM(sb1.b1_cod) = TRIM(c6.c6_produto)
            LEFT JOIN public.sc2010 c2
                ON (c2.c2_pedido = c5.c5_num )
                AND c2.c2_itempv = c6.c6_item
                AND COALESCE(c2.d_e_l_e_t_, '') = ''
            LEFT JOIN LATERAL (
                SELECT 1 as ok FROM public.sz0010
                WHERE TRIM(z0_produto) = TRIM(c6.c6_produto)
                AND COALESCE(d_e_l_e_t_, '') <> '*' AND z0_status = 'P' LIMIT 1
            ) sz0_chk ON true
            LEFT JOIN LATERAL (
                SELECT 1 as ok FROM public.sg1010
                WHERE TRIM(g1_cod) = TRIM(c6.c6_produto)
                AND COALESCE(d_e_l_e_t_, '') <> '*' LIMIT 1
            ) sg1_chk ON true
            LEFT JOIN LATERAL (
                SELECT 1 as ok FROM public.sg2010
                WHERE TRIM(g2_produto) = TRIM(c6.c6_produto)
                AND COALESCE(d_e_l_e_t_, '') <> '*' LIMIT 1
            ) sg2_chk ON true
            WHERE c5.c5_num = $1
            AND COALESCE(c5.d_e_l_e_t_, '') = ''
            AND c5.c5_tipo <> 'B'
            ORDER BY c6.c6_item ASC
    `, ['004156']);
    console.log(`FASE 1 OK - Encontrou ${res.rows.length} itens no PostgreSQL`);
  } catch (err) {
    console.error('ERRO FASE 1 (Postgres):', err);
  } finally {
    pool.end();
  }
}
test();
