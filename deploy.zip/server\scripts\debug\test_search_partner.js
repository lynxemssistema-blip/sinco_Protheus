const db = require('./db');
async function test() {
    try {
        const q = 'KMI';
        const searchTerm = `%${q}%`;
        const query = `
            WITH partners AS (
                SELECT 
                    TRIM(a1_cod) AS codigo,
                    TRIM(a1_loja) AS loja,
                    TRIM(a1_nome) AS nome,
                    TRIM(a1_nreduz) AS nreduz,
                    TRIM(a1_end) AS endereco,
                    TRIM(a1_bairro) AS bairro,
                    TRIM(a1_mun) AS cidade,
                    TRIM(a1_est) AS uf,
                    TRIM(a1_cep) AS cep,
                    TRIM(a1_tel) AS telefone,
                    'Cliente' AS tipo
                FROM public.sa1010
                WHERE 
                    COALESCE(d_e_l_e_t_, '') = ''
                    AND (
                        a1_cod ILIKE $1 
                        OR a1_nome ILIKE $1 
                        OR a1_nreduz ILIKE $1
                    )
                UNION ALL
                SELECT 
                    TRIM(a2_cod) AS codigo,
                    TRIM(a2_loja) AS loja,
                    TRIM(a2_nome) AS nome,
                    TRIM(a2_nreduz) AS nreduz,
                    TRIM(a2_end) AS endereco,
                    TRIM(a2_bairro) AS bairro,
                    TRIM(a2_mun) AS cidade,
                    TRIM(a2_est) AS uf,
                    TRIM(a2_cep) AS cep,
                    TRIM(a2_tel) AS telefone,
                    'Fornecedor' AS tipo
                FROM public.sa2010
                WHERE 
                    COALESCE(d_e_l_e_t_, '') = ''
                    AND (
                        a2_cod ILIKE $1 
                        OR a2_nome ILIKE $1 
                        OR a2_nreduz ILIKE $1
                    )
            )
            SELECT * FROM partners
            ORDER BY nome
            LIMIT 50
        `;
        const result = await db.query(query, [searchTerm]);
        console.log(result.rows);
    } catch(err) {
        console.error(err);
    } finally {
        process.exit();
    }
}
test();
