const axios = require('axios');

async function run() {
  const payload = {
    "items": [
      {
        "filial": "01",
        "produto": "MT3-14331",
        "quant": 2,
        "datpri": "20260430",
        "datprf": "20260430",
        "obs": "",
        "pedido": "004546",
        "itempv": "02"
      }
    ]
  };

  try {
    const res = await axios.post('http://localhost:5000/api/protheus/ordem-producao/incluir', payload);
    console.log('RES:', res.data);
  } catch(e) {
    if (e.response) {
       console.log("ERR status:", e.response.status);
       console.log("ERR data:", e.response.data);
    } else {
       console.log("ERR message:", e.message);
    }
  }
}
run();
