const db = require('../db'); // Postgres
const mysqlPool = require('../services/mysqlService'); // MySQL

async function syncOsiUnits() {
    try {
        console.log('🚀 [SYNC-OSI] Iniciando sincronização real de ordemservicoitem...');

        const [mysqlRows] = await mysqlPool.execute(`
            SELECT IdOrdemServicoItem, CodMatFabricante, Unidade 
            FROM ordemservicoitem 
            WHERE CodMatFabricante IS NOT NULL AND CodMatFabricante != ''
        `);
        console.log(`📊 Total de registros em ordemservicoitem: ${mysqlRows.length}`);

        const protheusQuery = `
            SELECT TRIM(b1_cod) as codigo, TRIM(b1_um) as unidade_protheus
            FROM sb1010
            WHERE COALESCE(d_e_l_e_t_, '') = ''
        `;
        const pgRes = await db.query(protheusQuery);
        const protheusMap = {};
        pgRes.rows.forEach(r => {
            protheusMap[r.codigo] = r.unidade_protheus;
        });

        let atualizados = 0;
        let erros = 0;

        for (const row of mysqlRows) {
            const codigo = row.CodMatFabricante ? row.CodMatFabricante.trim() : null;
            const protheusUnit = protheusMap[codigo];

            if (protheusUnit && protheusUnit !== row.Unidade) {
                try {
                    await mysqlPool.execute(
                        'UPDATE ordemservicoitem SET Unidade = ? WHERE IdOrdemServicoItem = ?',
                        [protheusUnit, row.IdOrdemServicoItem]
                    );
                    atualizados++;
                    if (atualizados % 100 === 0) {
                        console.log(`✅ ${atualizados} itens de OS atualizados...`);
                    }
                } catch (updateErr) {
                    console.error(`❌ Erro ao atualizar item OS ${codigo}:`, updateErr.message);
                    erros++;
                }
            }
        }

        console.log('\n====================================================');
        console.log('🎉 Sincronização OSI concluída!');
        console.log(`📊 Total atualizados: ${atualizados}`);
        console.log(`📊 Erros: ${erros}`);
        console.log('====================================================');

    } catch (err) {
        console.error("❌ Erro fatal OSI:", err);
    } finally {
        process.exit();
    }
}

syncOsiUnits();
