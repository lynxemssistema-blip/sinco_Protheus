require('dotenv').config();
const mysql = require('mysql2/promise');

async function test() {
    const dbConfig = {
        host: process.env.MYSQL_HOST,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASS,
        database: process.env.MYSQL_DB,
        port: 3306
    };
    let connection;
    try {
        console.log("Conectando...");
        connection = await mysql.createConnection(dbConfig);
        console.log("Conectado! Lançando query...");
        const [rows] = await connection.execute(
            'SELECT idUsuario, NomeCompleto, Login, TipoUsuario, fotoUsuario, email, aprovado FROM usuario WHERE Login = ? AND Senha = ?',
            ['Edson', 'EdsonMetal'] // dummy password just to test query format
        );
        console.log("Query Sucesso! Resultado:", rows.length);
    } catch(e) {
        console.error("🔥 ERRO NA QUERY:", e);
    } finally {
        if (connection) await connection.end();
    }
}
test();
