const { Client } = require('pg');
const client = new Client({host: '192.168.1.61', port: 5432, user: 'sinco2', password: 'sinco25', database: 'p12prd'});

async function run() {
    await client.connect();
    const res = await client.query(`SELECT g2_codigo FROM public.sg2010 WHERE btrim(g2_produto) = $1 AND COALESCE(d_e_l_e_t_, '') = '' ORDER BY g2_codigo DESC LIMIT 1`, ['MT6-7544']);
    console.log(res.rows);
    await client.end();
}
run().catch(console.error);
