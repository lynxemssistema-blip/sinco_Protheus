const http = require('http');
const jwt = require('jsonwebtoken');

const token = jwt.sign({ id: 1, name: 'Admin', role: 'ti' }, 'metalfisasecuritykey2026', { expiresIn: '1h' });

const options = {
  hostname: '192.168.1.77',
  port: 3001,
  path: '/api/sgq/processos',
  method: 'GET',
  headers: {
    'Authorization': 'Bearer ' + token
  }
};

const req = http.request(options, res => {
  let data = '';
  res.on('data', chunk => { data += chunk; });
  res.on('end', () => {
    console.log('STATUS:', res.statusCode);
    const parsed = JSON.parse(data);
    console.log('LENGTH:', parsed.length);
    if(parsed.length > 0) {
        console.log('DATA 0:', JSON.stringify(parsed[0]).substring(0, 100));
    } else {
        console.log(parsed);
    }
  });
});
req.on('error', e => console.error(e));
req.end();
