const db = require('./db');
async function test() {
    try {
        const fornecedor = '00000128';
        const loja = '0001';
        const search = 'KMI';
        const globalSearch = 'true';

        let cte1 = `
            SELECT 
                F1.F1_DOC AS "Num_NF",
                F1.F1_SERIE AS "Serie",
                F1.F1_EMISSAO AS "Data_Emissao",
                F1.F1_FORNECE AS "Cod_Fornecedor",
                A2.A2_NOME AS "Razao_Social_Fornecedor",
                A2.A2_CGC AS "CNPJ_Fornecedor",
                F1.F1_ESPECIE AS "Tipo_Doc",
                'Retorno' AS "Direcao",
                A2.A2_LOJA AS "Loja"
            FROM public.sf1010 F1
            INNER JOIN public.sa2010 A2 ON A2.A2_COD = F1.F1_FORNECE 
                                AND A2.A2_LOJA = F1.F1_LOJA
                                AND COALESCE(A2.D_E_L_E_T_, '') IN ('', ' ')
            WHERE COALESCE(F1.D_E_L_E_T_, '') IN ('', ' ')
        `;

        let cte2 = `
            SELECT 
                F2.F2_DOC AS "Num_NF",
                F2.F2_SERIE AS "Serie",
                F2.F2_EMISSAO AS "Data_Emissao",
                F2.F2_CLIENTE AS "Cod_Fornecedor",
                COALESCE(A1.A1_NOME, A2.A2_NOME) AS "Razao_Social_Fornecedor",
                COALESCE(A1.A1_CGC, A2.A2_CGC) AS "CNPJ_Fornecedor",
                F2.F2_ESPECIE AS "Tipo_Doc",
                'Saída' AS "Direcao",
                F2.F2_LOJA AS "Loja"
            FROM public.sf2010 F2
            LEFT JOIN public.sa1010 A1 ON A1.A1_COD = F2.F2_CLIENTE AND A1.A1_LOJA = F2.F2_LOJA AND F2.F2_TIPO NOT IN ('B', 'D')
            LEFT JOIN public.sa2010 A2 ON A2.A2_COD = F2.F2_CLIENTE AND A2.A2_LOJA = F2.F2_LOJA AND F2.F2_TIPO IN ('B', 'D')
            WHERE COALESCE(F2.D_E_L_E_T_, '') IN ('', ' ')
        `;

        let sql = `
            WITH combined_nfs AS (
                ${cte1}
                UNION ALL
                ${cte2}
            )
            SELECT * FROM combined_nfs WHERE 1=1
        `;

        const params = [];
        let paramIndex = 1;

        if (globalSearch !== 'true') {
            sql += ` AND "Cod_Fornecedor" = $${paramIndex}`;
            params.push(fornecedor);
            paramIndex++;
            if (loja) {
                sql += ` AND "Loja" = $${paramIndex}`;
                params.push(loja);
                paramIndex++;
            }
        }

        if (search) {
            const tokens = search.split(/[\s\-]+/).filter(t => t.trim().length > 0);
            if (tokens.length > 0) {
                const tokenConditions = tokens.map(token => {
                    const isNumeric = /^\d+$/.test(token);
                    let paddedToken = token;
                    if (isNumeric && token.length <= 9) {
                        paddedToken = token.padStart(9, '0');
                    }
                    let condition = `("Num_NF" ILIKE $${paramIndex} OR "Razao_Social_Fornecedor" ILIKE $${paramIndex}`;
                    params.push(`%${token}%`);
                    paramIndex++;

                    if (isNumeric) {
                        condition += ` OR "Num_NF" ILIKE $${paramIndex}`;
                        params.push(`%${paddedToken}%`);
                        paramIndex++;
                    }
                    condition += `)`;
                    return condition;
                });
                sql += ` AND (${tokenConditions.join(' AND ')})`;
            }
        }

        sql += ` ORDER BY "Data_Emissao" DESC LIMIT 10;`;
        
        const { rows } = await db.query(sql, params);
        console.log("Rows count:", rows.length);
        console.log("SQL:", sql);
        console.log("Params:", params);
        if (rows.length > 0) {
            console.log(rows[0]);
        }

    } catch (err) {
        console.error(err);
    } finally {
        process.exit();
    }
}
test();
