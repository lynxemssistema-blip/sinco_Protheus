const { Pool } = require('pg');

async function check() {
  const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'p12prd',
    password: 'admin',
    port: 5432,
  });

  const produto = "MT3-14331";
  
  try {
    const res = await pool.query(
      `SELECT g2_codigo FROM public.sg2010 WHERE btrim(g2_produto) = $1 AND d_e_l_e_t_ = ' ' ORDER BY g2_codigo DESC LIMIT 1`,
      [produto]
    );
    console.log("Rows:", res.rows);
  } catch (e) {
    console.error(e.message);
  } finally {
    pool.end();
  }
}
check();
