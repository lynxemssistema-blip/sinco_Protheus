const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
    host: process.env.PGHOST,
    port: process.env.PGPORT,
    user: process.env.PGUSER,
    password: process.env.PGPASSWORD,
    database: process.env.PGDATABASE,
});

async function main() {
    const produto = 'MT5-29462';

    console.log(`\n🔍 Testando roteiro para produto: ${produto}...\n`);

    try {
        const query = `
            SELECT 
                g2_operac AS seq,
                g2_descri AS descricao,
                TRIM(g2_recurso) AS recurso,
                COALESCE(g2_tempad, 0) AS tempo_padrao
            FROM public.sg2010 
            WHERE TRIM(g2_produto) = $1
              AND d_e_l_e_t_ = ' '
            ORDER BY g2_operac
        `;

        const { rows } = await pool.query(query, [produto]);

        if (rows.length === 0) {
            console.log('❌ Nenhum roteiro encontrado para este produto.\n');
        } else {
            console.log(`✅ ${rows.length} operações encontradas:\n`);
            console.table(rows);
        }

    } catch (error) {
        console.error('❌ Erro na query principal:', error.message);

        console.log('\n📋 Tentando buscar estrutura da tabela SG2010 (Fallback debug):\n');
        try {
            const fallbackQuery = `
                SELECT column_name, data_type 
                FROM information_schema.columns 
                WHERE table_name = 'sg2010' AND column_name LIKE 'g2_%'
                ORDER BY ordinal_position
            `;
            const { rows: cols } = await pool.query(fallbackQuery);
            console.table(cols);
        } catch (fallbackError) {
            console.error('❌ Falha ao buscar colunas do SG2010:', fallbackError.message);
        }
    } finally {
        await pool.end();
    }
}

main();
