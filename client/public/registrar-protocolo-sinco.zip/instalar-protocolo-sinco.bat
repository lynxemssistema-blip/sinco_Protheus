@echo off
chcp 65001 >nul
echo ========================================================
echo   Instalador de Protocolo de Rede - SINCO ERP
echo ========================================================
echo.
echo Registrando protocolo sinco-folder:// no Windows...
reg import "%~dp0registrar-protocolo-sinco.reg"
if %errorlevel% equ 0 (
    echo.
    echo [SUCESSO] Protocolo SINCO registrado com sucesso!
    echo Agora os links de abertura de pastas no Windows Explorer
    echo funcionarao diretamente no seu navegador.
) else (
    echo.
    echo [AVISO] Houve um problema ao registrar. Tente executar como Administrador.
)
echo.
pause
